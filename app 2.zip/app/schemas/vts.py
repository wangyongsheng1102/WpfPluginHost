"""
VTS Configurator の Pydantic スキーマ定義。
Project/Layout/Process/CTLog 等のリクエスト/レスポンス、および画面初期表示用コンテキストを定義する。
"""
from decimal import Decimal
from datetime import datetime
from typing import Optional, Any, List

from pydantic import Field, ConfigDict
from app.schemas.base import BaseModel


# ----- Project -----
class ProjectBase(BaseModel):
    # 空文字・空白のみは Schema では許容し、サービス層で ProjectNameEmptyError として 400 を返す
    project_name: str = Field(..., max_length=255, description="プロジェクト名（空文字・空白のみ不可、未指定時は 400 PROJECT_NAME_EMPTY）")


class ProjectCreate(ProjectBase):
    pass


class ProjectUpdate(BaseModel):
    """プロジェクト更新。削除は DELETE /projects/{id} で論理削除。"""
    # 空文字・空白のみはサービス層で ProjectNameEmptyError として 400 を返す
    project_name: Optional[str] = Field(None, max_length=255)


class ProjectCopyRequest(BaseModel):
    """プロジェクト複製時のリクエスト。省略時は「Copy of {元の名前}」になる。"""
    # 指定時かつ空文字・空白のみの場合はサービス層でフォールバック名を使用（copy は name 省略可のため 400 は不要）
    project_name: Optional[str] = Field(None, max_length=255, description="新規プロジェクト名（省略可）")


class ProjectResponse(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    project_id: int
    project_name: str
    del_flg: bool = False
    create_date: Optional[datetime] = None
    create_user: Optional[str] = None
    update_date: Optional[datetime] = None
    update_user: Optional[str] = None


# ----- Layout -----
class LayoutBase(BaseModel):
    vts_return_trip: Optional[bool] = None
    circulation_type: Optional[str] = Field(None, max_length=50)
    module_direction: Optional[str] = Field(None, max_length=50)
    footprint_limit_x: Optional[Decimal] = None
    footprint_limit_y: Optional[Decimal] = None
    footprint_limit_z: Optional[Decimal] = None
    work_name: Optional[str] = Field(None, max_length=200)
    work_size_w: Optional[Decimal] = None
    work_size_l: Optional[Decimal] = None
    work_size_d: Optional[Decimal] = None
    work_mass: Optional[Decimal] = None
    work_products_per_pallet: Optional[int] = None
    pallet_w: Optional[Decimal] = None
    pallet_l: Optional[Decimal] = None
    pallet_d: Optional[Decimal] = None
    pallet_mass: Optional[Decimal] = None
    slider_type: Optional[str] = Field(None, max_length=10)

    process_distance_type: Optional[str] = Field(None, max_length=50)
    circulation_axis_full_length: Optional[Decimal] = None
    circulation_axis_offset: Optional[Decimal] = None
    circulation_axis_speed: Optional[Decimal] = None
    circulation_axis_acceleration: Optional[Decimal] = None
    circulation_axis_sensor: Optional[str] = Field(None, max_length=50)
    circulation_axis_lead: Optional[Decimal] = None
    circulation_name: Optional[str] = Field(None, max_length=100, description="循環名称")
    circulation_type_attr: Optional[str] = Field(None, max_length=50)
    circulation_guide: Optional[str] = Field(None, max_length=50)
    circulation_stroke: Optional[Decimal] = None
    circulation_motor_set_direction: Optional[str] = Field(None, max_length=50)
    eor_speed: Optional[Decimal] = None
    eor_acceleration: Optional[Decimal] = None
    control_controller_pattern: Optional[str] = Field(None, max_length=20)
    finish_flg: Optional[bool] = None
    position_or_distance: Optional[str] = Field(None, max_length=50)
    vts_total_length: Optional[Decimal] = None
    module_count: Optional[int] = None
    del_flg: Optional[bool] = None


class LayoutCreate(LayoutBase):
    pass


class LayoutUpdate(BaseModel):
    vts_return_trip: Optional[bool] = None
    circulation_type: Optional[str] = Field(None, max_length=50)
    module_direction: Optional[str] = Field(None, max_length=50)
    footprint_limit_x: Optional[Decimal] = None
    footprint_limit_y: Optional[Decimal] = None
    footprint_limit_z: Optional[Decimal] = None
    work_name: Optional[str] = Field(None, max_length=200)
    work_size_w: Optional[Decimal] = None
    work_size_l: Optional[Decimal] = None
    work_size_d: Optional[Decimal] = None
    work_mass: Optional[Decimal] = None
    work_products_per_pallet: Optional[int] = None
    pallet_w: Optional[Decimal] = None
    pallet_l: Optional[Decimal] = None
    pallet_d: Optional[Decimal] = None
    pallet_mass: Optional[Decimal] = None
    slider_type: Optional[str] = Field(None, max_length=10)

    process_distance_type: Optional[str] = Field(None, max_length=50)
    circulation_axis_full_length: Optional[Decimal] = None
    circulation_axis_offset: Optional[Decimal] = None
    circulation_axis_speed: Optional[Decimal] = None
    circulation_axis_acceleration: Optional[Decimal] = None
    circulation_axis_sensor: Optional[str] = Field(None, max_length=50)
    circulation_axis_lead: Optional[Decimal] = None
    circulation_name: Optional[str] = Field(None, max_length=100, description="循環名称")
    circulation_type_attr: Optional[str] = Field(None, max_length=50)
    circulation_guide: Optional[str] = Field(None, max_length=50)
    circulation_stroke: Optional[Decimal] = None
    circulation_motor_set_direction: Optional[str] = Field(None, max_length=50)
    eor_speed: Optional[Decimal] = None
    eor_acceleration: Optional[Decimal] = None
    control_controller_pattern: Optional[str] = Field(None, max_length=20)
    finish_flg: Optional[bool] = None
    position_or_distance: Optional[str] = Field(None, max_length=50)
    vts_total_length: Optional[Decimal] = None
    module_count: Optional[int] = None
    del_flg: Optional[bool] = None


class LayoutResponse(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    project_id: int
    layout_id: int
    vts_return_trip: Optional[bool] = None
    circulation_type: Optional[str] = None
    module_direction: Optional[str] = None
    footprint_limit_x: Optional[Decimal] = None
    footprint_limit_y: Optional[Decimal] = None
    footprint_limit_z: Optional[Decimal] = None
    work_name: Optional[str] = None
    work_size_w: Optional[Decimal] = None
    work_size_l: Optional[Decimal] = None
    work_size_d: Optional[Decimal] = None
    work_mass: Optional[Decimal] = None
    work_products_per_pallet: Optional[int] = None
    pallet_w: Optional[Decimal] = None
    pallet_l: Optional[Decimal] = None
    pallet_d: Optional[Decimal] = None
    pallet_mass: Optional[Decimal] = None
    slider_type: Optional[str] = None

    # LayoutBase から引き継ぐ循環軸・制御系のフィールド
    process_distance_type: Optional[str] = None
    circulation_axis_full_length: Optional[Decimal] = None
    circulation_axis_offset: Optional[Decimal] = None
    circulation_axis_speed: Optional[Decimal] = None
    circulation_axis_acceleration: Optional[Decimal] = None
    circulation_axis_sensor: Optional[str] = None
    circulation_axis_lead: Optional[Decimal] = None
    circulation_name: Optional[str] = Field(None, description="循環名称")
    circulation_type_attr: Optional[str] = None
    circulation_guide: Optional[str] = None
    circulation_stroke: Optional[Decimal] = None
    circulation_motor_set_direction: Optional[str] = None
    eor_speed: Optional[Decimal] = None
    eor_acceleration: Optional[Decimal] = None
    control_controller_pattern: Optional[str] = None
    finish_flg: Optional[bool] = None
    position_or_distance: Optional[str] = None
    vts_total_length: Optional[Decimal] = None
    module_count: Optional[int] = None

    del_flg: bool = False
    create_date: Optional[datetime] = None
    create_user: Optional[str] = None
    update_date: Optional[datetime] = None
    update_user: Optional[str] = None


# ----- LayoutDesign -----
class LayoutDesignUpdate(BaseModel):
    layout_design: Optional[dict] = None
    layout_image: Optional[str] = None


class LayoutDesignResponse(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    project_id: int
    layout_id: int
    layout_design: Optional[dict] = None
    layout_image: Optional[str] = None
    del_flg: bool = False
    create_date: Optional[datetime] = None
    create_user: Optional[str] = None
    update_date: Optional[datetime] = None
    update_user: Optional[str] = None


# ----- Process -----
class ProcessBase(BaseModel):
    """process_no / truck_no / log_no は API の path または query で渡す"""
    process_name: Optional[str] = Field(None, max_length=200)
    process_time: Optional[Decimal] = None
    process_time_tolerance: Optional[Decimal] = None
    settling_time: Optional[Decimal] = None
    process_stop_position: Optional[Decimal] = None
    process_forbidden_area: Optional[dict] = None
    move_to_process_speed: Optional[Decimal] = None
    move_to_process_accel: Optional[Decimal] = None
    ct_check_result: Optional[int] = None
    wait_time: Optional[Decimal] = None
    vts_move_time: Optional[Decimal] = None


class ProcessCreate(ProcessBase):
    """process_no は API の path パラメータで渡す"""


class ProcessUpdate(BaseModel):
    truck_no: Optional[int] = None
    log_no: Optional[int] = None
    process_name: Optional[str] = Field(None, max_length=200)
    process_time: Optional[Decimal] = None
    process_time_tolerance: Optional[Decimal] = None
    settling_time: Optional[Decimal] = None
    process_stop_position: Optional[Decimal] = None
    process_forbidden_area: Optional[dict] = None
    move_to_process_speed: Optional[Decimal] = None
    move_to_process_accel: Optional[Decimal] = None
    ct_check_result: Optional[int] = None
    wait_time: Optional[Decimal] = None
    vts_move_time: Optional[Decimal] = None


class ProcessResponse(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    project_id: int
    layout_id: int
    process_no: int
    truck_no: int
    log_no: int
    process_name: Optional[str] = None
    process_time: Optional[Decimal] = None
    process_time_tolerance: Optional[Decimal] = None
    settling_time: Optional[Decimal] = None
    process_stop_position: Optional[Decimal] = None
    process_forbidden_area: Optional[dict] = None
    move_to_process_speed: Optional[Decimal] = None
    move_to_process_accel: Optional[Decimal] = None
    ct_check_result: Optional[int] = None
    wait_time: Optional[Decimal] = None
    vts_move_time: Optional[Decimal] = None
    del_flg: bool = False
    create_date: Optional[datetime] = None
    create_user: Optional[str] = None
    update_date: Optional[datetime] = None
    update_user: Optional[str] = None


# ----- ProductList -----
class ProductListItemBase(BaseModel):
    product_id: int = Field(..., description="製品ID（m_Product）")
    quantity: int = Field(1, ge=0, description="数量")
    cable_no: Optional[str] = Field(None, max_length=50)


class ProductListItemCreate(ProductListItemBase):
    pass


class ProductListItemUpdate(BaseModel):
    quantity: Optional[int] = Field(None, ge=0)
    cable_no: Optional[str] = Field(None, max_length=50)


class ProductListItemResponse(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    project_id: int
    layout_id: int
    product_id: int
    quantity: int = 1
    cable_no: Optional[str] = None
    del_flg: bool = False
    create_date: Optional[datetime] = None
    create_user: Optional[str] = None
    update_date: Optional[datetime] = None
    update_user: Optional[str] = None


# ----- CTLogHeader / CTLogDetail -----
class CTLogCreate(BaseModel):
    target_cycle_time: Optional[Decimal] = None
    target_throughput: Optional[Decimal] = None
    calculation_range: Optional[str] = Field(None, max_length=100)
    slider_count: Optional[int] = None
    expected_ct: Optional[Decimal] = None
    expected_throughput: Optional[Decimal] = None
    expected_time_efficiency: Optional[Decimal] = None
    record_flg: Optional[bool] = None
    ct_result_image: Optional[str] = None


class CTLogUpdate(BaseModel):
    target_cycle_time: Optional[Decimal] = None
    target_throughput: Optional[Decimal] = None
    calculation_range: Optional[str] = Field(None, max_length=100)
    slider_count: Optional[int] = None
    expected_ct: Optional[Decimal] = None
    expected_throughput: Optional[Decimal] = None
    expected_time_efficiency: Optional[Decimal] = None
    record_flg: Optional[bool] = None
    ct_result_image: Optional[str] = None


class CTLogResponse(BaseModel):
    """t_ct_log_header ベース（一覧用）。明細は別 API で取得可。"""
    model_config = ConfigDict(from_attributes=True)

    project_id: int
    layout_id: int
    log_no: int
    target_cycle_time: Optional[Decimal] = None
    target_throughput: Optional[Decimal] = None
    calculation_range: Optional[str] = None
    slider_count: Optional[int] = None
    expected_ct: Optional[Decimal] = None
    expected_throughput: Optional[Decimal] = None
    expected_time_efficiency: Optional[Decimal] = None
    record_flg: Optional[bool] = None
    ct_result_image: Optional[str] = None
    del_flg: bool = False
    create_date: Optional[datetime] = None
    create_user: Optional[str] = None
    update_date: Optional[datetime] = None
    update_user: Optional[str] = None


class CTLogDetailCreate(BaseModel):
    """t_ct_log_detail 追加用"""

    log_detail_no: Optional[int] = Field(None, ge=1, description="省略時は当該ログ内で自動採番")
    log_detail_name: Optional[str] = Field(None, max_length=200, description="ログ明細名称")
    log_detail_value: Optional[str] = Field(None, description="ログ明細値")


class CTLogDetailResponse(BaseModel):
    """t_ct_log_detail レスポンス"""
    model_config = ConfigDict(from_attributes=True)

    project_id: int
    layout_id: int
    log_no: int
    log_detail_no: int
    log_detail_name: Optional[str] = None
    log_detail_value: Optional[str] = None
    del_flg: bool = False
    create_date: Optional[datetime] = None
    create_user: Optional[str] = None
    update_date: Optional[datetime] = None
    update_user: Optional[str] = None


class CTLogRecordFlgClearResponse(BaseModel):
    """指定 project/layout の CTログ record_flg を一括で false に更新した件数。"""
    updated_count: int


class CTHistoryResetResponse(BaseModel):
    """設計完了時など：当該 layout の CT ログ全件と log_no!=0 の process を物理削除した件数。"""
    ct_log_detail_deleted: int
    ct_log_header_deleted: int
    process_nonzero_log_deleted: int


class ComparisonColumnResponse(BaseModel):
    """比較画面用：1列 = 1レイアウト（t_layout + t_ct_log_header の最新1件）"""
    column_index: int
    layout_id: int
    layout_name: Optional[str] = None
    vts_total_length: Optional[Decimal] = None
    slider_count: Optional[int] = None
    module_count: Optional[int] = None
    expected_ct: Optional[Decimal] = None


# ----- Context responses (画面初期表示) -----
class HomeContextResponse(BaseModel):
    projects: List[ProjectResponse]


class DesignerStep1ContextResponse(BaseModel):
    project: Optional[ProjectResponse] = None
    layouts: List[LayoutResponse]


class DesignerStep2ContextResponse(BaseModel):
    project: ProjectResponse
    layout: LayoutResponse


class DesignerStep3ContextResponse(BaseModel):
    project: ProjectResponse
    layout: LayoutResponse
    processes: List[ProcessResponse]


class DesignerStep4ContextResponse(BaseModel):
    project: ProjectResponse
    layout: LayoutResponse
    layout_design: Optional[LayoutDesignResponse] = None
    processes: List[ProcessResponse]


class DesignerStep3_4ContextResponse(BaseModel):
    """STEP3/4 統合コンテキストレスポンス（STEP3 と STEP4 は画面上で統合された1ステップ）"""
    project: ProjectResponse
    layout: LayoutResponse
    layout_design: Optional[LayoutDesignResponse] = None
    processes: List[ProcessResponse]


class DesignerStep5ContextResponse(BaseModel):
    project: ProjectResponse
    layout: LayoutResponse
    layout_design: Optional[LayoutDesignResponse] = None
    product_list: List[ProductListItemResponse]


class Step5SaveRequest(BaseModel):
    """STEP5 完成時の一括保存リクエスト。キャンバス上のコンポーネント、ケーブル、サイドバーのコンポーネントをすべて保存。"""
    project_id: int = Field(..., description="プロジェクトID")
    layout_id: int = Field(..., description="レイアウトID")
    layout_design: Optional[dict] = Field(None, description="キャンバスのレイアウトとケーブル接続関係（JSONB）")
    layout_image: Optional[str] = Field(None, description="キャンバスのスクリーンショット（base64）")
    product_list: List[ProductListItemCreate] = Field(..., description="すべてのコンポーネント（キャンバス上とサイドバー）")


class Step5SaveResponse(BaseModel):
    """STEP5 保存後のレスポンス。保存された product_list と layout_design を含む。"""
    layout_design: LayoutDesignResponse
    product_list: List[ProductListItemResponse]


class CycleTimeStep1ContextResponse(BaseModel):
    project: ProjectResponse
    layouts: List[LayoutResponse]


class CycleTimeStep2ContextResponse(BaseModel):
    project: ProjectResponse
    layout: LayoutResponse
    processes: List[ProcessResponse]


class CycleTimeStep3ContextResponse(BaseModel):
    project: ProjectResponse
    layout: LayoutResponse
    ct_logs: List[CTLogResponse]


class CompareContextResponse(BaseModel):
    project: ProjectResponse
    layouts: List[LayoutResponse]
    ct_logs: Optional[List[CTLogResponse]] = None


# ----- MPrdUserUnique (Layout Unique) -----
class LayoutUniqueCreateRequest(BaseModel):
    """STEP3/4 レイアウトをユニーク製品として登録するリクエスト（m_prd_user_unique）"""
    layout_info_name: str = Field(..., max_length=200, description="レイアウト情報名称（必須）")
    min_cycle_time: Optional[Decimal] = Field(None, description="最短CT")
    layout_info: dict = Field(..., description="レイアウト情報（JSONB）")
    layout_image: Optional[str] = Field(None, description="レイアウト画像等の base64 文字列")


class LayoutUniqueResponse(BaseModel):
    """ユーザーユニーク製品マスタ（レイアウト情報）のレスポンス"""
    model_config = ConfigDict(from_attributes=True)

    layout_info_id: int
    layout_info_name: str
    layout_info: Optional[dict] = None
    min_cycle_time: Optional[Decimal] = None
    layout_image: Optional[str] = None
    del_flg: bool = False
    create_date: Optional[datetime] = None
    create_user: Optional[str] = None
    update_date: Optional[datetime] = None
    update_user: Optional[str] = None


# ----- MProduct (マスタ製品) -----
class MProductResponse(BaseModel):
    """製品情報マスタのレスポンス（product_type_id で m_ProductType 参照）"""
    model_config = ConfigDict(from_attributes=True)

    product_id: int
    product_name: str
    product_name_en: Optional[str] = None
    product_isome_image: Optional[str] = None
    product_side_view_image: Optional[str] = None
    product_top_view_image: Optional[str] = None
    product_type_id: Optional[int] = None
    product_type_name: Optional[str] = None
    product_type_name_en: Optional[str] = None
    product_model: Optional[str] = None
    product_code: Optional[str] = None
    min_cycle_time: Optional[Decimal] = None
    stroke: Optional[Decimal] = None
    list_price: Optional[Decimal] = None
    del_flg: bool = False


class MProductTypeResponse(BaseModel):
    """製品種類情報マスタのレスポンス"""
    model_config = ConfigDict(from_attributes=True)

    product_type_id: int
    product_type_name: str
    product_type_name_en: Optional[str] = None
    sort_no: Optional[int] = None
    del_flg: bool = False
    create_date: Optional[datetime] = None
    create_user: Optional[str] = None
    update_date: Optional[datetime] = None
    update_user: Optional[str] = None


class MProductCreate(BaseModel):
    """m_Product 登録用"""
    product_name: str = Field(..., max_length=200)
    product_name_en: Optional[str] = Field(None, max_length=200, description="製品名称（英語）")
    product_type_id: Optional[int] = None
    product_model: Optional[str] = Field(None, max_length=100)
    product_code: Optional[str] = Field(None, max_length=50)
    min_cycle_time: Optional[Decimal] = None
    stroke: Optional[Decimal] = None
    list_price: Optional[Decimal] = None
    product_isome_image: Optional[str] = None
    product_side_view_image: Optional[str] = None
    product_top_view_image: Optional[str] = None


class MProductUpdate(BaseModel):
    """m_Product 更新用"""
    product_name: Optional[str] = Field(None, max_length=200)
    product_name_en: Optional[str] = Field(None, max_length=200, description="製品名称（英語）")
    product_type_id: Optional[int] = None
    product_model: Optional[str] = Field(None, max_length=100)
    product_code: Optional[str] = Field(None, max_length=50)
    min_cycle_time: Optional[Decimal] = None
    stroke: Optional[Decimal] = None
    list_price: Optional[Decimal] = None
    product_isome_image: Optional[str] = None
    product_side_view_image: Optional[str] = None
    product_top_view_image: Optional[str] = None


class MProductI18nNamesUpdate(BaseModel):
    """製品名（日本語/英語）を同時に編集するための更新用"""
    product_name: str = Field(..., max_length=200, description="製品名称（日本語）")
    product_name_en: str = Field(..., max_length=200, description="製品名称（英語）")


class MProductI18nNamesResponse(BaseModel):
    """製品（全フィールド）を日本語/英語名付きで返すレスポンス（特殊编辑场面用）"""
    model_config = ConfigDict(from_attributes=True)

    product_id: int
    product_name: str
    product_name_en: Optional[str] = None

    product_isome_image: Optional[str] = None
    product_side_view_image: Optional[str] = None
    product_top_view_image: Optional[str] = None

    product_type_id: Optional[int] = None
    product_type_name: Optional[str] = None
    product_type_name_en: Optional[str] = None

    product_model: Optional[str] = None
    product_code: Optional[str] = None
    min_cycle_time: Optional[Decimal] = None
    stroke: Optional[Decimal] = None
    list_price: Optional[Decimal] = None
    del_flg: bool = False


# ----- Designer Sidebar Context -----
class DesignerSidebarContextResponse(BaseModel):
    """STEP3/4 サイドバー用コンテキスト（axis + processes）。layout_uniques/modules は常に空。取得は /sidebar/layout-uniques と /sidebar/products?category= を使用。"""
    layout_uniques: List[LayoutUniqueResponse] = Field(default_factory=list, description="互換用・常に空。GET .../sidebar/layout-uniques で取得")
    modules: List[MProductResponse] = Field(default_factory=list, description="互換用・常に空。GET .../sidebar/products?category=module|accessory で取得")
    circulation_axis_config: Optional[dict] = Field(None, description="循環軸設定（現在の layout の Process から抽出）")
    processes: List[ProcessResponse] = Field(default_factory=list, description="現在の layout のすべての process")
