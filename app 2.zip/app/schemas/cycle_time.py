"""
サイクルタイム計算API関連のPydanticスキーマ
"""
from pydantic import BaseModel, Field
from typing import List, Optional


class StopPositionItem(BaseModel):
    """停止位置データ項目"""
    point: int = Field(..., description="ポイント番号", ge=1)
    stop_position: float = Field(..., description="停止位置[mm]", ge=0)
    stop_time: float = Field(..., description="停止時間[s]", ge=0)
    maximum_speed: float = Field(..., description="速度[mm/s]", ge=0)
    acc_deceleration: float = Field(..., description="加減速度[mm/s²]", ge=0)


class CycleTimeCalculateRequest(BaseModel):
    """サイクルタイム計算リクエストスキーマ"""
    vts_total_length: float = Field(..., description="VTS全長[mm]", gt=0)
    slider_gap: float = Field(..., description="スライダギャップ[mm]", ge=0)
    slider_type: str = Field(..., min_length=1, description="スライダの種類", pattern="^(ショート|ロング)$")
    slider_count: int = Field(..., description="スライダ数", ge=2, le=128)
    circulation_axis_offset: float = Field(..., description="循環軸位置オフセット[mm]", ge=0)
    circulation_axis_stroke: float = Field(..., description="循環軸ストローク[mm]", gt=0)
    circulation_axis_speed: float = Field(..., description="循環軸速度[mm/s]", gt=0)
    circulation_axis_acc_decel: float = Field(..., description="循環軸加減速度[mm/s²]", gt=0)
    discharge_speed: float = Field(..., description="排出速度[mm/s]", gt=0)
    discharge_acc_decel: float = Field(..., description="排出加減速度[mm/s²]", gt=0)
    calculation_range: float = Field(..., description="計算範囲[s]", gt=0)
    control_pattern: int = Field(..., description="制御コントローラパターン", ge=1, le=2)
    return_trip_available: bool = Field(..., description="VTS復路有無")
    stop_positions: List[StopPositionItem] = Field(..., description="停止位置データリスト", min_items=0)


class CycleTimeCalculateResponse(BaseModel):
    """サイクルタイム計算レスポンススキーマ"""
    cycle_time: float = Field(..., description="サイクルタイム[s]")
    production_per_hour: float = Field(..., description="生産性[個/h]")
    production_per_8h: float = Field(..., description="生産数[個/8h]")
    total_laps: int = Field(..., description="全スライダ循環回数の合計値")
    calculation_time: float = Field(..., description="計算範囲[s]")