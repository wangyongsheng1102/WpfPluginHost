"""
PDF 報告用コンテキスト API の Pydantic スキーマ
"""
from datetime import date, datetime
from decimal import Decimal
from typing import Any, List, Optional

from pydantic import Field
from app.schemas.base import BaseModel


class PdfCoverData(BaseModel):
    """表紙用: タイトル、作成日、作成者"""
    title: str = Field("", description="表紙タイトル（例: 〇〇社構想設計）")
    creation_date: Optional[str] = Field(None, description="作成日 YYYY/MM/DD")
    creator: str = Field("", description="作成者名")


class PdfLayoutOption(BaseModel):
    """モーダル「レイアウト」選択肢"""
    layout_id: int
    layout_name: str = Field("", description="表示名（layout_info_name or レイアウト{id}）")
    project_id: int = 0
    finish_flg: Optional[bool] = None


class PdfCtLogOption(BaseModel):
    """モーダル「サイクルタイム情報」選択肢"""
    log_no: int
    log_name: str = Field("", description="表示名（例: ログ1）")


class PdfPartsListItem(BaseModel):
    """部品表1行: No, 分類, 名称, 形番, 商品コード, 数量"""
    no: int = 0
    category: str = ""
    name: str = ""
    model_number: str = Field("", description="形番")
    product_code: str = ""
    quantity: int = 0


class PdfInputConditionRow(BaseModel):
    """入力条件テーブル1行: 項目, 値, 単位"""
    item: str = ""
    value: str = ""
    unit: str = ""


class PdfProcessTableRow(BaseModel):
    """プロセス番号テーブル1行: 項目 + 各プロセス番号の値（キーは A, P1-1 等）"""
    item: str = ""
    values: dict = Field(default_factory=dict, description="process_no or 表示名 -> 値")


class PdfCalculationResult(BaseModel):
    """検討結果: 目標/予想 CT・スループット・時間効率、時間分解など"""
    target_cycle_time: Optional[Decimal] = None
    target_throughput: Optional[Decimal] = None
    calculation_range: Optional[str] = None
    work_load_count: Optional[int] = None
    slider_count: Optional[int] = None
    expected_cycle_time: Optional[Decimal] = None
    expected_throughput: Optional[Decimal] = None
    expected_time_efficiency: Optional[Decimal] = None
    time_breakdown: Optional[List[dict]] = Field(None, description="作業/待ち/移動の時間分解")
    ct_result_image: Optional[str] = Field(
        None,
        description="CT計算結果画像（t_ct_log_header.ct_result_image / Base64 や data URL）",
    )


class PdfReportContextResponse(BaseModel):
    """GET /api/v1/pdf-report/context のレスポンス"""
    cover: PdfCoverData = Field(default_factory=PdfCoverData)
    layout_list: List[PdfLayoutOption] = Field(default_factory=list, description="モーダル「レイアウト」一覧")
    ct_log_list: List[PdfCtLogOption] = Field(default_factory=list, description="モーダル「サイクルタイム情報」一覧")
    parts_list: List[PdfPartsListItem] = Field(default_factory=list, description="部品表")
    input_conditions: List[PdfInputConditionRow] = Field(default_factory=list, description="入力条件テーブル")
    process_table: List[PdfProcessTableRow] = Field(default_factory=list, description="プロセス番号テーブル")
    calculation_result: Optional[PdfCalculationResult] = Field(None, description="検討結果")
    vts_diagram: Optional[str] = Field(None, description="VTS構成図画像 Base64（data:image/png;base64,... または生 base64）")

    class Config:
        populate_by_name = True
