"""
製品関連のPydanticスキーマ

※ VTS Configurator 用の最新テーブル定義（m_Product, m_ProductType）に合わせ、
  ここでは vts 用スキーマ `MProductResponse` をラップして公開する。
"""
from pydantic import BaseModel
from typing import List

from app.schemas.vts import MProductResponse


# VTS 用の製品レスポンスをそのまま公開
ProductResponse = MProductResponse


class ProductListResponse(BaseModel):
    """製品リストレスポンススキーマ（m_Product ベース）"""
    total: int
    items: List[ProductResponse]
