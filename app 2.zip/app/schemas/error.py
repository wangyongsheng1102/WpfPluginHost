"""
エラーレスポンススキーマ
統一されたエラーレスポンス形式を定義
"""
from pydantic import BaseModel, Field
from typing import Optional, Dict, Any


class ErrorResponse(BaseModel):
    """統一されたエラーレスポンス形式"""
    error_code: str = Field(..., description="エラーコード（例: SESSION_NOT_FOUND）")
    message: str = Field(..., description="国際化されたエラーメッセージ")
    language: str = Field(..., description="使用された言語コード（ja/en）")
    details: Optional[Dict[str, Any]] = Field(None, description="追加のエラー詳細情報（オプション）")

    class Config:
        json_schema_extra = {
            "example": {
                "error_code": "SESSION_NOT_FOUND",
                "message": "セッションが見つかりませんまたは期限切れです",
                "language": "ja"
            }
        }
