"""
認証関連のPydanticスキーマ
"""
from pydantic import EmailStr, Field, validator
from app.schemas.base import BaseModel
from typing import Optional


class LoginRequest(BaseModel):
    """ログインリクエスト"""
    email: EmailStr
    password: str = Field(..., min_length=1, description="パスワード")


class PasswordResetRequest(BaseModel):
    """パスワードリセットリクエスト（ステップ1：メールアドレス入力）"""
    email: EmailStr


class PasswordResetConfirm(BaseModel):
    """パスワードリセット確認（ステップ2：新しいパスワード設定）"""
    token: str = Field(..., min_length=1, description="リセットトークン")
    new_password: str = Field(..., min_length=8)
    confirm_password: str = Field(..., min_length=8)
    
    @validator('confirm_password')
    def passwords_match(cls, v, values):
        if 'new_password' in values and v != values['new_password']:
            raise ValueError('パスワードが一致しません')
        return v


class RegistrationRequest(BaseModel):
    """ユーザー登録リクエスト（ステップ1：メールアドレスとユーザー名入力）"""
    email: EmailStr
    confirm_email: EmailStr
    username: str = Field(..., min_length=3, max_length=50)
    
    @validator('confirm_email')
    def emails_match(cls, v, values):
        if 'email' in values and v != values['email']:
            raise ValueError('メールアドレスが一致しません')
        return v


class RegistrationComplete(BaseModel):
    """登録完了（ステップ2：パスワード設定）"""
    token: str = Field(..., min_length=1, description="登録トークン")
    password: str = Field(..., min_length=8)
    confirm_password: str = Field(..., min_length=8)
    
    @validator('confirm_password')
    def passwords_match(cls, v, values):
        if 'password' in values and v != values['password']:
            raise ValueError('パスワードが一致しません')
        return v


class ChangePasswordRequest(BaseModel):
    """パスワード変更リクエスト"""
    current_password: str = Field(..., min_length=1, description="現在のパスワード")
    new_password: str = Field(..., min_length=8)
    confirm_password: str = Field(..., min_length=8)
    
    @validator('confirm_password')
    def passwords_match(cls, v, values):
        if 'new_password' in values and v != values['new_password']:
            raise ValueError('パスワードが一致しません')
        return v


class UpdateProfileRequest(BaseModel):
    """プロフィール更新リクエスト"""
    username: Optional[str] = Field(None, min_length=3, max_length=50)
    full_name: Optional[str] = Field(None, max_length=100)
    language: Optional[str] = Field(None, pattern="^(ja|en)$")


class RefreshTokenRequest(BaseModel):
    """トークンリフレッシュリクエスト"""
    refresh_token: str = Field(..., min_length=1, description="リフレッシュトークン")


# ----- m_user（vts）用：登録・ログイン・メール認証 -----


class MUserLoginRequest(BaseModel):
    """m_user ログインリクエスト（メール + パスワード）"""
    mail: str = Field(..., min_length=1, description="メールアドレス（m_user.mail_address）")
    password: str = Field(..., min_length=1, description="パスワード（明文）")


class MUserInfo(BaseModel):
    """m_user 情報（レスポンス用）"""
    user_id: str
    mail_address: Optional[str] = None
    user_name: Optional[str] = None
    role_id: int
    language_cd: Optional[str] = None
    email_verified: bool = False

    model_config = {"from_attributes": True}


class MUserLoginResponse(BaseModel):
    """m_user ログイン成功レスポンス（トークンなし）"""
    user: MUserInfo
