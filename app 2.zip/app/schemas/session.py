"""
セッション関連のPydanticスキーマ
"""
from pydantic import BaseModel, Field
from typing import Optional, Dict, Any, List
from datetime import datetime


class SessionBase(BaseModel):
    """セッション基本スキーマ"""
    context: Optional[str] = Field(None, max_length=50, description="セッションのコンテキスト")
    language: str = Field("ja", pattern="^(ja|en)$", description="言語")


class SessionCreate(SessionBase):
    """セッション作成スキーマ"""
    pass


class StepContent(BaseModel):
    """ステップ内容スキーマ"""
    step_type: str = Field(..., min_length=1, description="ステップタイプ（designer, cycle_time, configurator等）")
    content: Dict[str, Any] = Field(..., description="ステップの具体的な内容")
    metadata: Optional[Dict[str, Any]] = Field(None, description="追加のメタデータ")


class SessionStepUpdate(BaseModel):
    """ステップデータ更新スキーマ"""
    step: int = Field(..., ge=1, description="ステップ番号")
    step_type: str = Field(..., min_length=1, description="ステップタイプ（designer, cycle_time, configurator等）")
    content: Dict[str, Any] = Field(..., description="ステップの具体的な内容")
    metadata: Optional[Dict[str, Any]] = Field(None, description="追加のメタデータ")
    mark_completed: bool = Field(False, description="このステップを完了としてマークするか")


class SessionStepInfo(BaseModel):
    """ステップ情報スキーマ"""
    step: int
    step_type: str
    content: Dict[str, Any]
    metadata: Optional[Dict[str, Any]] = None
    is_completed: bool
    completed_at: Optional[datetime] = None
    updated_at: datetime


class SessionStepResponse(BaseModel):
    """ステップデータレスポンススキーマ"""
    step: int
    step_type: str
    content: Dict[str, Any]
    metadata: Optional[Dict[str, Any]] = None
    is_completed: bool
    completed_at: Optional[datetime] = None
    updated_at: datetime


class SessionResponse(SessionBase):
    """セッションレスポンススキーマ"""
    id: int
    session_id: str
    user_id: Optional[int] = None
    step_data: Dict[int, Dict[str, Any]]  # {step: {step_type, content, metadata, ...}}形式
    current_step: int
    completed_steps: List[int]
    created_at: datetime
    updated_at: datetime
    expires_at: datetime

    class Config:
        from_attributes = True


class SessionSummaryResponse(BaseModel):
    """セッションサマリーレスポンススキーマ"""
    session_id: str
    current_step: int
    completed_steps: List[int]
    total_steps: int
    step_types: List[str] = Field(..., description="セッション内のステップタイプ一覧")
    expires_at: datetime


class SessionStepsByTypeResponse(BaseModel):
    """タイプ別ステップレスポンススキーマ"""
    step_type: str
    steps: List[SessionStepInfo]


class SessionListResponse(BaseModel):
    """セッションリストレスポンススキーマ"""
    total: int
    items: List[SessionResponse]


class SessionAssociateRequest(BaseModel):
    """セッション紐づけリクエストスキーマ"""
    session_id: str = Field(..., min_length=1, description="紐づけるセッションID")
