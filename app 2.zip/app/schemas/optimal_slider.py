"""
最適スライダ数API用スキーマ（参照: CalculationOptimalSliderNumber.py）
入力は「レイアウト関連の 11 パラメータ + manufacturing_process_list」のみとする（参照スクリプトと同等）。
"""
from pydantic import BaseModel, Field
from typing import List


# ----- リクエスト：レイアウト関連パラメータ + 製造プロセス情報 -----

class ManufacturingProcessListItem(BaseModel):
    """製造プロセス情報の1件（STEP3、最大256件）"""
    process_number: str = Field(..., description="プロセス番号")
    process_name: str = Field(..., description="プロセス名称")
    process_ct_time: float = Field(..., description="プロセスCT動作時間[s]", ge=0)
    process_ct_time_tolerance: float = Field(..., description="プロセスCT動作時間公差[s]", ge=0)
    settling_time: float = Field(..., description="静定時間[s]", ge=0)
    process_stop_position: float = Field(..., description="プロセス停止位置[mm]", ge=0)
    distance_between_processes: float = Field(..., description="プロセス間の距離[mm]", ge=0)
    prohibited_area_during_process: float = Field(..., description="プロセス中禁止領域[mm]", ge=0)
    move_speed_to_this_process: float = Field(..., description="本プロセスへの移動速度[mm/s]", ge=0, le=3000)
    move_accel_to_this_process: float = Field(..., description="本プロセスへの移動加減速度[mm/s²]", ge=0, le=9000)


class OptimalSliderRequest(BaseModel):
    """
    最適スライダ数計算リクエスト（参照スクリプトの入力セル In[3]・In[6] に相当）。
    入力は「レイアウト関連の 11 パラメータ + 製造プロセス一覧」のみとする（空配列可）。
    """
    vts_length: float = Field(..., description="VTS全長[mm]", gt=0)
    cyclical_axis_offset: float = Field(..., description="循環軸オフセット[mm]", ge=0)
    cyclical_axis_stroke: float = Field(..., description="循環軸ストローク[mm]", ge=0)
    slider_length: float = Field(..., description="スライダ長さ[mm]", gt=0)
    work_size_w: float = Field(..., description="ワークサイズ W[mm]", ge=0)
    pallet_size_w: float = Field(..., description="パレットサイズ W[mm]", ge=0)
    controller_pattern: int = Field(..., description="制御コントローラパターン (1 or 2)", ge=1, le=2)
    cyclical_axis_speed: float = Field(..., description="循環軸速度[mm/s]", ge=0, le=3000)
    cyclical_axis_accel: float = Field(..., description="循環軸加減速度[mm/s²]", ge=0, le=9000)
    eject_or_retract_speed: float = Field(..., description="排出/引込速度[mm/s]", ge=0, le=3000)
    eject_or_retract_accel: float = Field(..., description="排出/引込加減速度[mm/s²]", ge=0, le=9000)
    manufacturing_process_list: List[ManufacturingProcessListItem] = Field(
        default_factory=list,
        description="製造プロセス情報（配列、最大256）。空配列可。",
        max_length=256,
    )


# ----- レスポンス：参照スクリプトの print 関数出力に相当 -----

class StopPositionOutputItem(BaseModel):
    """停止位置情報（計算後）。print(stop_position) による表示内容。"""
    number: int = Field(..., description="番号")
    processing_time: float = Field(..., description="処理時間[s]（移動時間、算出値）")
    position: float = Field(..., description="位置[mm]")
    max_speed: float = Field(..., description="最大速度[mm/s]")
    acceleration: float = Field(..., description="加減速度[mm/s²]")
    distance: float = Field(..., description="前方までの距離[mm]（算出値）")
    circulation_axis_flag: int = Field(..., description="循環軸有無 (0 or 1)")


class StopTimeOutputItem(BaseModel):
    """停止時間リストの 1 件（統合後）。print(stop_time) による表示内容。"""
    number: int = Field(..., description="番号")
    processing_time: float = Field(..., description="処理時間[s]")
    position: float = Field(0, description="位置（作業ステーションは 0）")
    max_speed: float = Field(0, description="最大速度（作業ステーションは 0）")
    acceleration: float = Field(0, description="加減速度（作業ステーションは 0）")
    distance: float = Field(0, description="距離（作業ステーションは 0）")
    circulation_axis_flag: int = Field(0, description="循環軸有無")


class DivisionLoopItem(BaseModel):
    """割り数ループの 1 ステップ。参照スクリプトにおける 4 行分の print 出力。"""
    division_count: int = Field(..., description="割り数カウント=スライダ数")
    other_processing_time: float = Field(..., description="他処理時間[s]")
    temp_other_processing_time: float = Field(..., description="他処理時間（一時保存）=サイクルタイム[s]")
    max_processing_time: float = Field(..., description="最大処理時間[s]")


class OptimalSliderResponse(BaseModel):
    """最適スライダ数計算レスポンス（参照スクリプトの print 出力一式に工程情報を追加）"""
    stop_position_list_num: int = Field(..., description="停止位置情報のリスト登録数")
    stop_position_list: List[StopPositionOutputItem] = Field(
        ..., description="停止位置情報リスト（計算後：番号・処理時間・位置・最大速度・加減速度・距離・循環軸有無）"
    )
    stop_time_list: List[StopTimeOutputItem] = Field(
        ..., description="停止時間リスト（統合後。最大処理時間算出用）"
    )
    max_processing_time: float = Field(..., description="最大処理時間[s]")
    total_processing_time: float = Field(..., description="処理時間合計値[s]")
    other_processing_time: float = Field(..., description="他処理時間[s]")
    division_loop: List[DivisionLoopItem] = Field(
        ..., description="割り数ループ（各ステップの4値）"
    )
    optimal_slider_count: int = Field(..., description="最適スライダ数")
    optimum_slider_count_total_value: int = Field(
        ..., description="最適スライダ数の合計値[個]（仕様書出力用）"
    )
    start_positions: List[float] = Field(
        ..., description="各スライダの開始位置[mm]（工程追加、1 周を等分割）"
    )
