from decimal import Decimal

from pydantic import BaseModel as PydanticBaseModel, ConfigDict


def _serialize_decimal(value: Decimal) -> int | float:
    # Normalize trailing zeros (e.g. 12.0000 -> 12, 12.3400 -> 12.34)
    normalized = value.normalize()
    if normalized.is_zero():
        return 0
    if normalized == normalized.to_integral_value():
        return int(normalized)
    return float(normalized)


class BaseModel(PydanticBaseModel):
    model_config = ConfigDict(
        json_encoders={Decimal: _serialize_decimal},
    )
