"""
THK VTS Configurator バックエンド
FastAPI アプリケーションエントリーポイント
"""
from fastapi import FastAPI, HTTPException, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from sqlalchemy.exc import IntegrityError

from app.core.config import settings
from app.core.database import Base, engine

from app.core.logger import setup_logging
import logging

setup_logging()

logger = logging.getLogger(__name__)

# データベーステーブルを作成（失敗してもアプリケーションは起動する）
try:
    Base.metadata.create_all(bind=engine)
except Exception as e:
    logger.warning(f"データベース初期化に失敗しました（一部機能が利用できません）: {e}")

app = FastAPI(
    title="THK VTS Configurator API",
    description="THK 次世代リニア搬送システム API",
    version="2.0.0",
    docs_url="/docs",
    redoc_url="/redoc",
)

# CORS設定
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.CORS_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# API アクセスログミドルウェア（リクエスト/レスポンスの詳細を記録）
from app.middleware.api_logging import APILoggingMiddleware
app.add_middleware(APILoggingMiddleware)

# m_user（vts）登録・ログイン・メール認証・ログアウト（/api/v1/auth/local/*）
from app.api import m_user_auth
app.include_router(m_user_auth.router, prefix="/api/v1/auth/local", tags=["認証（m_user）"])

# ホーム・プロジェクト・デザイナー・比較（画面別 context + CRUD）
from app.api import home
app.include_router(home.router, prefix="/api/v1/home", tags=["ホーム"])
from app.api import projects
app.include_router(projects.router, prefix="/api/v1/projects", tags=["プロジェクト"])
from app.api import designer
app.include_router(designer.router, prefix="/api/v1/designer", tags=["デザイナー"])
from app.api import compare
app.include_router(compare.router, prefix="/api/v1/compare", tags=["比較"])

# サイクルタイム計算ルーター
from app.api import cycle_time
app.include_router(cycle_time.router, prefix="/api/v1/cycle-time", tags=["サイクルタイム計算"])

# 最適スライダ数ルーター（cycle_time とは独立）
from app.api import optimal_slider
app.include_router(optimal_slider.router, prefix="/api/v1/optimal-slider", tags=["最適スライダ数"])

# セッション管理ルーター（多ステップフローの一時データ管理）
from app.api import session
app.include_router(session.router, prefix="/api/v1/sessions", tags=["セッション管理"])

# PDF報告用コンテキスト（テンプレートデータ取得）
from app.api import pdf_report
app.include_router(pdf_report.router, prefix="/api/v1/pdf-report", tags=["PDF報告"])

# 製品ルーター
from app.api import products
app.include_router(products.router, prefix="/api/v1/products", tags=["製品"])

@app.get("/")
async def root():
    """ルートパス"""
    return {"message": "THK 次世代リニア搬送システム API", "version": "2.0.0"}


@app.get("/health")
async def health_check():
    """ヘルスチェック"""
    return {"status": "healthy"}


@app.exception_handler(IntegrityError)
async def integrity_exception_handler(request: Request, exc: IntegrityError):
    """未捕捉の IntegrityError → FK / 保存競合（500 にしない）"""
    from app.core.db_integrity import integrity_error_to_app_exception
    from app.core.errors import get_error_message, get_language_from_request

    app_exc = integrity_error_to_app_exception(exc)
    language = get_language_from_request(request)
    error_message = get_error_message(app_exc.error_code, language)
    return JSONResponse(
        status_code=app_exc.status_code,
        content={
            "error_code": app_exc.error_code.value,
            "message": error_message,
            "language": language,
        },
    )


@app.exception_handler(Exception)
async def global_exception_handler(request, exc):
    """グローバル例外処理（統一されたエラーレスポンス形式）"""
    from app.core.errors import ErrorCode, get_error_message, get_language_from_request
    from app.core.exceptions import BaseAppException
    
    # BaseAppException は統一された形式で処理
    if isinstance(exc, BaseAppException):
        language = get_language_from_request(request)
        error_message = get_error_message(exc.error_code, language)
        
        return JSONResponse(
            status_code=exc.status_code,
            content={
                "error_code": exc.error_code.value,
                "message": error_message,
                "language": language
            }
        )
    
    # HTTPExceptionはそのまま返す（既に統一された形式）
    if isinstance(exc, HTTPException):
        return JSONResponse(
            status_code=exc.status_code,
            content=exc.detail if isinstance(exc.detail, dict) else {
                "error_code": "UNKNOWN_ERROR",
                "message": str(exc.detail),
                "language": get_language_from_request(request)
            }
        )
    
    # その他の例外は統一された形式で返す
    language = get_language_from_request(request)
    error_message = get_error_message(ErrorCode.INTERNAL_SERVER_ERROR, language)
    
    return JSONResponse(
        status_code=500,
        content={
            "error_code": ErrorCode.INTERNAL_SERVER_ERROR.value,
            "message": error_message,
            "language": language
        },
    )


if __name__ == "__main__":
    import uvicorn

    uvicorn.run(app, host="0.0.0.0", port=8000)
    logger.info("FastAPI アプリケーションが起動しました")
