"""
国際化モジュール
"""
from app.i18n.loader import i18n_loader

__all__ = ["i18n_loader"]
