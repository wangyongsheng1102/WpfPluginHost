"""
国際化ローダー
YAML ファイルから翻訳テキストを読み込む
"""
import yaml
from pathlib import Path
from typing import Dict, Optional, Any
import logging

logger = logging.getLogger(__name__)


class I18nLoader:
    """国際化ローダー"""
    
    def __init__(self):
        self._translations: Dict[str, Dict] = {}
        self._load_all()
    
    def _load_all(self):
        """すべての言語ファイルを読み込む"""
        # i18n ディレクトリのパス
        i18n_dir = Path(__file__).parent
        
        # サポートする言語
        languages = ["ja", "en"]
        
        for lang in languages:
            self._translations[lang] = {}
            
            # errors ディレクトリから読み込み
            errors_file = i18n_dir / "errors" / f"{lang}.yaml"
            if errors_file.exists():
                try:
                    with open(errors_file, "r", encoding="utf-8") as f:
                        errors_data = yaml.safe_load(f)
                        if errors_data:
                            self._translations[lang]["errors"] = errors_data
                except Exception as e:
                    logger.error(f"Failed to load errors file {errors_file}: {e}")
            
            # locales ディレクトリから読み込み
            locales_file = i18n_dir / "locales" / f"{lang}.yaml"
            if locales_file.exists():
                try:
                    with open(locales_file, "r", encoding="utf-8") as f:
                        locales_data = yaml.safe_load(f)
                        if locales_data:
                            # errors 以外のデータをマージ
                            for key, value in locales_data.items():
                                if key != "errors":
                                    self._translations[lang][key] = value
                except Exception as e:
                    logger.error(f"Failed to load locales file {locales_file}: {e}")
    
    def _get_nested_value(self, data: Dict, key_path: str) -> Optional[Any]:
        """
        ネストされた辞書から値を取得
        
        Args:
            data: 辞書データ
            key_path: ドット区切りのキーパス（例: "errors.auth.invalid_credentials"）
            
        Returns:
            値、または None
        """
        keys = key_path.split(".")
        current = data
        
        for key in keys:
            if isinstance(current, dict) and key in current:
                current = current[key]
            else:
                return None
        
        return current
    
    def get(self, key: str, language: str = "ja", **kwargs: Any) -> str:
        """
        翻訳テキストを取得
        
        Args:
            key: キーパス（例: "errors.auth.invalid_credentials" または "common.loading"）
            language: 言語コード（ja/en）
            **kwargs: メッセージ内のプレースホルダーを置換する値
            
        Returns:
            翻訳されたテキスト
        """
        if language not in self._translations:
            language = "ja"  # フォールバック
        
        translations = self._translations[language]
        value = self._get_nested_value(translations, key)
        
        if value is None:
            # フォールバック: 日本語を試す
            if language != "ja":
                ja_translations = self._translations.get("ja", {})
                value = self._get_nested_value(ja_translations, key)
            
            # それでも見つからない場合
            if value is None:
                logger.warning(f"Translation key not found: {key} (language: {language})")
                return key  # キーをそのまま返す
        
        # 文字列でない場合は文字列に変換
        if not isinstance(value, str):
            value = str(value)
        
        # プレースホルダーを置換
        try:
            return value.format(**kwargs)
        except KeyError:
            # プレースホルダーが不足している場合、そのまま返す
            return value
    
    def get_error(self, error_code: str, language: str = "ja", **kwargs: Any) -> str:
        """
        エラーメッセージを取得
        
        Args:
            error_code: エラーコード（例: "auth.invalid_credentials"）
            language: 言語コード（ja/en）
            **kwargs: メッセージ内のプレースホルダーを置換する値
            
        Returns:
            エラーメッセージ
        """
        # ErrorCode の値からキーパスを構築
        # 例: "AUTH_INVALID_CREDENTIALS" -> "errors.auth.invalid_credentials"
        key_path = f"errors.{error_code.lower()}"
        return self.get(key_path, language, **kwargs)


# シングルトンインスタンス
i18n_loader = I18nLoader()
