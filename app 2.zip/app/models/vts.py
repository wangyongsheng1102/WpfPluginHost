"""
VTS Configurator 業務モデル
DDL: backend/docs/ddl/001_vts_tables.sql
"""
from sqlalchemy import Column, BigInteger, String, Boolean, DateTime, Numeric, Text, Integer, ForeignKey, ForeignKeyConstraint
from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func

from app.core.database import Base


class Project(Base):
    """t_Project: プロジェクト情報"""
    __tablename__ = "t_project"

    project_id = Column(BigInteger, primary_key=True, autoincrement=True)
    project_name = Column(String(255), nullable=False)
    del_flg = Column(Boolean, default=False)
    create_date = Column(DateTime(timezone=True), server_default=func.now())
    create_user = Column(String(100))
    update_date = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())
    update_user = Column(String(100))

    layouts = relationship("Layout", back_populates="project", cascade="all, delete-orphan")


class Layout(Base):
    """t_Layout: レイアウト情報"""
    __tablename__ = "t_layout"

    project_id = Column(BigInteger, ForeignKey("t_project.project_id", ondelete="CASCADE"), primary_key=True)
    layout_id = Column(BigInteger, primary_key=True)
    vts_return_trip = Column(Boolean)
    circulation_type = Column(String(50))
    module_direction = Column(String(50))
    footprint_limit_x = Column(Numeric(12, 4))
    footprint_limit_y = Column(Numeric(12, 4))
    footprint_limit_z = Column(Numeric(12, 4))
    work_name = Column(String(200))
    work_size_w = Column(Numeric(12, 4))
    work_size_l = Column(Numeric(12, 4))
    work_size_d = Column(Numeric(12, 4))
    work_mass = Column(Numeric(12, 4))
    work_products_per_pallet = Column(Integer)
    pallet_w = Column(Numeric(12, 4))
    pallet_l = Column(Numeric(12, 4))
    pallet_d = Column(Numeric(12, 4))
    pallet_mass = Column(Numeric(12, 4))
    slider_type = Column(String(10))
    process_distance_type = Column(String(50))
    circulation_axis_full_length = Column(Numeric(12, 4))
    circulation_axis_offset = Column(Numeric(12, 4))
    circulation_axis_speed = Column(Numeric(12, 4))
    circulation_axis_acceleration = Column(Numeric(12, 4))
    circulation_axis_sensor = Column(String(50))
    circulation_axis_lead = Column(Numeric(12, 4))
    circulation_name = Column(String(100))
    circulation_type_attr = Column(String(50))
    circulation_guide = Column(String(50))
    circulation_stroke = Column(Numeric(12, 4))
    circulation_motor_set_direction = Column(String(50))
    eor_speed = Column(Numeric(12, 4))
    eor_acceleration = Column(Numeric(12, 4))
    control_controller_pattern = Column(String(20))
    finish_flg = Column(Boolean, default=False)
    position_or_distance = Column(String(50))
    vts_total_length = Column(Numeric(12, 4))
    module_count = Column(Integer)
    del_flg = Column(Boolean, default=False)
    create_date = Column(DateTime(timezone=True), server_default=func.now())
    create_user = Column(String(100))
    update_date = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())
    update_user = Column(String(100))

    project = relationship("Project", back_populates="layouts")
    layout_design = relationship("LayoutDesign", back_populates="layout", uselist=False, cascade="all, delete-orphan")
    processes = relationship("Process", back_populates="layout", cascade="all, delete-orphan")
    product_list = relationship("ProductList", back_populates="layout", cascade="all, delete-orphan")
    ct_log_headers = relationship("CTLogHeader", back_populates="layout", cascade="all, delete-orphan")


class LayoutDesign(Base):
    """t_LayoutDesign: レイアウトデザイン"""
    __tablename__ = "t_layout_design"

    project_id = Column(BigInteger, primary_key=True)
    layout_id = Column(BigInteger, primary_key=True)
    layout_image = Column(Text)
    layout_design = Column(JSONB)
    del_flg = Column(Boolean, default=False)
    create_date = Column(DateTime(timezone=True), server_default=func.now())
    create_user = Column(String(100))
    update_date = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())
    update_user = Column(String(100))

    __table_args__ = (
        ForeignKeyConstraint(
            ["project_id", "layout_id"],
            ["t_layout.project_id", "t_layout.layout_id"],
            ondelete="CASCADE"
        ),
    )

    layout = relationship("Layout", back_populates="layout_design")


class Process(Base):
    """t_Process: プロセス情報（PK: process_no）"""
    __tablename__ = "t_process"

    project_id = Column(BigInteger, primary_key=True)
    layout_id = Column(BigInteger, primary_key=True)
    process_no = Column(Integer, primary_key=True)
    truck_no = Column(Integer, primary_key=True)
    log_no = Column(Integer, primary_key=True)
    process_name = Column(String(200))
    process_time = Column(Numeric(12, 4))
    process_time_tolerance = Column(Numeric(12, 4))
    settling_time = Column(Numeric(12, 4))
    process_stop_position = Column(Numeric(12, 4))
    process_forbidden_area = Column(JSONB)
    move_to_process_speed = Column(Numeric(12, 4))
    move_to_process_accel = Column(Numeric(12, 4))
    ct_check_result = Column(Integer)
    wait_time = Column(Numeric(12, 4))
    vts_move_time = Column(Numeric(12, 4))
    del_flg = Column(Boolean, default=False)
    create_date = Column(DateTime(timezone=True), server_default=func.now())
    create_user = Column(String(100))
    update_date = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())
    update_user = Column(String(100))

    __table_args__ = (
        ForeignKeyConstraint(
            ["project_id", "layout_id"],
            ["t_layout.project_id", "t_layout.layout_id"],
            ondelete="CASCADE"
        ),
    )

    layout = relationship("Layout", back_populates="processes")


class MProductType(Base):
    """m_ProductType: 製品種類マスタ"""
    __tablename__ = "m_product_type"

    product_type_id = Column(BigInteger, primary_key=True, autoincrement=True)
    product_type_name = Column(String(200), nullable=False)
    product_type_name_en = Column(String(200), nullable=True)
    sort_no = Column(Integer)
    del_flg = Column(Boolean, default=False)
    create_date = Column(DateTime(timezone=True), server_default=func.now())
    create_user = Column(String(100))
    update_date = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())
    update_user = Column(String(100))


class MProduct(Base):
    """m_Product: 製品情報マスタ（product_type_id で m_ProductType を参照）"""
    __tablename__ = "m_product"

    product_id = Column(BigInteger, primary_key=True, autoincrement=True)
    product_name = Column(String(200), nullable=False)
    product_name_en = Column(String(200), nullable=True)
    product_isome_image = Column(Text)
    product_side_view_image = Column(Text)
    product_top_view_image = Column(Text)
    product_type_id = Column(BigInteger, ForeignKey("m_product_type.product_type_id"), nullable=True)
    product_model = Column(String(100))
    product_code = Column(String(50))
    min_cycle_time = Column(Numeric(12, 4))
    stroke = Column(Numeric(12, 4))
    list_price = Column(Numeric(12, 2))
    del_flg = Column(Boolean, default=False)
    create_date = Column(DateTime(timezone=True), server_default=func.now())
    create_user = Column(String(100))
    update_date = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())
    update_user = Column(String(100))

    product_type_rel = relationship("MProductType", foreign_keys=[product_type_id])
    product_list_items = relationship("ProductList", back_populates="product")


class ProductList(Base):
    """t_ProductList: 部品一覧情報（PK: project_id, layout_id, product_id, cable_no）"""
    __tablename__ = "t_product_list"

    project_id = Column(BigInteger, primary_key=True)
    layout_id = Column(BigInteger, primary_key=True)
    product_id = Column(BigInteger, ForeignKey("m_product.product_id", ondelete="RESTRICT"), primary_key=True)
    cable_no = Column(String(50), primary_key=True)
    quantity = Column(Integer, default=1)
    del_flg = Column(Boolean, default=False)
    create_date = Column(DateTime(timezone=True), server_default=func.now())
    create_user = Column(String(100))
    update_date = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())
    update_user = Column(String(100))

    __table_args__ = (
        ForeignKeyConstraint(
            ["project_id", "layout_id"],
            ["t_layout.project_id", "t_layout.layout_id"],
            ondelete="CASCADE"
        ),
    )

    layout = relationship("Layout", back_populates="product_list")
    product = relationship("MProduct", back_populates="product_list_items")


class CTLogHeader(Base):
    """t_CTLogHeader: CT計算ログヘッダ"""
    __tablename__ = "t_ct_log_header"

    project_id = Column(BigInteger, primary_key=True)
    layout_id = Column(BigInteger, primary_key=True)
    log_no = Column(Integer, primary_key=True)
    target_cycle_time = Column(Numeric(12, 4))
    target_throughput = Column(Numeric(12, 4))
    calculation_range = Column(String(100))
    slider_count = Column(Integer)
    expected_ct = Column(Numeric(12, 4))
    expected_throughput = Column(Numeric(12, 4))
    expected_time_efficiency = Column(Numeric(12, 4))
    record_flg = Column(Boolean)
    ct_result_image = Column(Text)
    del_flg = Column(Boolean, default=False)
    create_date = Column(DateTime(timezone=True), server_default=func.now())
    create_user = Column(String(100))
    update_date = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())
    update_user = Column(String(100))

    __table_args__ = (
        ForeignKeyConstraint(
            ["project_id", "layout_id"],
            ["t_layout.project_id", "t_layout.layout_id"],
            ondelete="CASCADE"
        ),
    )

    layout = relationship("Layout", back_populates="ct_log_headers")
    details = relationship("CTLogDetail", back_populates="header", cascade="all, delete-orphan")


class CTLogDetail(Base):
    """t_CTLogDetail: CT計算ログ明細"""
    __tablename__ = "t_ct_log_detail"

    project_id = Column(BigInteger, primary_key=True)
    layout_id = Column(BigInteger, primary_key=True)
    log_no = Column(Integer, primary_key=True)
    log_detail_no = Column(Integer, primary_key=True)
    log_detail_name = Column(String(200))
    log_detail_value = Column(Text)
    del_flg = Column(Boolean, default=False)
    create_date = Column(DateTime(timezone=True), server_default=func.now())
    create_user = Column(String(100))
    update_date = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())
    update_user = Column(String(100))

    __table_args__ = (
        ForeignKeyConstraint(
            ["project_id", "layout_id", "log_no"],
            ["t_ct_log_header.project_id", "t_ct_log_header.layout_id", "t_ct_log_header.log_no"],
            ondelete="CASCADE"
        ),
    )

    header = relationship("CTLogHeader", back_populates="details")


class MUser(Base):
    """m_User: ユーザーマスタ"""
    __tablename__ = "m_user"

    user_id = Column(String(100), primary_key=True)
    role_id = Column(Integer, nullable=False)
    mail_address = Column(String(255))
    language_cd = Column(String(10))
    password = Column(String(255))
    user_name = Column(String(200))
    del_flg = Column(Boolean, default=False)
    email_verified = Column(Boolean, default=False)
    verification_token = Column(String(255))
    verification_token_expires = Column(DateTime(timezone=True))
    create_date = Column(DateTime(timezone=True), server_default=func.now())
    create_user = Column(String(100))
    update_date = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())
    update_user = Column(String(100))


class MSendHistory(Base):
    """m_SendHistory: メール送信履歴"""
    __tablename__ = "m_send_history"

    mail_address = Column(String(255), primary_key=True)
    event = Column(String(200), primary_key=True)
    sendtime = Column(DateTime(timezone=True), primary_key=True)


class MCommon(Base):
    """m_Common: 共通マスタ"""
    __tablename__ = "m_common"

    id = Column(BigInteger, primary_key=True)
    object_id = Column(String(100), primary_key=True)
    key = Column(String(200), nullable=False)
    name = Column(String(500), nullable=False)
    del_flg = Column(Boolean, default=False)
    create_date = Column(DateTime(timezone=True), server_default=func.now())
    create_user = Column(String(100))
    update_date = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())
    update_user = Column(String(100))


class MPrdUserUnique(Base):
    """m_PrdUserUnique: ユーザーユニーク製品マスタ"""
    __tablename__ = "m_prd_user_unique"

    layout_info_id = Column(BigInteger, primary_key=True, autoincrement=True)
    layout_info_name = Column(String(200), nullable=False)
    min_cycle_time = Column(Numeric(12, 4))
    layout_image = Column(Text)
    layout_info = Column(JSONB)
    del_flg = Column(Boolean, default=False)
    create_date = Column(DateTime(timezone=True), server_default=func.now())
    create_user = Column(String(100))
    update_date = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())
    update_user = Column(String(100))
