"""
セッションモデル（多ステップフローの一時データ保存用）
"""
from sqlalchemy import Column, Integer, String, JSON, DateTime
from sqlalchemy.sql import func
from datetime import datetime, timedelta
from typing import Dict, Any, Optional
from app.core.database import Base
from app.core.config import settings


class Session(Base):
    """
    セッションモデル（多ステップフローの一時データ保存）
    
    step_data構造:
    {
        step_number: {
            "step_type": "designer" | "cycle_time" | "configurator" | ...,
            "content": {...},  # ステップの具体的な内容
            "metadata": {...},  # 追加のメタデータ（オプション）
            "completed_at": "2026-01-28T10:00:00Z",  # 完了時刻
            "updated_at": "2026-01-28T10:00:00Z"   # 更新時刻
        }
    }
    """
    __tablename__ = "sessions"

    id = Column(Integer, primary_key=True, index=True)
    session_id = Column(String(100), unique=True, index=True, nullable=False)  # セッションID（外部公開用）
    user_id = Column(String(100), nullable=True, index=True)  # m_user.user_id（オプション、未ログイン時はNULL）
    
    # セッションデータ
    step_data = Column(JSON, nullable=False, default=dict)  # 各ステップの詳細データ（{step: {step_type, content, ...}}形式）
    current_step = Column(Integer, default=1, nullable=False)  # 現在のステップ
    completed_steps = Column(JSON, nullable=False, default=list)  # 完了したステップのリスト
    
    # メタデータ
    context = Column(String(50), nullable=True, index=True)  # セッションのコンテキスト（例: "configurator"）
    language = Column(String(10), default="ja", nullable=False)  # 言語
    
    # タイムスタンプ
    created_at = Column(DateTime(timezone=True), server_default=func.now(), nullable=False)
    updated_at = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now(), nullable=False)
    expires_at = Column(DateTime(timezone=True), nullable=False, index=True)  # 有効期限

    def __repr__(self):
        return f"<Session(id={self.id}, session_id={self.session_id}, current_step={self.current_step})>"
    
    def is_expired(self) -> bool:
        """セッションが期限切れかどうかをチェック"""
        from datetime import timezone
        now = datetime.now(timezone.utc)
        if self.expires_at.tzinfo is None:
            # タイムゾーン情報がない場合はUTCとして扱う
            expires_utc = self.expires_at.replace(tzinfo=timezone.utc)
        else:
            expires_utc = self.expires_at.astimezone(timezone.utc)
        return now > expires_utc
    
    def update_expiry(self, hours: int = None):
        """有効期限を更新"""
        from datetime import timezone
        if hours is None:
            hours = settings.SESSION_EXPIRE_HOURS
        self.expires_at = datetime.now(timezone.utc) + timedelta(hours=hours)
    
    def get_steps_by_type(self, step_type: str) -> Dict[int, Dict[str, Any]]:
        """指定されたタイプのステップを取得"""
        result = {}
        step_data = self.step_data or {}
        for step_num, step_info in step_data.items():
            if isinstance(step_info, dict) and step_info.get("step_type") == step_type:
                result[step_num] = step_info
        return result
    
    def get_step_info(self, step: int) -> Optional[Dict[str, Any]]:
        """指定されたステップの情報を取得"""
        step_data = self.step_data or {}
        return step_data.get(step)
