"""
カスタム例外クラス
統一された例外処理アーキテクチャ
"""
from typing import Optional
from fastapi import status
from app.core.errors import ErrorCode


def _get_status_code_from_error_code(error_code: ErrorCode) -> int:
    """
    ErrorCode から HTTP ステータスコードを自動判定
    
    Args:
        error_code: ErrorCode 列挙値
        
    Returns:
        HTTP ステータスコード
    """
    code_value = error_code.value
    
    # マッピングルール
    if code_value.endswith("_NOT_FOUND"):
        return status.HTTP_404_NOT_FOUND
    elif code_value.endswith("_DUPLICATE"):
        return status.HTTP_409_CONFLICT
    elif code_value.endswith("_EMPTY") or code_value.endswith("_INVALID"):
        return status.HTTP_400_BAD_REQUEST
    elif code_value.endswith("_EXPIRED") or code_value.endswith("_REQUIRED"):
        return status.HTTP_401_UNAUTHORIZED
    elif code_value.endswith("_PERMISSION_DENIED"):
        return status.HTTP_403_FORBIDDEN
    else:
        return status.HTTP_400_BAD_REQUEST


class BaseAppException(Exception):
    """すべてのアプリケーション例外の基底クラス"""
    
    def __init__(
        self,
        error_code: ErrorCode,
        message: Optional[str] = None,
        status_code: Optional[int] = None
    ):
        """
        Args:
            error_code: エラーコード
            message: カスタムメッセージ（省略時は error_code から自動取得）
            status_code: HTTP ステータスコード（省略時は error_code から自動判定）
        """
        self.error_code = error_code
        self.message = message
        self.status_code = status_code or _get_status_code_from_error_code(error_code)
        super().__init__(message or error_code.value)


# ============================================================================
# 領域別例外基底クラス
# ============================================================================

class ProjectError(BaseAppException):
    """プロジェクト関連の例外基底クラス"""
    pass


class LayoutError(BaseAppException):
    """レイアウト関連の例外基底クラス"""
    pass


class ProcessError(BaseAppException):
    """プロセス関連の例外基底クラス"""
    pass


class ProductListError(BaseAppException):
    """部品表関連の例外基底クラス"""
    pass


class CTLogError(BaseAppException):
    """CTログ関連の例外基底クラス"""
    pass


class DesignerError(BaseAppException):
    """デザイナー関連の例外基底クラス"""
    pass


class CycleTimeError(BaseAppException):
    """サイクルタイム関連の例外基底クラス"""
    pass


class CompareError(BaseAppException):
    """比較関連の例外基底クラス"""
    pass


class ProductError(BaseAppException):
    """製品関連の例外基底クラス"""
    pass


class SessionError(BaseAppException):
    """セッション関連の例外基底クラス"""
    pass


class AuthError(BaseAppException):
    """認証関連の例外基底クラス"""
    pass


class UserError(BaseAppException):
    """ユーザー関連の例外基底クラス"""
    pass


class ConfigError(BaseAppException):
    """コンフィギュレーション関連の例外基底クラス"""
    pass


# ============================================================================
# プロジェクト関連の例外
# ============================================================================

class ProjectNotFoundError(ProjectError):
    """プロジェクトが見つからない"""
    
    def __init__(self, message: Optional[str] = None):
        super().__init__(ErrorCode.PROJECT_NOT_FOUND, message)


class ProjectNameDuplicateError(ProjectError):
    """同一ユーザー内でプロジェクト名が重複している（DB 一意制約違反）"""
    
    def __init__(self, message: Optional[str] = None):
        super().__init__(ErrorCode.PROJECT_NAME_DUPLICATE, message)


class ProjectNameEmptyError(ProjectError):
    """プロジェクト名が空または空白のみ（不正な値）"""
    
    def __init__(self, message: Optional[str] = None):
        super().__init__(ErrorCode.PROJECT_NAME_EMPTY, message)


class ProjectNameTooLongError(ProjectError):
    """プロジェクト名が長すぎる（30文字超過）"""
    
    def __init__(self, message: Optional[str] = None):
        super().__init__(ErrorCode.PROJECT_NAME_TOO_LONG, message)


# ============================================================================
# レイアウト関連の例外
# ============================================================================

class LayoutNotFoundError(LayoutError):
    """レイアウトが見つからない"""
    
    def __init__(self, message: Optional[str] = None):
        super().__init__(ErrorCode.LAYOUT_NOT_FOUND, message)


class LayoutNameEmptyError(LayoutError):
    """レイアウト名が空または空白のみ（不正な値）"""
    
    def __init__(self, message: Optional[str] = None):
        super().__init__(ErrorCode.LAYOUT_NAME_EMPTY, message)


class LayoutNameTooLongError(LayoutError):
    """レイアウト名が長すぎる（30文字超過）"""
    
    def __init__(self, message: Optional[str] = None):
        super().__init__(ErrorCode.LAYOUT_NAME_TOO_LONG, message)


class LayoutDesignNotFoundError(LayoutError):
    """レイアウトデザインが見つからない"""
    
    def __init__(self, message: Optional[str] = None):
        super().__init__(ErrorCode.LAYOUT_DESIGN_NOT_FOUND, message)


# ============================================================================
# プロセス関連の例外
# ============================================================================

class ProcessNotFoundError(ProcessError):
    """プロセスが見つからない"""
    
    def __init__(self, message: Optional[str] = None):
        super().__init__(ErrorCode.PROCESS_NOT_FOUND, message)


class ProcessDuplicateError(ProcessError):
    """同一キーのプロセスが既に存在する（DB 一意制約違反）"""

    def __init__(self, message: Optional[str] = None):
        super().__init__(ErrorCode.PROCESS_DUPLICATE, message)


class ProcessNameEmptyError(ProcessError):
    """プロセス名が空または空白のみ（不正な値）"""
    
    def __init__(self, message: Optional[str] = None):
        super().__init__(ErrorCode.PROCESS_NAME_EMPTY, message)


class ProcessNameTooLongError(ProcessError):
    """プロセス名が長すぎる（30文字超過）"""
    
    def __init__(self, message: Optional[str] = None):
        super().__init__(ErrorCode.PROCESS_NAME_TOO_LONG, message)


# ============================================================================
# 部品表関連の例外
# ============================================================================

class ProductListItemNotFoundError(ProductListError):
    """部品表アイテムが見つからない"""
    
    def __init__(self, message: Optional[str] = None):
        super().__init__(ErrorCode.PRODUCT_LIST_ITEM_NOT_FOUND, message)


class ProductListDuplicateError(ProductListError):
    """部品表の主キー重複（一意制約違反）"""

    def __init__(self, message: Optional[str] = None):
        super().__init__(ErrorCode.PRODUCT_LIST_DUPLICATE, message)


# ============================================================================
# データベース整合性（グローバル IntegrityError マッピング用）
# ============================================================================


class DatabaseForeignKeyViolationError(BaseAppException):
    """外部キー制約違反（PostgreSQL 23503）"""

    def __init__(self, message: Optional[str] = None):
        super().__init__(ErrorCode.DATABASE_FOREIGN_KEY_VIOLATION, message)


class DataSaveConflictError(BaseAppException):
    """保存競合・未分類の一意制約など（PostgreSQL 23505 を業務側で特定できない場合）"""

    def __init__(self, message: Optional[str] = None):
        super().__init__(
            ErrorCode.DATA_SAVE_CONFLICT,
            message,
            status_code=status.HTTP_409_CONFLICT,
        )


# ============================================================================
# CTログ関連の例外
# ============================================================================

class CTLogNotFoundError(CTLogError):
    """CTログが見つからない"""
    
    def __init__(self, message: Optional[str] = None):
        super().__init__(ErrorCode.CT_LOG_NOT_FOUND, message)


class CTLogNameEmptyError(CTLogError):
    """CTログ名が空または空白のみ（不正な値）"""
    
    def __init__(self, message: Optional[str] = None):
        super().__init__(ErrorCode.CT_LOG_NAME_EMPTY, message)


class CTLogNameTooLongError(CTLogError):
    """CTログ名が長すぎる（30文字超過）"""
    
    def __init__(self, message: Optional[str] = None):
        super().__init__(ErrorCode.CT_LOG_NAME_TOO_LONG, message)


class CTLogDetailDuplicateError(CTLogError):
    """CTログ明細番号が既に存在する（重複）"""
    
    def __init__(self, message: Optional[str] = None):
        super().__init__(ErrorCode.CT_LOG_DETAIL_DUPLICATE, message)


# ============================================================================
# デザイナー関連の例外
# ============================================================================

class DesignerContextNotFoundError(DesignerError):
    """デザイナーコンテキストが見つからない"""
    
    def __init__(self, message: Optional[str] = None):
        super().__init__(ErrorCode.DESIGNER_CONTEXT_NOT_FOUND, message)


# ============================================================================
# サイクルタイム関連の例外
# ============================================================================

class CycleTimeContextNotFoundError(CycleTimeError):
    """サイクルタイムコンテキストが見つからない"""
    
    def __init__(self, message: Optional[str] = None):
        super().__init__(ErrorCode.CYCLE_TIME_CONTEXT_NOT_FOUND, message)


# ============================================================================
# 比較関連の例外
# ============================================================================

class CompareContextNotFoundError(CompareError):
    """比較コンテキストが見つからない"""
    
    def __init__(self, message: Optional[str] = None):
        super().__init__(ErrorCode.COMPARE_CONTEXT_NOT_FOUND, message)


# ============================================================================
# 製品関連の例外
# ============================================================================

class ProductNotFoundError(ProductError):
    """製品が見つからない"""
    
    def __init__(self, message: Optional[str] = None):
        super().__init__(ErrorCode.PRODUCT_NOT_FOUND, message)


# ============================================================================
# セッション関連の例外
# ============================================================================

class SessionNotFoundError(SessionError):
    """セッションが見つからない"""
    
    def __init__(self, message: Optional[str] = None):
        super().__init__(ErrorCode.SESSION_NOT_FOUND, message)


class SessionExpiredError(SessionError):
    """セッションが期限切れ"""
    
    def __init__(self, message: Optional[str] = None):
        super().__init__(ErrorCode.SESSION_EXPIRED, message)


class SessionInvalidError(SessionError):
    """セッションが無効"""
    
    def __init__(self, message: Optional[str] = None):
        super().__init__(ErrorCode.SESSION_INVALID, message)


# ============================================================================
# 認証関連の例外
# ============================================================================

class AuthInvalidCredentialsError(AuthError):
    """認証情報が無効"""
    
    def __init__(self, message: Optional[str] = None):
        super().__init__(ErrorCode.AUTH_INVALID_CREDENTIALS, message)


class AuthTokenInvalidError(AuthError):
    """認証トークンが無効"""
    
    def __init__(self, message: Optional[str] = None):
        super().__init__(ErrorCode.AUTH_TOKEN_INVALID, message)


class AuthRequiredError(AuthError):
    """認証が必要"""
    
    def __init__(self, message: Optional[str] = None):
        super().__init__(ErrorCode.AUTH_REQUIRED, message)


# ============================================================================
# ユーザー関連の例外
# ============================================================================

class UserNotFoundError(UserError):
    """ユーザーが見つからない"""
    
    def __init__(self, message: Optional[str] = None):
        super().__init__(ErrorCode.USER_NOT_FOUND, message)


class UserEmailExistsError(UserError):
    """ユーザーのメールアドレスが既に存在"""
    
    def __init__(self, message: Optional[str] = None):
        super().__init__(ErrorCode.USER_EMAIL_EXISTS, message)


# ============================================================================
# THK統一ユーザー関連の例外
# ============================================================================

class THKUnifiedUserAPIError(SessionError):
    """セッション関連の汎用例外（レガシー名称）"""
    
    def __init__(self, error_code: ErrorCode, message: Optional[str] = None, status_code: Optional[int] = None):
        super().__init__(error_code, message, status_code)


# ============================================================================
# コンフィギュレーション関連の例外
# ============================================================================

class ConfigNotFoundError(ConfigError):
    """コンフィギュレーションが見つからない"""
    
    def __init__(self, message: Optional[str] = None):
        super().__init__(ErrorCode.CONFIG_NOT_FOUND, message)


class ConfigNameEmptyError(ConfigError):
    """コンフィギュレーション名が空または空白のみ（不正な値）"""
    
    def __init__(self, message: Optional[str] = None):
        super().__init__(ErrorCode.CONFIG_NAME_EMPTY, message)


class ConfigNameTooLongError(ConfigError):
    """コンフィギュレーション名が長すぎる（30文字超過）"""
    
    def __init__(self, message: Optional[str] = None):
        super().__init__(ErrorCode.CONFIG_NAME_TOO_LONG, message)
