"""
エラーメッセージ管理モジュール
多言語対応のエラーメッセージを提供

統一されたエラーレスポンス形式:
{
    "error_code": "ERROR_CODE",
    "message": "国際化されたエラーメッセージ",
    "language": "ja"
}
"""
from typing import Dict, Optional, Any
from fastapi import HTTPException, status, Request
from enum import Enum
from app.i18n.loader import i18n_loader


class ErrorCode(str, Enum):
    """エラーコード定義"""
    # 認証関連
    AUTH_INVALID_CREDENTIALS = "AUTH_INVALID_CREDENTIALS"
    AUTH_USER_INACTIVE = "AUTH_USER_INACTIVE"
    AUTH_TOKEN_INVALID = "AUTH_TOKEN_INVALID"
    AUTH_TOKEN_EXPIRED = "AUTH_TOKEN_EXPIRED"
    AUTH_TOKEN_TYPE_INVALID = "AUTH_TOKEN_TYPE_INVALID"
    AUTH_USER_NOT_FOUND = "AUTH_USER_NOT_FOUND"
    AUTH_REQUIRED = "AUTH_REQUIRED"
    AUTH_EMAIL_NOT_VERIFIED = "AUTH_EMAIL_NOT_VERIFIED"
    
    # ユーザー関連
    USER_EMAIL_EXISTS = "USER_EMAIL_EXISTS"
    USER_USERNAME_EXISTS = "USER_USERNAME_EXISTS"
    USER_NOT_FOUND = "USER_NOT_FOUND"
    USER_CANNOT_DELETE_SELF = "USER_CANNOT_DELETE_SELF"
    USER_CAN_ONLY_VIEW_SELF = "USER_CAN_ONLY_VIEW_SELF"
    USER_CAN_ONLY_UPDATE_SELF = "USER_CAN_ONLY_UPDATE_SELF"
    
    # パスワード関連
    PASSWORD_MISMATCH = "PASSWORD_MISMATCH"
    PASSWORD_CURRENT_INCORRECT = "PASSWORD_CURRENT_INCORRECT"
    PASSWORD_TOO_SHORT = "PASSWORD_TOO_SHORT"
    PASSWORD_REQUIRE_UPPERCASE = "PASSWORD_REQUIRE_UPPERCASE"
    PASSWORD_REQUIRE_LOWERCASE = "PASSWORD_REQUIRE_LOWERCASE"
    PASSWORD_REQUIRE_NUMBER = "PASSWORD_REQUIRE_NUMBER"
    PASSWORD_REQUIRE_SPECIAL = "PASSWORD_REQUIRE_SPECIAL"
    
    # トークン関連
    TOKEN_INVALID = "TOKEN_INVALID"
    TOKEN_EXPIRED = "TOKEN_EXPIRED"
    TOKEN_ALREADY_USED = "TOKEN_ALREADY_USED"
    TOKEN_MISSING_USERNAME = "TOKEN_MISSING_USERNAME"
    
    # コンフィギュレーション関連
    CONFIG_NOT_FOUND = "CONFIG_NOT_FOUND"
    CONFIG_NAME_EMPTY = "CONFIG_NAME_EMPTY"
    CONFIG_NAME_TOO_LONG = "CONFIG_NAME_TOO_LONG"
    CONFIG_CREATE_PERMISSION_DENIED = "CONFIG_CREATE_PERMISSION_DENIED"
    CONFIG_READ_PERMISSION_DENIED = "CONFIG_READ_PERMISSION_DENIED"
    CONFIG_UPDATE_PERMISSION_DENIED = "CONFIG_UPDATE_PERMISSION_DENIED"
    CONFIG_DELETE_PERMISSION_DENIED = "CONFIG_DELETE_PERMISSION_DENIED"
    CONFIG_CAN_ONLY_VIEW_OWN = "CONFIG_CAN_ONLY_VIEW_OWN"
    CONFIG_CAN_ONLY_UPDATE_OWN = "CONFIG_CAN_ONLY_UPDATE_OWN"
    CONFIG_CAN_ONLY_DELETE_OWN = "CONFIG_CAN_ONLY_DELETE_OWN"
    CONFIG_APPROVE_PERMISSION_DENIED = "CONFIG_APPROVE_PERMISSION_DENIED"
    
    # セッション関連
    SESSION_NOT_FOUND = "SESSION_NOT_FOUND"
    SESSION_EXPIRED = "SESSION_EXPIRED"
    SESSION_INVALID = "SESSION_INVALID"
    SESSION_CANNOT_PROCEED = "SESSION_CANNOT_PROCEED"
    SESSION_STEP_NOT_COMPLETED = "SESSION_STEP_NOT_COMPLETED"
    SESSION_REQUIRES_LOGIN = "SESSION_REQUIRES_LOGIN"
    
    # 製品関連
    PRODUCT_NOT_FOUND = "PRODUCT_NOT_FOUND"
    
    # バリデーション関連
    VALIDATION_ERROR = "VALIDATION_ERROR"
    EMAIL_MISMATCH = "EMAIL_MISMATCH"
    
    # サイクルタイム計算関連
    CYCLE_TIME_SLIDER_COUNT_EXCEEDED = "CYCLE_TIME_SLIDER_COUNT_EXCEEDED"
    CYCLE_TIME_PRODUCTION_ZERO = "CYCLE_TIME_PRODUCTION_ZERO"
    CYCLE_TIME_OVERTAKING_DETECTED = "CYCLE_TIME_OVERTAKING_DETECTED"
    CYCLE_TIME_TARGET_POSITION_IGNORED = "CYCLE_TIME_TARGET_POSITION_IGNORED"
    CYCLE_TIME_NEGATIVE_SPEED = "CYCLE_TIME_NEGATIVE_SPEED"
    CYCLE_TIME_SHORTEST_STOP_NOT_FOUND = "CYCLE_TIME_SHORTEST_STOP_NOT_FOUND"
    CYCLE_TIME_BACKWARD_SHORTEST_STOP_NOT_FOUND = "CYCLE_TIME_BACKWARD_SHORTEST_STOP_NOT_FOUND"
    CYCLE_TIME_SLIDER_COUNT_INVALID = "CYCLE_TIME_SLIDER_COUNT_INVALID"
    
    # VTS 業務（プロジェクト・レイアウト・部品表等）
    PROJECT_NOT_FOUND = "PROJECT_NOT_FOUND"
    PROJECT_NAME_DUPLICATE = "PROJECT_NAME_DUPLICATE"
    PROJECT_NAME_EMPTY = "PROJECT_NAME_EMPTY"
    PROJECT_NAME_TOO_LONG = "PROJECT_NAME_TOO_LONG"
    LAYOUT_NOT_FOUND = "LAYOUT_NOT_FOUND"
    LAYOUT_NAME_EMPTY = "LAYOUT_NAME_EMPTY"
    LAYOUT_NAME_TOO_LONG = "LAYOUT_NAME_TOO_LONG"
    LAYOUT_DESIGN_NOT_FOUND = "LAYOUT_DESIGN_NOT_FOUND"
    PROCESS_NOT_FOUND = "PROCESS_NOT_FOUND"
    PROCESS_DUPLICATE = "PROCESS_DUPLICATE"
    PROCESS_NAME_EMPTY = "PROCESS_NAME_EMPTY"
    PROCESS_NAME_TOO_LONG = "PROCESS_NAME_TOO_LONG"
    PRODUCT_LIST_ITEM_NOT_FOUND = "PRODUCT_LIST_ITEM_NOT_FOUND"
    PRODUCT_LIST_DUPLICATE = "PRODUCT_LIST_DUPLICATE"
    DATABASE_FOREIGN_KEY_VIOLATION = "DATABASE_FOREIGN_KEY_VIOLATION"
    DATA_SAVE_CONFLICT = "DATA_SAVE_CONFLICT"
    CT_LOG_NOT_FOUND = "CT_LOG_NOT_FOUND"
    CT_LOG_NAME_EMPTY = "CT_LOG_NAME_EMPTY"
    CT_LOG_NAME_TOO_LONG = "CT_LOG_NAME_TOO_LONG"
    CT_LOG_DETAIL_DUPLICATE = "CT_LOG_DETAIL_DUPLICATE"
    DESIGNER_CONTEXT_NOT_FOUND = "DESIGNER_CONTEXT_NOT_FOUND"
    CYCLE_TIME_CONTEXT_NOT_FOUND = "CYCLE_TIME_CONTEXT_NOT_FOUND"
    COMPARE_CONTEXT_NOT_FOUND = "COMPARE_CONTEXT_NOT_FOUND"
    
    # 一般エラー
    INTERNAL_SERVER_ERROR = "INTERNAL_SERVER_ERROR"
    PERMISSION_DENIED = "PERMISSION_DENIED"
    RESOURCE_NOT_FOUND = "RESOURCE_NOT_FOUND"
    BAD_REQUEST = "BAD_REQUEST"


def _error_code_to_key_path(error_code: ErrorCode) -> str:
    """
    ErrorCode を YAML キーパスに変換
    
    Args:
        error_code: ErrorCode 列挙値
        
    Returns:
        YAML キーパス（例: "auth.invalid_credentials"）
    """
    code_value = error_code.value
    
    # エラーコードから YAML キーパスへのマッピング
    error_code_mapping = {
        # 認証関連
        "AUTH_INVALID_CREDENTIALS": "auth.invalid_credentials",
        "AUTH_USER_INACTIVE": "auth.user_inactive",
        "AUTH_TOKEN_INVALID": "auth.token_invalid",
        "AUTH_TOKEN_EXPIRED": "auth.token_expired",
        "AUTH_TOKEN_TYPE_INVALID": "auth.token_type_invalid",
        "AUTH_USER_NOT_FOUND": "auth.user_not_found",
        "AUTH_REQUIRED": "auth.required",
        "AUTH_EMAIL_NOT_VERIFIED": "auth.email_not_verified",
        
        # ユーザー関連
        "USER_EMAIL_EXISTS": "user.email_exists",
        "USER_USERNAME_EXISTS": "user.username_exists",
        "USER_NOT_FOUND": "user.not_found",
        "USER_CANNOT_DELETE_SELF": "user.cannot_delete_self",
        "USER_CAN_ONLY_VIEW_SELF": "user.can_only_view_self",
        "USER_CAN_ONLY_UPDATE_SELF": "user.can_only_update_self",
        
        # パスワード関連
        "PASSWORD_MISMATCH": "password.mismatch",
        "PASSWORD_CURRENT_INCORRECT": "password.current_incorrect",
        "PASSWORD_TOO_SHORT": "password.too_short",
        "PASSWORD_REQUIRE_UPPERCASE": "password.require_uppercase",
        "PASSWORD_REQUIRE_LOWERCASE": "password.require_lowercase",
        "PASSWORD_REQUIRE_NUMBER": "password.require_number",
        "PASSWORD_REQUIRE_SPECIAL": "password.require_special",
        
        # トークン関連
        "TOKEN_INVALID": "token.invalid",
        "TOKEN_EXPIRED": "token.expired",
        "TOKEN_ALREADY_USED": "token.already_used",
        "TOKEN_MISSING_USERNAME": "token.missing_username",
        
        # コンフィギュレーション関連
        "CONFIG_NOT_FOUND": "config.not_found",
        "CONFIG_NAME_EMPTY": "config.name_empty",
        "CONFIG_NAME_TOO_LONG": "config.name_too_long",
        "CONFIG_CREATE_PERMISSION_DENIED": "config.create_permission_denied",
        "CONFIG_READ_PERMISSION_DENIED": "config.read_permission_denied",
        "CONFIG_UPDATE_PERMISSION_DENIED": "config.update_permission_denied",
        "CONFIG_DELETE_PERMISSION_DENIED": "config.delete_permission_denied",
        "CONFIG_CAN_ONLY_VIEW_OWN": "config.can_only_view_own",
        "CONFIG_CAN_ONLY_UPDATE_OWN": "config.can_only_update_own",
        "CONFIG_CAN_ONLY_DELETE_OWN": "config.can_only_delete_own",
        "CONFIG_APPROVE_PERMISSION_DENIED": "config.approve_permission_denied",
        
        # セッション関連
        "SESSION_NOT_FOUND": "session.not_found",
        "SESSION_EXPIRED": "session.expired",
        "SESSION_INVALID": "session.invalid",
        "SESSION_CANNOT_PROCEED": "session.cannot_proceed",
        "SESSION_STEP_NOT_COMPLETED": "session.step_not_completed",
        "SESSION_REQUIRES_LOGIN": "session.requires_login",
        
        # 製品関連
        "PRODUCT_NOT_FOUND": "product.not_found",
        
        # バリデーション関連
        "VALIDATION_ERROR": "validation.error",
        "EMAIL_MISMATCH": "validation.email_mismatch",
        
        # サイクルタイム計算関連
        "CYCLE_TIME_SLIDER_COUNT_EXCEEDED": "cycle_time.slider_count_exceeded",
        "CYCLE_TIME_PRODUCTION_ZERO": "cycle_time.production_zero",
        "CYCLE_TIME_OVERTAKING_DETECTED": "cycle_time.overtaking_detected",
        "CYCLE_TIME_TARGET_POSITION_IGNORED": "cycle_time.target_position_ignored",
        "CYCLE_TIME_NEGATIVE_SPEED": "cycle_time.negative_speed",
        "CYCLE_TIME_SHORTEST_STOP_NOT_FOUND": "cycle_time.shortest_stop_not_found",
        "CYCLE_TIME_BACKWARD_SHORTEST_STOP_NOT_FOUND": "cycle_time.backward_shortest_stop_not_found",
        "CYCLE_TIME_SLIDER_COUNT_INVALID": "cycle_time.slider_count_invalid",
        
        # VTS 業務
        "PROJECT_NOT_FOUND": "vts.project_not_found",
        "PROJECT_NAME_DUPLICATE": "vts.project_name_duplicate",
        "PROJECT_NAME_EMPTY": "vts.project_name_empty",
        "PROJECT_NAME_TOO_LONG": "vts.project_name_too_long",
        "LAYOUT_NOT_FOUND": "vts.layout_not_found",
        "LAYOUT_NAME_EMPTY": "vts.layout_name_empty",
        "LAYOUT_NAME_TOO_LONG": "vts.layout_name_too_long",
        "LAYOUT_DESIGN_NOT_FOUND": "vts.layout_design_not_found",
        "PROCESS_NOT_FOUND": "vts.process_not_found",
        "PROCESS_DUPLICATE": "vts.process_duplicate",
        "PROCESS_NAME_EMPTY": "vts.process_name_empty",
        "PROCESS_NAME_TOO_LONG": "vts.process_name_too_long",
        "PRODUCT_LIST_ITEM_NOT_FOUND": "vts.product_list_item_not_found",
        "PRODUCT_LIST_DUPLICATE": "vts.product_list_duplicate",
        "DATABASE_FOREIGN_KEY_VIOLATION": "general.database_foreign_key_violation",
        "DATA_SAVE_CONFLICT": "general.data_save_conflict",
        "CT_LOG_NOT_FOUND": "vts.ct_log_not_found",
        "CT_LOG_NAME_EMPTY": "vts.ct_log_name_empty",
        "CT_LOG_NAME_TOO_LONG": "vts.ct_log_name_too_long",
        "CT_LOG_DETAIL_DUPLICATE": "vts.ct_log_detail_duplicate",
        "DESIGNER_CONTEXT_NOT_FOUND": "vts.designer_context_not_found",
        "CYCLE_TIME_CONTEXT_NOT_FOUND": "vts.cycle_time_context_not_found",
        "COMPARE_CONTEXT_NOT_FOUND": "vts.compare_context_not_found",
        
        # 一般エラー
        "INTERNAL_SERVER_ERROR": "general.internal_server_error",
        "PERMISSION_DENIED": "general.permission_denied",
        "RESOURCE_NOT_FOUND": "general.resource_not_found",
        "BAD_REQUEST": "general.bad_request",
    }
    
    # マッピングから取得
    if code_value in error_code_mapping:
        return error_code_mapping[code_value]
    
    # マッピングが見つからない場合、デフォルト処理
    # すべて小文字にしてアンダースコアをドットに変換
    key = code_value.lower().replace("_", ".")
    return key


def get_language_from_request(request: Optional[Request] = None) -> str:
    """
    リクエストから言語を取得
    優先順位: Accept-Languageヘッダー > デフォルト(ja)
    """
    if request is None:
        return "ja"
    
    accept_language = request.headers.get("Accept-Language") or "ja"
    accept_language = accept_language.strip()
    # Accept-Languageヘッダーから言語を抽出（例: "ja,en;q=0.9" -> "ja"）
    if "," in accept_language:
        accept_language = accept_language.split(",")[0]
    if ";" in accept_language:
        accept_language = accept_language.split(";")[0]
    accept_language = accept_language.strip()
    # 大文字・前後空白（" EN", "en-US"）に対応
    primary = accept_language.lower()
    if primary.startswith("en"):
        return "en"
    return "ja"


def get_error_message(
    error_code: ErrorCode,
    language: str = "ja",
    **kwargs: Any
) -> str:
    """
    エラーメッセージを取得（YAML 設定から）
    
    Args:
        error_code: エラーコード
        language: 言語コード（ja/en）
        **kwargs: メッセージ内のプレースホルダーを置換する値
    
    Returns:
        エラーメッセージ文字列
    """
    # ErrorCode を YAML キーパスに変換
    key_path = _error_code_to_key_path(error_code)
    
    # i18n_loader からエラーメッセージを取得
    return i18n_loader.get_error(key_path, language, **kwargs)


def raise_http_exception(
    error_code: ErrorCode,
    status_code: int = status.HTTP_400_BAD_REQUEST,
    language: str = "ja",
    request: Optional[Request] = None,
    headers: Optional[Dict[str, str]] = None,
    **kwargs: Any
) -> None:
    """
    統一されたエラーレスポンス形式でHTTPExceptionを生成してraise
    
    この関数は統一されたエラーレスポンス形式を使用します：
    {
        "error_code": "ERROR_CODE",
        "message": "国際化されたエラーメッセージ",
        "language": "ja"
    }
    
    Args:
        error_code: エラーコード（ErrorCode列挙型）
        status_code: HTTPステータスコード（デフォルト: 400）
        language: 言語コード（指定がない場合はリクエストから取得）
        request: FastAPI Requestオブジェクト（言語取得用、必須推奨）
        headers: 追加のHTTPヘッダー
        **kwargs: メッセージ内のプレースホルダーを置換する値（例: step=1, current_step=2）
    
    Raises:
        HTTPException: 統一された形式のエラーレスポンス
    
    Example:
        raise_http_exception(
            error_code=ErrorCode.SESSION_STEP_NOT_COMPLETED,
            status_code=status.HTTP_400_BAD_REQUEST,
            request=request,
            step=1
        )
    """
    # 言語が指定されていない場合、リクエストから取得
    if language == "ja" and request is not None:
        language = get_language_from_request(request)
    
    # 国際化されたエラーメッセージを取得（パラメータ化対応）
    error_message = get_error_message(error_code, language, **kwargs)
    
    # 統一されたエラーレスポンス形式
    error_detail = {
        "error_code": error_code.value,
        "message": error_message,
        "language": language
    }
    
    exception_headers = headers or {}
    
    raise HTTPException(
        status_code=status_code,
        detail=error_detail,
        headers=exception_headers
    )


def create_error_response(
    error_code: ErrorCode,
    language: str = "ja",
    **kwargs: Any
) -> Dict[str, Any]:
    """
    エラーレスポンス辞書を作成（HTTPExceptionをraiseしない場合用）
    
    Args:
        error_code: エラーコード
        language: 言語コード
        **kwargs: メッセージ内のプレースホルダーを置換する値
    
    Returns:
        エラーレスポンス辞書
    """
    error_message = get_error_message(error_code, language, **kwargs)
    
    return {
        "error_code": error_code.value,
        "message": error_message,
        "language": language
    }
