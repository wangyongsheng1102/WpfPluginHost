"""
SQLAlchemy IntegrityError → BaseAppException（PostgreSQL pgcode ベース）
"""
from typing import Optional

from sqlalchemy.exc import IntegrityError

from app.core.exceptions import BaseAppException, DataSaveConflictError, DatabaseForeignKeyViolationError


def _pgcode(exc: IntegrityError) -> Optional[str]:
    orig = getattr(exc, "orig", None)
    if orig is None:
        return None
    code = getattr(orig, "pgcode", None)
    if code:
        return code
    return getattr(orig, "sqlstate", None)


def integrity_error_to_app_exception(exc: IntegrityError) -> BaseAppException:
    """23503 → 外部キー、23505 その他 → 保存競合（未分類の一意制約）"""
    pg = _pgcode(exc)
    if pg == "23503":
        return DatabaseForeignKeyViolationError()
    if pg == "23505":
        return DataSaveConflictError()
    return DataSaveConflictError()
