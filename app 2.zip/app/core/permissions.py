"""
認可・現在ユーザー取得（m_user ベース）
旧 User / users テーブルは廃止済み。X-User-Id で m_user を取得する。
"""
from typing import Optional

from fastapi import Depends, Request, status
from sqlalchemy.orm import Session

from app.core.database import get_db
from app.core.errors import ErrorCode, raise_http_exception
from app.models.vts import MUser
from app.services.m_user_auth_service import get_m_user_by_id


def get_current_user(
    request: Request,
    db: Session = Depends(get_db),
) -> MUser:
    """
    リクエストヘッダの X-User-Id から現在の m_user を取得（必須）。
    ヘッダがない、またはユーザーが存在しない場合は 401 を返す。
    """
    user_id = request.headers.get("X-User-Id")
    if not user_id:
        raise_http_exception(
            error_code=ErrorCode.AUTH_REQUIRED,
            status_code=status.HTTP_401_UNAUTHORIZED,
            request=request,
        )
    user = get_m_user_by_id(db, user_id)
    if not user:
        raise_http_exception(
            error_code=ErrorCode.AUTH_USER_NOT_FOUND,
            status_code=status.HTTP_401_UNAUTHORIZED,
            request=request,
        )
    return user


def get_current_user_optional(
    request: Request,
    db: Session = Depends(get_db),
) -> Optional[MUser]:
    """
    リクエストヘッダの X-User-Id から現在の m_user を取得（オプション）。
    ヘッダがない、またはユーザーが存在しない場合は None を返す。401 は返さない。
    """
    user_id = request.headers.get("X-User-Id")
    if not user_id:
        return None
    return get_m_user_by_id(db, user_id)
