"""
製品名・製品種類名の言語解決（m_product / m_product_type の *_en 列と Accept-Language 連携）
"""
from __future__ import annotations

from typing import TYPE_CHECKING, Optional

if TYPE_CHECKING:
    from app.models.vts import MProduct, MProductType


def resolve_product_name(p: Optional["MProduct"], language: str) -> str:
    """language=='en' かつ product_name_en が空でなければ EN、それ以外は日本語 product_name。"""
    if p is None:
        return ""
    if language == "en":
        en = getattr(p, "product_name_en", None)
        if en is not None and str(en).strip():
            return str(en).strip()
    return (p.product_name or "").strip() if p.product_name else ""


def resolve_product_type_name(pt: Optional["MProductType"], language: str) -> Optional[str]:
    """language=='en' かつ product_type_name_en が空でなければ EN、それ以外は日本語 product_type_name。"""
    if pt is None:
        return None
    if language == "en":
        en = getattr(pt, "product_type_name_en", None)
        if en is not None and str(en).strip():
            return str(en).strip()
    name = pt.product_type_name
    return name.strip() if name else None
