"""
アプリケーション設定
"""
import secrets
import json

from pydantic import Field, field_validator
from pydantic_settings import BaseSettings, SettingsConfigDict
from typing import List, Any, Optional


class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_file=".env",
        case_sensitive=True,
    )
    
    # CORS設定
    # 注意：環境変数 CORS_ORIGINS は JSON 配列の文字列で指定する（例：'["http://localhost:3000","http://localhost:8000"]'）
    CORS_ORIGINS: List[str] = Field(..., env="CORS_ORIGINS")

    # API設定
    API_V1_PREFIX: str = Field(..., env="API_V1_PREFIX")

    # データベース設定
    # DATABASE_URL: str = "postgresql://user:password@localhost:5432/thk_configurator"
    DATABASE_URL: str = Field(..., env="DATABASE_URL")

    # ページネーション設定
    DEFAULT_PAGE_SIZE: int = Field(..., env="DEFAULT_PAGE_SIZE")
    MAX_PAGE_SIZE: int = Field(..., env="MAX_PAGE_SIZE")
    
    # セッション設定
    SESSION_EXPIRE_HOURS: int = Field(24, env="SESSION_EXPIRE_HOURS")  # セッション有効期限（時間）
    
    # 環境設定
    ENVIRONMENT: str = Field("development", env="ENVIRONMENT")  # "development" または "production"
    
    # API ログ設定
    LOG_API_REQUESTS: bool = Field(True, env="LOG_API_REQUESTS")  # API リクエストログを記録するか
    LOG_REQUEST_BODY: bool = Field(True, env="LOG_REQUEST_BODY")  # リクエスト body を記録するか
    LOG_RESPONSE_BODY: bool = Field(True, env="LOG_RESPONSE_BODY")  # レスポンス body を記録するか
    LOG_BODY_MAX_SIZE: int = Field(10240, env="LOG_BODY_MAX_SIZE")  # Body の最大サイズ（バイト）、超過時は切り捨て
    LOG_SENSITIVE_DATA: bool = Field(True, env="LOG_SENSITIVE_DATA")  # 機密情報を記録するか（開発環境: True、本番環境: False 推奨）


settings = Settings()
