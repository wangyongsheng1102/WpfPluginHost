import logging
from logging.handlers import TimedRotatingFileHandler
from pathlib import Path

# ログディレクトリの設定
LOG_DIR = Path(__file__).resolve().parent.parent.parent / "logs"
LOG_DIR.mkdir(exist_ok=True)

LOG_FILE = LOG_DIR / "app.log"
API_ACCESS_LOG_FILE = LOG_DIR / "api_access.log"


def setup_logging():
    """ロギング設定を初期化"""
    # ログフォーマッタ
    formatter = logging.Formatter(
        "[%(asctime)s] [%(levelname)s] [%(name)s] %(message)s"
    )

    # ファイルハンドラ（日次ローテーション）
    file_handler = TimedRotatingFileHandler(
        LOG_FILE,
        when="midnight",      # 毎日深夜
        interval=1,           # 1日間隔
        backupCount=14,       # 14日分保持
        encoding="utf-8",     # UTF-8エンコーディング
    )
    file_handler.setFormatter(formatter)
    file_handler.setLevel(logging.INFO)

    # コンソールハンドラ
    console_handler = logging.StreamHandler()
    console_handler.setFormatter(formatter)
    console_handler.setLevel(logging.INFO)

    # ルートロガーの設定
    root_logger = logging.getLogger()
    root_logger.setLevel(logging.INFO)
    root_logger.handlers.clear()  # 既存のハンドラをクリア
    root_logger.addHandler(file_handler)
    root_logger.addHandler(console_handler)

    # uvicorn ロガーの設定（上書き防止）
    logging.getLogger("uvicorn").propagate = True
    logging.getLogger("uvicorn.error").propagate = True
    logging.getLogger("uvicorn.access").propagate = False  # アクセスログは独自に処理

    # SQLAlchemy SQL ログをコンソール・ファイルに出力（echo と併用）
    sql_logger = logging.getLogger("sqlalchemy.engine.Engine")
    sql_logger.setLevel(logging.INFO)
    sql_logger.addHandler(console_handler)
    sql_logger.addHandler(file_handler)

    # API アクセスログ専用ロガーの設定
    api_access_logger = logging.getLogger("api_access")
    api_access_logger.setLevel(logging.INFO)
    api_access_logger.propagate = False  # ルートロガーに伝播しない
    
    # API アクセスログ用ファイルハンドラ（日次ローテーション、30日保持）
    api_file_handler = TimedRotatingFileHandler(
        API_ACCESS_LOG_FILE,
        when="midnight",
        interval=1,
        backupCount=30,       # 30日分保持
        encoding="utf-8",
    )
    api_file_handler.setFormatter(formatter)
    api_file_handler.setLevel(logging.INFO)
    
    # API アクセスログ用コンソールハンドラ
    api_console_handler = logging.StreamHandler()
    api_console_handler.setFormatter(formatter)
    api_console_handler.setLevel(logging.INFO)
    
    api_access_logger.addHandler(api_file_handler)
    api_access_logger.addHandler(api_console_handler)