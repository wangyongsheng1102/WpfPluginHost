"""
PDF 報告用コンテキスト API
GET /api/v1/pdf-report/context で PDF テンプレート用データを返す
"""
import logging
from typing import Optional

from fastapi import APIRouter, Depends, Query, Request
from sqlalchemy.orm import Session

from app.api.m_user_auth import get_current_m_user_from_header
from app.core.database import get_db
from app.core.errors import ErrorCode, get_language_from_request, raise_http_exception
from app.core.exceptions import LayoutNotFoundError, ProjectNotFoundError
from app.models.vts import MUser
from app.schemas.pdf_report import PdfReportContextResponse
from app.services import pdf_report_service

logger = logging.getLogger(__name__)

router = APIRouter()


@router.get("/context", response_model=PdfReportContextResponse)
async def get_pdf_report_context(
    request: Request,
    project_id: int = Query(..., description="プロジェクトID"),
    layout_id: int = Query(..., description="レイアウトID"),
    ct_log_no: Optional[int] = Query(None, description="サイクルタイムログ番号（省略可）"),
    db: Session = Depends(get_db),
    current_user: MUser = Depends(get_current_m_user_from_header),
):
    """
    PDF 報告用のコンテキストを取得する。
    表紙・部品表・入力条件・プロセス表・検討結果・VTS図用のデータを返す。
    """
    try:
        lang = get_language_from_request(request)
        return pdf_report_service.get_pdf_report_context(
            db=db,
            create_user=current_user.user_id,
            project_id=project_id,
            layout_id=layout_id,
            ct_log_no=ct_log_no,
            language=lang,
        )
    except (ProjectNotFoundError, LayoutNotFoundError):
        raise_http_exception(
            error_code=ErrorCode.BAD_REQUEST,
            status_code=400,
            request=request,
        )
    except Exception as e:
        logger.exception("PDF report context failed: %s", e)
        raise_http_exception(
            error_code=ErrorCode.INTERNAL_SERVER_ERROR,
            status_code=500,
            request=request,
        )
