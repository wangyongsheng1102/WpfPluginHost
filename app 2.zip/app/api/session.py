"""
セッションAPIルート（多ステップフローの一時データ管理）
"""
from fastapi import APIRouter, HTTPException, Depends, status
from sqlalchemy.orm import Session
from typing import Optional

from app.core.database import get_db
from app.core.permissions import get_current_user_optional, get_current_user
from app.core.errors import ErrorCode, raise_http_exception, get_language_from_request
from app.core.exceptions import THKUnifiedUserAPIError
from app.models.vts import MUser
from fastapi import Request
from app.schemas.session import (
    SessionCreate,
    SessionStepUpdate,
    SessionResponse,
    SessionSummaryResponse,
    SessionStepResponse,
    SessionStepsByTypeResponse,
    SessionStepInfo,
    SessionListResponse,
    SessionAssociateRequest,
)
from app.services.session_service import SessionService

router = APIRouter()

# ============================================================================
# 公開API（認証不要、未ログインでも使用可能）
# ============================================================================


@router.post("/", response_model=SessionResponse, status_code=status.HTTP_201_CREATED)
async def create_session(
    request: SessionCreate,
    http_request: Request,
    current_user: Optional[MUser] = Depends(get_current_user_optional),
    db: Session = Depends(get_db)
):
    """
    新しいセッションを作成（公開API）
    
    - 認証はオプション（未ログインでもセッション作成可能）
    - ログイン済みの場合、自動的にユーザーに紐づけられる
    - 未ログインの場合、user_id = NULL で作成される
    """
    try:
        session = SessionService.create_session(
            db=db,
            user=current_user,
            context=request.context,
            language=request.language
        )
        return session
    except Exception as e:
        raise_http_exception(
            error_code=ErrorCode.INTERNAL_SERVER_ERROR,
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            request=http_request
        )


@router.get("/{session_id}", response_model=SessionResponse)
async def get_session(
    session_id: str,
    http_request: Request,
    current_user: Optional[MUser] = Depends(get_current_user_optional),
    db: Session = Depends(get_db)
):
    """
    セッションの詳細を取得（公開API）
    
    - 認証はオプション
    - ログイン済みの場合、自分のセッションまたは未ログイン時に作成されたセッションにアクセス可能
    - 未ログインの場合、未ログイン時に作成されたセッションのみアクセス可能
    """
    try:
        session = SessionService.get_session(
            db, 
            session_id, 
            current_user,
            require_ownership=False
        )
        if not session:
            raise_http_exception(
                error_code=ErrorCode.SESSION_NOT_FOUND,
                status_code=status.HTTP_404_NOT_FOUND,
                request=http_request
            )
        return session
    except HTTPException:
        raise
    except Exception as e:
        raise_http_exception(
            error_code=ErrorCode.INTERNAL_SERVER_ERROR,
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            request=http_request
        )


@router.get("/{session_id}/summary", response_model=SessionSummaryResponse)
async def get_session_summary(
    session_id: str,
    http_request: Request,
    current_user: Optional[MUser] = Depends(get_current_user_optional),
    db: Session = Depends(get_db)
):
    """
    セッションのサマリーを取得
    """
    try:
        session = SessionService.get_session(db, session_id, current_user)
        if not session:
            raise_http_exception(
                error_code=ErrorCode.SESSION_NOT_FOUND,
                status_code=status.HTTP_404_NOT_FOUND,
                request=http_request
            )
        
        # 全ステップ数を計算（step_dataの最大キーから）
        step_data = session.step_data or {}
        total_steps = max(step_data.keys()) if step_data else session.current_step
        
        # ステップタイプ一覧を取得
        step_types = set()
        for step_info in step_data.values():
            if isinstance(step_info, dict) and "step_type" in step_info:
                step_types.add(step_info["step_type"])
        
        return SessionSummaryResponse(
            session_id=session.session_id,
            current_step=session.current_step,
            completed_steps=session.completed_steps or [],
            total_steps=total_steps,
            step_types=list(step_types),
            expires_at=session.expires_at
        )
    except HTTPException:
        raise
    except Exception as e:
        raise_http_exception(
            error_code=ErrorCode.INTERNAL_SERVER_ERROR,
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            request=http_request
        )


@router.put("/{session_id}/step", response_model=SessionResponse)
async def update_step_data(
    session_id: str,
    request: SessionStepUpdate,
    http_request: Request,
    current_user: Optional[MUser] = Depends(get_current_user_optional),
    db: Session = Depends(get_db)
):
    """
    ステップデータを更新（タイプと内容を含む）
    """
    try:
        session = SessionService.update_step_data(
            db=db,
            session_id=session_id,
            step=request.step,
            step_type=request.step_type,
            content=request.content,
            metadata=request.metadata,
            mark_completed=request.mark_completed,
            user=current_user
        )
        return session
    except THKUnifiedUserAPIError as e:
        if e.error_code == ErrorCode.SESSION_NOT_FOUND:
            raise_http_exception(
                error_code=ErrorCode.SESSION_NOT_FOUND,
                status_code=status.HTTP_404_NOT_FOUND,
                request=http_request
            )
        raise_http_exception(
            error_code=e.error_code,
            status_code=status.HTTP_400_BAD_REQUEST,
            request=http_request
        )
    except Exception as e:
        raise_http_exception(
            error_code=ErrorCode.INTERNAL_SERVER_ERROR,
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            request=http_request
        )


@router.post("/{session_id}/proceed/{target_step}", response_model=SessionResponse)
async def proceed_to_step(
    session_id: str,
    target_step: int,
    http_request: Request,
    current_user: Optional[MUser] = Depends(get_current_user_optional),
    db: Session = Depends(get_db)
):
    """
    指定されたステップに進む（ステップ検証付き）
    """
    try:
        session = SessionService.proceed_to_step(
            db=db,
            session_id=session_id,
            target_step=target_step,
            user=current_user
        )
        return session
    except THKUnifiedUserAPIError as e:
        if e.error_code == ErrorCode.SESSION_NOT_FOUND:
            raise_http_exception(
                error_code=ErrorCode.SESSION_NOT_FOUND,
                status_code=status.HTTP_404_NOT_FOUND,
                request=http_request
            )
        elif e.error_code == ErrorCode.SESSION_STEP_NOT_COMPLETED:
            # エラーメッセージからstep番号を抽出（必要に応じて）
            raise_http_exception(
                error_code=ErrorCode.SESSION_STEP_NOT_COMPLETED,
                status_code=status.HTTP_400_BAD_REQUEST,
                request=http_request,
                step=target_step
            )
        raise_http_exception(
            error_code=e.error_code,
            status_code=status.HTTP_400_BAD_REQUEST,
            request=http_request
        )
    except Exception as e:
        raise_http_exception(
            error_code=ErrorCode.INTERNAL_SERVER_ERROR,
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            request=http_request
        )


@router.get("/{session_id}/step/{step}", response_model=SessionStepResponse)
async def get_step_data(
    session_id: str,
    step: int,
    http_request: Request,
    current_user: Optional[MUser] = Depends(get_current_user_optional),
    db: Session = Depends(get_db)
):
    """
    指定されたステップのデータを取得
    """
    try:
        from datetime import datetime
        data = SessionService.get_step_data(
            db=db,
            session_id=session_id,
            step=step,
            user=current_user
        )
        
        if not data:
            raise_http_exception(
                error_code=ErrorCode.RESOURCE_NOT_FOUND,
                status_code=status.HTTP_404_NOT_FOUND,
                request=http_request
            )
        
        # 完了状態を確認
        session = SessionService.get_session(db, session_id, current_user)
        is_completed = step in (session.completed_steps or []) if session else False
        
        # 日時文字列をdatetimeオブジェクトに変換
        completed_at = None
        if data.get("completed_at"):
            completed_at = datetime.fromisoformat(data["completed_at"].replace("Z", "+00:00"))
        
        updated_at = datetime.fromisoformat(data.get("updated_at", datetime.utcnow().isoformat()).replace("Z", "+00:00"))
        
        return SessionStepResponse(
            step=step,
            step_type=data.get("step_type", ""),
            content=data.get("content", {}),
            metadata=data.get("metadata"),
            is_completed=is_completed,
            completed_at=completed_at,
            updated_at=updated_at
        )
    except HTTPException:
        raise
    except THKUnifiedUserAPIError as e:
        if e.error_code == ErrorCode.SESSION_NOT_FOUND:
            raise_http_exception(
                error_code=ErrorCode.SESSION_NOT_FOUND,
                status_code=status.HTTP_404_NOT_FOUND,
                request=http_request
            )
        raise_http_exception(
            error_code=e.error_code,
            status_code=status.HTTP_400_BAD_REQUEST,
            request=http_request
        )
    except Exception as e:
        raise_http_exception(
            error_code=ErrorCode.INTERNAL_SERVER_ERROR,
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            request=http_request
        )


@router.get("/{session_id}/steps/type/{step_type}", response_model=SessionStepsByTypeResponse)
async def get_steps_by_type(
    session_id: str,
    step_type: str,
    http_request: Request,
    current_user: Optional[MUser] = Depends(get_current_user_optional),
    db: Session = Depends(get_db)
):
    """
    指定されたタイプのステップを取得
    """
    try:
        from datetime import datetime
        steps_data = SessionService.get_steps_by_type(
            db=db,
            session_id=session_id,
            step_type=step_type,
            user=current_user
        )
        
        session = SessionService.get_session(db, session_id, current_user)
        completed_steps = session.completed_steps or [] if session else []
        
        steps = []
        for step_num, step_info in steps_data.items():
            is_completed = step_num in completed_steps
            completed_at = None
            if step_info.get("completed_at"):
                completed_at = datetime.fromisoformat(step_info["completed_at"].replace("Z", "+00:00"))
            
            updated_at = datetime.fromisoformat(step_info.get("updated_at", datetime.utcnow().isoformat()).replace("Z", "+00:00"))
            
            steps.append(SessionStepInfo(
                step=step_num,
                step_type=step_info.get("step_type", ""),
                content=step_info.get("content", {}),
                metadata=step_info.get("metadata"),
                is_completed=is_completed,
                completed_at=completed_at,
                updated_at=updated_at
            ))
        
        # ステップ番号でソート
        steps.sort(key=lambda x: x.step)
        
        return SessionStepsByTypeResponse(
            step_type=step_type,
            steps=steps
        )
    except THKUnifiedUserAPIError as e:
        if e.error_code == ErrorCode.SESSION_NOT_FOUND:
            raise_http_exception(
                error_code=ErrorCode.SESSION_NOT_FOUND,
                status_code=status.HTTP_404_NOT_FOUND,
                request=http_request
            )
        raise_http_exception(
            error_code=e.error_code,
            status_code=status.HTTP_400_BAD_REQUEST,
            request=http_request
        )
    except Exception as e:
        raise_http_exception(
            error_code=ErrorCode.INTERNAL_SERVER_ERROR,
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            request=http_request
        )


@router.delete("/{session_id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete_session(
    session_id: str,
    http_request: Request,
    current_user: Optional[MUser] = Depends(get_current_user_optional),
    db: Session = Depends(get_db)
):
    """
    セッションを削除（公開API）
    
    - 認証はオプション
    - ログイン済みの場合、自分のセッションのみ削除可能
    - 未ログインの場合、未ログイン時に作成したセッションのみ削除可能
    """
    try:
        deleted = SessionService.delete_session(
            db=db,
            session_id=session_id,
            user=current_user
        )
        if not deleted:
            raise_http_exception(
                error_code=ErrorCode.SESSION_NOT_FOUND,
                status_code=status.HTTP_404_NOT_FOUND,
                request=http_request
            )
        return None
    except HTTPException:
        raise
    except Exception as e:
        raise_http_exception(
            error_code=ErrorCode.INTERNAL_SERVER_ERROR,
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            request=http_request
        )


# ============================================================================
# ユーザー専用API（認証必須）
# ============================================================================

@router.post("/associate", response_model=SessionResponse)
async def associate_session_to_user(
    request: SessionAssociateRequest,
    http_request: Request,
    current_user: MUser = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    セッションを現在のユーザーに紐づける（認証必須）
    
    - 未ログイン時に作成したセッションを、ログイン後にユーザーに紐づける
    - 既に他のユーザーに紐づいているセッションは紐づけ不可
    """
    try:
        session = SessionService.associate_session_to_user(
            db=db,
            session_id=request.session_id,
            user=current_user
        )
        return session
    except THKUnifiedUserAPIError as e:
        if e.error_code == ErrorCode.SESSION_NOT_FOUND:
            raise_http_exception(
                error_code=ErrorCode.SESSION_NOT_FOUND,
                status_code=status.HTTP_404_NOT_FOUND,
                request=http_request
            )
        elif e.error_code == ErrorCode.SESSION_INVALID:
            raise_http_exception(
                error_code=ErrorCode.SESSION_INVALID,
                status_code=status.HTTP_403_FORBIDDEN,
                request=http_request
            )
        raise_http_exception(
            error_code=e.error_code,
            status_code=status.HTTP_400_BAD_REQUEST,
            request=http_request
        )
    except Exception as e:
        raise_http_exception(
            error_code=ErrorCode.INTERNAL_SERVER_ERROR,
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            request=http_request
        )


@router.get("/user/list", response_model=SessionListResponse)
async def list_user_sessions(
    http_request: Request,
    context: Optional[str] = None,
    include_expired: bool = False,
    current_user: MUser = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    現在のユーザーのセッション一覧を取得（認証必須）
    
    - 自分のセッションのみ取得可能
    - contextでフィルタリング可能
    - include_expiredで期限切れセッションを含めるか指定可能
    """
    try:
        sessions = SessionService.get_user_sessions(
            db=db,
            user=current_user,
            context=context,
            include_expired=include_expired
        )
        return SessionListResponse(
            total=len(sessions),
            items=sessions
        )
    except Exception as e:
        raise_http_exception(
            error_code=ErrorCode.INTERNAL_SERVER_ERROR,
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            request=http_request
        )
