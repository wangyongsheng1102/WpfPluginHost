"""
サイクルタイム計算APIルート（calculate + STEP1/2/3 画面 context）
"""
from typing import Optional
from fastapi import APIRouter, Depends, status, Request, Query, HTTPException
from sqlalchemy.orm import Session

from app.core.database import get_db
from app.core.permissions import get_current_user
from app.core.errors import raise_http_exception, ErrorCode, get_language_from_request
from app.models.vts import MUser
from app.schemas.cycle_time import (
    CycleTimeCalculateRequest,
    CycleTimeCalculateResponse,
)
from app.schemas.vts import (
    CycleTimeStep1ContextResponse,
    CycleTimeStep2ContextResponse,
    CycleTimeStep3ContextResponse,
)
from app.services import vts_service
from app.services.cycle_time_calculator.exceptions import CycleTimeCalculationError
from app.services.cycle_time_calculator.modules.main_controller import MainController
from app.services.cycle_time_calculator.modules.axis_data_manipulater import AxisDataManipulater
from app.services.cycle_time_calculator.modules.slider_data_manipulater import SliderDataManipulater
from app.services.cycle_time_calculator.modules.stop_position_manipulater import StopPositionManipulater
from app.services.cycle_time_calculator.modules.speed_control import SpeedControl
from app.services.cycle_time_calculator.modules.collision_detecter import CollisionDetecter
from app.services.cycle_time_calculator.modules.shortest_stop_position_setter import ShortestStopPositionSetter

router = APIRouter()


# ---------- 画面 context（STEP1 レイアウト選択 / STEP2 値入力 / STEP3 計算結果） ----------
@router.get("/step1/context", response_model=CycleTimeStep1ContextResponse)
async def get_cycle_time_step1_context(
    request: Request,
    project_id: int = Query(...),
    db: Session = Depends(get_db),
    current_user: MUser = Depends(get_current_user),
):
    """サイクルタイム STEP1 レイアウト選択: project + layouts（ユーザー別）"""
    user_identifier = current_user.user_id or current_user.mail_address or current_user.user_name or ""
    ctx = vts_service.get_cycle_time_step1_context(db, user_identifier, project_id)
    if ctx is None:
        raise_http_exception(
            error_code=ErrorCode.CYCLE_TIME_CONTEXT_NOT_FOUND,
            status_code=status.HTTP_404_NOT_FOUND,
            request=request,
        )
    return ctx


@router.get("/step2/context", response_model=CycleTimeStep2ContextResponse)
async def get_cycle_time_step2_context(
    request: Request,
    project_id: int = Query(...),
    layout_id: int = Query(...),
    db: Session = Depends(get_db),
    current_user: MUser = Depends(get_current_user),
):
    """サイクルタイム STEP2 値入力: project + layout + processes（ユーザー別）"""
    user_identifier = current_user.user_id or current_user.mail_address or current_user.user_name or ""
    ctx = vts_service.get_cycle_time_step2_context(db, user_identifier, project_id, layout_id)
    if ctx is None:
        raise_http_exception(
            error_code=ErrorCode.CYCLE_TIME_CONTEXT_NOT_FOUND,
            status_code=status.HTTP_404_NOT_FOUND,
            request=request,
        )
    return ctx


@router.get("/step3/context", response_model=CycleTimeStep3ContextResponse)
async def get_cycle_time_step3_context(
    request: Request,
    project_id: int = Query(...),
    layout_id: int = Query(...),
    db: Session = Depends(get_db),
    current_user: MUser = Depends(get_current_user),
):
    """サイクルタイム STEP3 計算結果: project + layout + ct_logs（ユーザー別）"""
    user_identifier = current_user.user_id or current_user.mail_address or current_user.user_name or ""
    ctx = vts_service.get_cycle_time_step3_context(db, user_identifier, project_id, layout_id)
    if ctx is None:
        raise_http_exception(
            error_code=ErrorCode.CYCLE_TIME_CONTEXT_NOT_FOUND,
            status_code=status.HTTP_404_NOT_FOUND,
            request=request,
        )
    return ctx


@router.post("/calculate", response_model=CycleTimeCalculateResponse, status_code=status.HTTP_200_OK)
async def calculate_cycle_time(
    request_data: CycleTimeCalculateRequest,
    request: Request
):
    """
    サイクルタイム計算
    
    ユーザ操作画面の入力項目を受け取り、サイクルタイムと生産数を計算する
    """
    try:
        # ユーザ入力データを辞書形式に変換
        user_input_data = {
            'vts_total_length': request_data.vts_total_length,
            'slider_gap': request_data.slider_gap,
            'slider_type': request_data.slider_type,
            'slider_count': request_data.slider_count,
            'circulation_axis_offset': request_data.circulation_axis_offset,
            'circulation_axis_stroke': request_data.circulation_axis_stroke,
            'circulation_axis_speed': request_data.circulation_axis_speed,
            'circulation_axis_acc_decel': request_data.circulation_axis_acc_decel,
            'discharge_speed': request_data.discharge_speed,
            'discharge_acc_decel': request_data.discharge_acc_decel,
            'calculation_range': request_data.calculation_range,
            'control_pattern': request_data.control_pattern,
            'return_trip_available': request_data.return_trip_available,
            'stop_positions': [
                {
                    'point': sp.point,
                    'stop_position': sp.stop_position,
                    'stop_time': sp.stop_time,
                    'maximum_speed': sp.maximum_speed,
                    'acc_deceleration': sp.acc_deceleration
                }
                for sp in request_data.stop_positions
            ]
        }
        
        # 各モジュールのインスタンスを作成（循環参照を避けるため、段階的に初期化）
        # 1. 基本モジュール
        axis_data_manipulater = AxisDataManipulater(user_input_data)
        shortest_stop_position_setter = ShortestStopPositionSetter()
        
        # 2. 一時的なインスタンスを作成（後で更新）
        # MainController は最後に構築するため、一時的に None を渡す
        temp_main_controller = None
        
        # 3. CollisionDetecter（MainControllerへの参照は後で設定）
        collision_detecter = CollisionDetecter(
            axis_data_manipulater,
            None,  # slider_data_manipulaterは後で設定
            temp_main_controller
        )
        
        # 4. SpeedControl（MainControllerへの参照は後で設定）
        speed_control = SpeedControl(
            axis_data_manipulater,
            None,  # slider_data_manipulaterは後で設定
            collision_detecter,
            temp_main_controller
        )
        
        # 5. StopPositionManipulater
        stop_position_manipulater = StopPositionManipulater(
            user_input_data,
            axis_data_manipulater,
            None,  # slider_data_manipulaterは後で設定
            speed_control
        )
        
        # 6. SliderDataManipulater
        slider_data_manipulater = SliderDataManipulater(
            user_input_data,
            axis_data_manipulater,
            stop_position_manipulater,
            speed_control
        )
        
        # 7. 参照を更新
        speed_control._slider_data_manipulater = slider_data_manipulater
        collision_detecter._slider_data_manipulater = slider_data_manipulater
        stop_position_manipulater._slider_data_manipulater = slider_data_manipulater
        
        # 8. MainControllerを作成
        main_controller = MainController(
            user_input_data,
            axis_data_manipulater,
            slider_data_manipulater,
            stop_position_manipulater,
            speed_control,
            collision_detecter,
            shortest_stop_position_setter
        )
        
        # 9. MainControllerへの参照を更新
        speed_control._main_controller = main_controller
        collision_detecter._main_controller = main_controller
        
        # メイン処理を実行
        result = main_controller.exec()
        
        # 結果をレスポンス形式に変換
        if not result:
            language = get_language_from_request(request)
            raise_http_exception(
                error_code=ErrorCode.INTERNAL_SERVER_ERROR,
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                language=language,
                request=request,
            )
        
        return CycleTimeCalculateResponse(
            cycle_time=result.get('cycle_time', 0.0),
            production_per_hour=result.get('production_per_hour', 0.0),
            production_per_8h=result.get('production_per_8h', 0.0),
            total_laps=result.get('total_laps', 0),
            calculation_time=result.get('calculation_time', 0.0)
        )
        
    except CycleTimeCalculationError as e:
        language = get_language_from_request(request)
        raise_http_exception(
            error_code=e.error_code,
            status_code=status.HTTP_400_BAD_REQUEST,
            language=language,
            request=request,
        )
    except ValueError as e:
        # 既存のValueError経路との後方互換性を維持
        language = get_language_from_request(request)
        raise_http_exception(
            error_code=ErrorCode.BAD_REQUEST,
            status_code=status.HTTP_400_BAD_REQUEST,
            language=language,
            request=request,
        )
    except HTTPException:
        # try ブロック内の raise_http_exception が投げた HTTPException を、広い except Exception で握りつぶさない
        raise
    except Exception as e:
        language = get_language_from_request(request)
        raise_http_exception(
            error_code=ErrorCode.INTERNAL_SERVER_ERROR,
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            language=language,
            request=request,
        )