"""
ホーム画面 API: 画面初期表示用 context
"""
import logging
from fastapi import APIRouter, Depends, Request, HTTPException
from sqlalchemy.orm import Session

from app.core.database import get_db
from app.core.permissions import get_current_user
from app.core.errors import ErrorCode, get_error_message, get_language_from_request
from app.models.vts import MUser
from app.schemas.vts import HomeContextResponse
from app.services.vts_service import get_home_context

router = APIRouter()
logger = logging.getLogger(__name__)


@router.get("/context", response_model=HomeContextResponse)
async def get_home_context_api(
    request: Request,
    current_user: MUser = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """
    ホーム画面初期表示用: プロジェクト一覧を返す（ユーザー別）
    """
    try:
        user_identifier = current_user.user_id or current_user.mail_address or current_user.user_name or ""
        projects = get_home_context(db, user_identifier)
        return HomeContextResponse(projects=projects)
    except Exception as e:
        logger.exception("home/context DB error: %s", e)
        language = get_language_from_request(request)
        message = get_error_message(ErrorCode.INTERNAL_SERVER_ERROR, language)
        raise HTTPException(
            status_code=500,
            detail={
                "error_code": ErrorCode.INTERNAL_SERVER_ERROR.value,
                "message": message,
                "language": language,
                "detail": str(e),
            },
        )
