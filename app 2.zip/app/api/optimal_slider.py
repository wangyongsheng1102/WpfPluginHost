"""
最適スライダ数算出 API。
実装は `CalculationOptimalSliderNumber.py` を基にする。

- 入力: レイアウト関連の 11 パラメータ + `manufacturing_process_list`
- 出力: 参照スクリプトの print 相当 + `start_positions` + `optimum_slider_count_total_value`
"""
from fastapi import APIRouter, status, Request

from app.schemas.optimal_slider import (
    OptimalSliderRequest,
    OptimalSliderResponse,
    StopPositionOutputItem,
    StopTimeOutputItem,
    DivisionLoopItem,
)
from app.core.errors import raise_http_exception, ErrorCode, get_language_from_request
from app.services.optimal_slider_service import (
    calculate,
    build_stops_from_layout,
)

router = APIRouter()


@router.post("/calculate", response_model=OptimalSliderResponse, status_code=status.HTTP_200_OK)
async def calculate_optimal_slider(
    request_data: OptimalSliderRequest,
    request: Request,
):
    """
    最適スライダ数と関連情報を算出する。
    入力は「レイアウト関連の 11 パラメータ + 製造プロセス一覧」であり、参照スクリプト In[3], In[6] と同等である。
    内部で 1 周長と停止位置情報を構築し、計算結果として参照スクリプトの print 相当、各スライダの開始位置、`optimum_slider_count_total_value` を返す。
    """
    try:
        process_list = request_data.manufacturing_process_list or []
        lap, stop_inputs = build_stops_from_layout(
            vts_length=request_data.vts_length,
            cyclical_axis_offset=request_data.cyclical_axis_offset,
            cyclical_axis_stroke=request_data.cyclical_axis_stroke,
            slider_length=request_data.slider_length,
            work_size_w=request_data.work_size_w,
            pallet_size_w=request_data.pallet_size_w,
            controller_pattern=request_data.controller_pattern,
            cyclical_axis_speed=request_data.cyclical_axis_speed,
            cyclical_axis_accel=request_data.cyclical_axis_accel,
            eject_or_retract_speed=request_data.eject_or_retract_speed,
            eject_or_retract_accel=request_data.eject_or_retract_accel,
            manufacturing_process_list=[p.model_dump() for p in process_list],
        )
        result = calculate(lap, stop_inputs)
        if result is None:
            language = get_language_from_request(request)
            raise_http_exception(
                error_code=ErrorCode.BAD_REQUEST,
                status_code=status.HTTP_400_BAD_REQUEST,
                language=language,
                request=request,
            )
        return OptimalSliderResponse(
            stop_position_list_num=result.stop_position_list_num,
            stop_position_list=[
                StopPositionOutputItem(
                    number=d.number,
                    processing_time=d.processing_time,
                    position=d.position,
                    max_speed=d.max_speed,
                    acceleration=d.acceleration,
                    distance=d.distance,
                    circulation_axis_flag=d.circulation_axis_flag,
                )
                for d in result.stop_position_list
            ],
            stop_time_list=[
                StopTimeOutputItem(
                    number=d.number,
                    processing_time=d.processing_time,
                    position=d.position,
                    max_speed=d.max_speed,
                    acceleration=d.acceleration,
                    distance=d.distance,
                    circulation_axis_flag=d.circulation_axis_flag,
                )
                for d in result.stop_time_list
            ],
            max_processing_time=result.max_processing_time,
            total_processing_time=result.total_processing_time,
            other_processing_time=result.other_processing_time,
            division_loop=[
                DivisionLoopItem(
                    division_count=s.division_count,
                    other_processing_time=s.other_processing_time,
                    temp_other_processing_time=s.temp_other_processing_time,
                    max_processing_time=s.max_processing_time,
                )
                for s in result.division_loop
            ],
            optimal_slider_count=result.optimal_slider_count,
            optimum_slider_count_total_value=result.optimal_slider_count,
            start_positions=result.start_positions,
        )
    except ValueError:
        language = get_language_from_request(request)
        raise_http_exception(
            error_code=ErrorCode.BAD_REQUEST,
            status_code=status.HTTP_400_BAD_REQUEST,
            language=language,
            request=request,
        )
    except Exception:
        language = get_language_from_request(request)
        raise_http_exception(
            error_code=ErrorCode.INTERNAL_SERVER_ERROR,
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            language=language,
            request=request,
        )
