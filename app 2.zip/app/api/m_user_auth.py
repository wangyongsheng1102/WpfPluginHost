"""
m_user（vts）を用いたシンプルログイン API（Azure AD / JWT なし）
"""
import logging
from typing import Optional

from fastapi import APIRouter, Depends, Request, status
from sqlalchemy.orm import Session

from app.core.database import get_db
from app.core.errors import ErrorCode, raise_http_exception
from app.schemas.auth import (
    MUserLoginRequest,
    MUserLoginResponse,
    MUserInfo,
)
from app.services.m_user_auth_service import (
    login,
    get_m_user_by_id,
)
from app.models.vts import MUser

logger = logging.getLogger(__name__)

router = APIRouter()


def get_current_m_user_from_header(
    request: Request,
    db: Session = Depends(get_db),
) -> MUser:
    """
    リクエストヘッダの X-User-Id から現在の m_user を取得。
    - ヘッダがない、またはユーザーが存在しない場合は 401 を返す
    """
    user_id = request.headers.get("X-User-Id")
    if not user_id:
        raise_http_exception(
            error_code=ErrorCode.AUTH_REQUIRED,
            status_code=status.HTTP_401_UNAUTHORIZED,
            request=request,
        )
    user = get_m_user_by_id(db, user_id)
    if not user:
        raise_http_exception(
            error_code=ErrorCode.AUTH_USER_NOT_FOUND,
            status_code=status.HTTP_401_UNAUTHORIZED,
            request=request,
        )
    return user


def _muser_to_info(u: MUser) -> MUserInfo:
    return MUserInfo(
        user_id=u.user_id,
        mail_address=u.mail_address,
        user_name=u.user_name,
        role_id=u.role_id,
        language_cd=u.language_cd,
        email_verified=getattr(u, "email_verified", False),
    )


@router.post("/login", response_model=MUserLoginResponse)
def login_api(
    body: MUserLoginRequest,
    request: Request,
    db: Session = Depends(get_db),
):
    """
    ログイン（mail + 明文パスワードで照合）。
    トークンは発行せず、ユーザー情報のみ返す。
    リクエストヘッダに X-User-Id は不要。
    """
    user = login(
        db,
        mail=body.mail,
        password=body.password,
        request=request,
    )
    return MUserLoginResponse(user=_muser_to_info(user))


@router.post("/logout")
def logout_api(request: Request):
    """
    ログアウト。クライアントは access_token / refresh_token を破棄すること。
    サーバー側ではトークン黒名単は行わないため、トークンは有効期限まで有効。
    """
    return {"message": "ログアウトしました。"}


@router.get("/me", response_model=MUserInfo)
def me_api(
    current_user: MUser = Depends(get_current_m_user_from_header),
):
    """現在の m_user 情報を返す（X-User-Id ヘッダ必須）。"""
    return _muser_to_info(current_user)
