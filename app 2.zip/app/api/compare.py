"""
比較画面 API: 画面初期表示用 context
"""
from typing import Optional
from fastapi import APIRouter, Depends, Request, Query, status
from sqlalchemy.orm import Session

from app.core.database import get_db
from app.core.permissions import get_current_user
from app.core.errors import ErrorCode, raise_http_exception
from app.models.vts import MUser
from app.schemas.vts import CompareContextResponse
from app.services import vts_service

router = APIRouter()


@router.get("/context", response_model=CompareContextResponse)
async def get_compare_context(
    request: Request,
    project_id: int = Query(...),
    layout_id: Optional[int] = Query(None, description="省略時は ct_logs なし"),
    db: Session = Depends(get_db),
    current_user: MUser = Depends(get_current_user),
):
    """比較画面: project + layouts + (optional) ct_logs for layout_id（ユーザー別）"""
    try:
        user_identifier = current_user.user_id or current_user.mail_address or current_user.user_name or ""
        ctx = vts_service.get_compare_context(db, user_identifier, project_id, layout_id)
        if ctx is None:
            raise_http_exception(
                error_code=ErrorCode.COMPARE_CONTEXT_NOT_FOUND,
                status_code=status.HTTP_404_NOT_FOUND,
                request=request,
            )
        return ctx
    except Exception as e:
        if hasattr(e, "status_code"):
            raise
        raise_http_exception(
            error_code=ErrorCode.INTERNAL_SERVER_ERROR,
            status_code=500,
            request=request,
        )
