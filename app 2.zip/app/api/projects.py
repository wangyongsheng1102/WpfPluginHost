"""
Projects API: CRUD for Project, Layout, LayoutDesign, Process, ProductList, CTLog
"""
import io
from datetime import datetime
from typing import Literal, Optional
from fastapi import APIRouter, Body, Depends, Request, Query, status
from fastapi.responses import StreamingResponse
from sqlalchemy.orm import Session

from app.core.database import get_db
from app.core.errors import ErrorCode, raise_http_exception
from app.core.exceptions import ProjectNameDuplicateError, ProjectNameEmptyError, ProductNotFoundError
from app.api.m_user_auth import get_current_m_user_from_header
from app.models.vts import MUser
from app.schemas.vts import (
    ProjectCreate,
    ProjectUpdate,
    ProjectCopyRequest,
    ProjectResponse,
    LayoutCreate,
    LayoutUpdate,
    LayoutResponse,
    LayoutDesignUpdate,
    LayoutDesignResponse,
    ProcessCreate,
    ProcessUpdate,
    ProcessResponse,
    ProductListItemCreate,
    ProductListItemUpdate,
    ProductListItemResponse,
    CTLogCreate,
    CTLogUpdate,
    CTLogResponse,
    CTLogDetailCreate,
    CTLogDetailResponse,
    CTLogRecordFlgClearResponse,
    CTHistoryResetResponse,
    ComparisonColumnResponse,
)
from app.services import vts_service

router = APIRouter()


def _user_name(user: Optional[MUser]) -> Optional[str]:
    if not user:
        return None
    return user.user_id


# ---------- Projects ----------
@router.get("", response_model=list[ProjectResponse])
async def list_projects_api(
    request: Request,
    db: Session = Depends(get_db),
    current_user: MUser = Depends(get_current_m_user_from_header),
    search: Optional[str] = Query(None, description="プロジェクト名で曖昧検索"),
    limit: int = Query(50, ge=1, le=200, description="取得件数"),
    offset: int = Query(0, ge=0, description="オフセット"),
    sort_by: Literal["create_date", "update_date", "project_name"] = Query("update_date", description="並び替え項目"),
    order: Literal["asc", "desc"] = Query("desc", description="昇順/降順"),
):
    """プロジェクト一覧（del_flg=False、ユーザー別）。検索・並び替え・ページング対応。"""
    try:
        return vts_service.list_projects(
            db,
            _user_name(current_user),
            search=search,
            limit=limit,
            offset=offset,
            sort_by=sort_by,
            order=order,
        )
    except Exception:
        raise_http_exception(
            error_code=ErrorCode.INTERNAL_SERVER_ERROR,
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            request=request,
        )


@router.get("/{project_id}", response_model=ProjectResponse)
async def get_project_api(
    project_id: int,
    request: Request,
    db: Session = Depends(get_db),
    current_user: MUser = Depends(get_current_m_user_from_header),
):
    """プロジェクト単体取得（ユーザー別）"""
    return vts_service.get_project(db, _user_name(current_user), project_id)


@router.post("", response_model=ProjectResponse, status_code=status.HTTP_201_CREATED)
async def create_project_api(
    body: ProjectCreate,
    request: Request,
    db: Session = Depends(get_db),
    current_user: MUser = Depends(get_current_m_user_from_header),
):
    """プロジェクト作成（ユーザー別）。同一ユーザー内でプロジェクト名は重複不可。"""
    p = vts_service.create_project(db, _user_name(current_user), body)
    from app.schemas.vts import ProjectResponse
    return ProjectResponse(
        project_id=p.project_id,
        project_name=p.project_name,
        del_flg=p.del_flg or False,
        create_date=p.create_date,
        create_user=p.create_user,
        update_date=p.update_date,
        update_user=p.update_user,
    )


@router.patch("/{project_id}", response_model=ProjectResponse)
async def update_project_api(
    project_id: int,
    body: ProjectUpdate,
    request: Request,
    db: Session = Depends(get_db),
    current_user: MUser = Depends(get_current_m_user_from_header),
):
    """プロジェクト更新（ユーザー別）。同一ユーザー内でプロジェクト名は重複不可。削除は DELETE で論理削除。"""
    p = vts_service.update_project(db, _user_name(current_user), project_id, body, update_user=_user_name(current_user))
    return vts_service._project_response(p)


@router.delete("/{project_id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete_project_api(
    project_id: int,
    request: Request,
    db: Session = Depends(get_db),
    current_user: MUser = Depends(get_current_m_user_from_header),
):
    """プロジェクト論理削除（del_flg=True）。Layout/Process/CTLog は残し遡及可能。"""
    vts_service.delete_project(db, _user_name(current_user), project_id)


@router.post("/{project_id}/copy", response_model=ProjectResponse, status_code=status.HTTP_201_CREATED)
async def copy_project_api(
    project_id: int,
    request: Request,
    body: Optional[ProjectCopyRequest] = Body(None),
    db: Session = Depends(get_db),
    current_user: MUser = Depends(get_current_m_user_from_header),
):
    """プロジェクト複製（Layout / LayoutDesign / Process / ProductList / CTLog をすべてコピー）。body.project_name 省略時は「Copy of {元の名前}」。同一ユーザー内でプロジェクト名は重複不可。"""
    if body is None:
        body = ProjectCopyRequest()
    p = vts_service.copy_project(
        db,
        _user_name(current_user),
        project_id,
        new_project_name=body.project_name,
    )
    return vts_service._project_response(p)


# ---------- Layouts ----------
@router.get("/{project_id}/layouts", response_model=list[LayoutResponse])
async def list_layouts_api(
    project_id: int,
    request: Request,
    db: Session = Depends(get_db),
    current_user: MUser = Depends(get_current_m_user_from_header),
):
    """レイアウト一覧（ユーザー別）"""
    return vts_service.list_layouts(db, _user_name(current_user), project_id)


@router.get("/{project_id}/layouts/{layout_id}", response_model=LayoutResponse)
async def get_layout_api(
    project_id: int,
    layout_id: int,
    request: Request,
    db: Session = Depends(get_db),
    current_user: MUser = Depends(get_current_m_user_from_header),
):
    """レイアウト単体取得（ユーザー別）"""
    return vts_service.get_layout(db, _user_name(current_user), project_id, layout_id)


@router.post("/{project_id}/layouts", response_model=LayoutResponse, status_code=status.HTTP_201_CREATED)
async def create_layout_api(
    project_id: int,
    body: LayoutCreate,
    request: Request,
    db: Session = Depends(get_db),
    current_user: MUser = Depends(get_current_m_user_from_header),
):
    """レイアウト作成（ユーザー別）"""
    l = vts_service.create_layout(db, _user_name(current_user), project_id, body)
    return vts_service._layout_response(l)


@router.patch("/{project_id}/layouts/{layout_id}", response_model=LayoutResponse)
async def update_layout_api(
    project_id: int,
    layout_id: int,
    body: LayoutUpdate,
    request: Request,
    db: Session = Depends(get_db),
    current_user: MUser = Depends(get_current_m_user_from_header),
):
    """レイアウト更新（ユーザー別）"""
    l = vts_service.update_layout(db, _user_name(current_user), project_id, layout_id, body, update_user=_user_name(current_user))
    return vts_service._layout_response(l)


# ---------- LayoutDesign ----------
@router.get("/{project_id}/layouts/{layout_id}/design", response_model=LayoutDesignResponse | None)
async def get_layout_design_api(
    project_id: int,
    layout_id: int,
    db: Session = Depends(get_db),
    current_user: MUser = Depends(get_current_m_user_from_header),
):
    """レイアウトデザイン取得（ユーザー別）"""
    return vts_service.get_layout_design(db, _user_name(current_user), project_id, layout_id)


@router.patch("/{project_id}/layouts/{layout_id}/design", response_model=LayoutDesignResponse)
async def update_layout_design_api(
    project_id: int,
    layout_id: int,
    body: LayoutDesignUpdate,
    request: Request,
    db: Session = Depends(get_db),
    current_user: MUser = Depends(get_current_m_user_from_header),
):
    """レイアウトデザイン更新（layout_design JSON, layout_image、ユーザー別）"""
    d = vts_service.upsert_layout_design(db, _user_name(current_user), project_id, layout_id, body, user=_user_name(current_user))
    return vts_service._layout_design_response(d)


# ---------- Processes ----------
@router.get("/{project_id}/layouts/{layout_id}/processes", response_model=list[ProcessResponse])
async def list_processes_api(
    project_id: int,
    layout_id: int,
    db: Session = Depends(get_db),
    current_user: MUser = Depends(get_current_m_user_from_header),
):
    """プロセス一覧（ユーザー別）"""
    return vts_service.list_processes(db, _user_name(current_user), project_id, layout_id)


@router.post("/{project_id}/layouts/{layout_id}/processes/{process_no}", response_model=ProcessResponse, status_code=status.HTTP_201_CREATED)
async def create_process_api(
    project_id: int,
    layout_id: int,
    process_no: int,
    body: ProcessCreate,
    request: Request,
    truck_no: int = Query(..., description="PK"),
    log_no: int = Query(..., description="PK"),
    db: Session = Depends(get_db),
    current_user: MUser = Depends(get_current_m_user_from_header),
):
    """プロセス追加（ユーザー別）。process_no は path、truck_no / log_no は query で必須（update と同様）"""
    p = vts_service.create_process(db, _user_name(current_user), project_id, layout_id, process_no, truck_no, log_no, body)
    return vts_service._process_response(p)


@router.patch("/{project_id}/layouts/{layout_id}/processes/{process_no}", response_model=ProcessResponse)
async def update_process_api(
    project_id: int,
    layout_id: int,
    process_no: int,
    body: ProcessUpdate,
    request: Request,
    truck_no: int = Query(..., description="PK"),
    log_no: int = Query(..., description="PK"),
    db: Session = Depends(get_db),
    current_user: MUser = Depends(get_current_m_user_from_header),
):
    """プロセス更新（PK: process_no, truck_no, log_no、ユーザー別）"""
    p = vts_service.update_process(
        db, _user_name(current_user), project_id, layout_id, process_no, truck_no, log_no, body, update_user=_user_name(current_user)
    )
    return vts_service._process_response(p)


@router.delete("/{project_id}/layouts/{layout_id}/processes/{process_no}", status_code=status.HTTP_204_NO_CONTENT)
async def delete_process_api(
    project_id: int,
    layout_id: int,
    process_no: int,
    request: Request,
    truck_no: int = Query(..., description="PK"),
    log_no: int = Query(..., description="PK"),
    db: Session = Depends(get_db),
    current_user: MUser = Depends(get_current_m_user_from_header),
):
    """プロセス削除（ユーザー別）"""
    vts_service.delete_process(db, _user_name(current_user), project_id, layout_id, process_no, truck_no, log_no)


# ---------- ProductList ----------
@router.get("/{project_id}/layouts/{layout_id}/product-list", response_model=list[ProductListItemResponse])
async def list_product_list_api(
    project_id: int,
    layout_id: int,
    db: Session = Depends(get_db),
    current_user: MUser = Depends(get_current_m_user_from_header),
):
    """部品表一覧（ユーザー別）"""
    return vts_service.list_product_list(db, _user_name(current_user), project_id, layout_id)


@router.post("/{project_id}/layouts/{layout_id}/product-list", response_model=ProductListItemResponse, status_code=status.HTTP_201_CREATED)
async def create_product_list_item_api(
    project_id: int,
    layout_id: int,
    body: ProductListItemCreate,
    request: Request,
    db: Session = Depends(get_db),
    current_user: MUser = Depends(get_current_m_user_from_header),
):
    """部品表行追加（ユーザー別）"""
    item = vts_service.create_product_list_item(db, _user_name(current_user), project_id, layout_id, body)
    return vts_service._product_list_response(item)


@router.patch("/{project_id}/layouts/{layout_id}/product-list/{product_id}", response_model=ProductListItemResponse)
async def update_product_list_item_api(
    project_id: int,
    layout_id: int,
    product_id: int,
    body: ProductListItemUpdate,
    request: Request,
    db: Session = Depends(get_db),
    current_user: MUser = Depends(get_current_m_user_from_header),
):
    """部品表行更新（PK: product_id、ユーザー別）"""
    item = vts_service.update_product_list_item(db, _user_name(current_user), project_id, layout_id, product_id, body, update_user=_user_name(current_user))
    return vts_service._product_list_response(item)


@router.delete("/{project_id}/layouts/{layout_id}/product-list/{product_id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete_product_list_item_api(
    project_id: int,
    layout_id: int,
    product_id: int,
    request: Request,
    db: Session = Depends(get_db),
    current_user: MUser = Depends(get_current_m_user_from_header),
):
    """部品表行削除（product_id で指定、ユーザー別）"""
    vts_service.delete_product_list_item(db, _user_name(current_user), project_id, layout_id, product_id)


@router.get("/{project_id}/layouts/{layout_id}/product-list/export/csv")
async def export_product_list_csv_api(
    project_id: int,
    layout_id: int,
    request: Request,
    language: Literal["ja", "en"] = Query("ja", description="CSVヘッダー言語"),
    db: Session = Depends(get_db),
    current_user: MUser = Depends(get_current_m_user_from_header),
):
    """部品表CSVエクスポート（ユーザー別）。UTF-8 BOM付きでExcel互換。"""
    csv_data = vts_service.export_product_list_csv(
        db, _user_name(current_user), project_id, layout_id, language
    )
    if csv_data is None:
        raise_http_exception(
            error_code=ErrorCode.PRODUCT_LIST_ITEM_NOT_FOUND,
            status_code=status.HTTP_404_NOT_FOUND,
            request=request,
        )
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    filename = f"product_list_{project_id}_{layout_id}_{timestamp}.csv"
    return StreamingResponse(
        io.BytesIO(csv_data.read()),
        media_type="text/csv; charset=utf-8",
        headers={
            "Content-Disposition": f'attachment; filename="{filename}"',
        },
    )


# ---------- Comparison (比較画面) ----------
@router.get("/{project_id}/comparison", response_model=list[ComparisonColumnResponse])
async def get_comparison_api(
    project_id: int,
    request: Request,
    db: Session = Depends(get_db),
    current_user: MUser = Depends(get_current_m_user_from_header),
):
    """比較画面用：プロジェクト配下の全レイアウトの t_layout + t_ct_log_header 最新を返す。"""
    return vts_service.get_comparison_columns(db, _user_name(current_user), project_id)


# ---------- CTLogs ----------
@router.get("/{project_id}/layouts/{layout_id}/ct-logs", response_model=list[CTLogResponse])
async def list_ct_logs_api(
    project_id: int,
    layout_id: int,
    db: Session = Depends(get_db),
    current_user: MUser = Depends(get_current_m_user_from_header),
):
    """CT計算ログ一覧（ユーザー別）"""
    return vts_service.list_ct_logs(db, _user_name(current_user), project_id, layout_id)


@router.post("/{project_id}/layouts/{layout_id}/ct-logs", response_model=CTLogResponse, status_code=status.HTTP_201_CREATED)
async def create_ct_log_api(
    project_id: int,
    layout_id: int,
    body: CTLogCreate,
    request: Request,
    db: Session = Depends(get_db),
    current_user: MUser = Depends(get_current_m_user_from_header),
):
    """CT計算ログ追加（ユーザー別）"""
    c = vts_service.create_ct_log(db, _user_name(current_user), project_id, layout_id, body)
    return vts_service._ct_log_response(c)


@router.post(
    "/{project_id}/layouts/{layout_id}/ct-logs/{log_no}/details",
    response_model=CTLogDetailResponse,
    status_code=status.HTTP_201_CREATED,
)
async def create_ct_log_detail_api(
    project_id: int,
    layout_id: int,
    log_no: int,
    body: CTLogDetailCreate,
    request: Request,
    db: Session = Depends(get_db),
    current_user: MUser = Depends(get_current_m_user_from_header),
):
    """CT計算ログ明細を追加（t_ct_log_detail、ユーザー別）"""
    d = vts_service.create_ct_log_detail(
        db, _user_name(current_user), project_id, layout_id, log_no, body
    )
    return vts_service._ct_log_detail_response(d)


@router.patch("/{project_id}/layouts/{layout_id}/ct-logs/record-flg", response_model=CTLogRecordFlgClearResponse)
async def clear_ct_log_record_flags_api(
    project_id: int,
    layout_id: int,
    request: Request,
    db: Session = Depends(get_db),
    current_user: MUser = Depends(get_current_m_user_from_header),
):
    """指定 project/layout の CT計算ログの record_flg を全件 false にする。"""
    updated = vts_service.clear_ct_log_record_flags(
        db,
        _user_name(current_user),
        project_id,
        layout_id,
        update_user=_user_name(current_user),
    )
    return CTLogRecordFlgClearResponse(updated_count=updated)


@router.post(
    "/{project_id}/layouts/{layout_id}/ct-reset",
    response_model=CTHistoryResetResponse,
    status_code=status.HTTP_200_OK,
)
async def reset_ct_history_api(
    project_id: int,
    layout_id: int,
    db: Session = Depends(get_db),
    current_user: MUser = Depends(get_current_m_user_from_header),
):
    """当該 layout の CT ログ全削除と、log_no!=0 の process 行の物理削除（設計完了後の履歴リセット用）。"""
    counts = vts_service.reset_ct_history(db, _user_name(current_user), project_id, layout_id)
    return CTHistoryResetResponse(**counts)


@router.patch("/{project_id}/layouts/{layout_id}/ct-logs/{log_no}", response_model=CTLogResponse)
async def update_ct_log_api(
    project_id: int,
    layout_id: int,
    log_no: int,
    body: CTLogUpdate,
    request: Request,
    db: Session = Depends(get_db),
    current_user: MUser = Depends(get_current_m_user_from_header),
):
    """CT計算ログ更新（ユーザー別）"""
    c = vts_service.update_ct_log(db, _user_name(current_user), project_id, layout_id, log_no, body, update_user=_user_name(current_user))
    return vts_service._ct_log_response(c)


@router.delete("/{project_id}/layouts/{layout_id}/ct-logs/{log_no}", status_code=status.HTTP_204_NO_CONTENT)
async def delete_ct_log_api(
    project_id: int,
    layout_id: int,
    log_no: int,
    request: Request,
    db: Session = Depends(get_db),
    current_user: MUser = Depends(get_current_m_user_from_header),
):
    """CT計算ログ削除（ユーザー別）"""
    vts_service.delete_ct_log(db, _user_name(current_user), project_id, layout_id, log_no)
