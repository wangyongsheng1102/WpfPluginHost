"""
製品APIルート（m_Product ベース）

m_Product は product_type_id で m_ProductType を参照する。
登録・更新・削除（論理削除）対応。
"""
from fastapi import APIRouter, Depends, Query, Request, status
from sqlalchemy import or_
from sqlalchemy.orm import Session, joinedload
from typing import Optional, List

from app.core.database import get_db
from app.core.errors import ErrorCode, get_language_from_request, raise_http_exception
from app.core.product_locale import resolve_product_name, resolve_product_type_name
from app.models.vts import MProduct, MProductType
from app.schemas.vts import (
    MProductResponse,
    MProductTypeResponse,
    MProductCreate,
    MProductUpdate,
    MProductI18nNamesResponse,
    MProductI18nNamesUpdate,
)
from app.schemas.product import ProductListResponse

router = APIRouter()


def _to_m_product_response(p: MProduct, language: str = "ja") -> MProductResponse:
    """MProduct（product_type_rel 読み込み済み想定）を MProductResponse に変換"""
    return MProductResponse(
        product_id=p.product_id,
        product_name=resolve_product_name(p, language),
        product_name_en=(p.product_name_en.strip() if p.product_name_en else None),
        product_isome_image=p.product_isome_image,
        product_side_view_image=p.product_side_view_image,
        product_top_view_image=p.product_top_view_image,
        product_type_id=p.product_type_id,
        product_type_name=resolve_product_type_name(p.product_type_rel, language),
        product_type_name_en=(
            p.product_type_rel.product_type_name_en.strip()
            if p.product_type_rel and p.product_type_rel.product_type_name_en
            else None
        ),
        product_model=p.product_model,
        product_code=p.product_code,
        min_cycle_time=p.min_cycle_time,
        stroke=p.stroke,
        list_price=p.list_price,
        del_flg=bool(p.del_flg),
    )


def _to_m_product_type_response(t: MProductType, language: str = "ja") -> MProductTypeResponse:
    """MProductType をレスポンス用に変換（言語に応じて product_type_name を切替）"""
    return MProductTypeResponse(
        product_type_id=t.product_type_id,
        product_type_name=(resolve_product_type_name(t, language) or ""),
        product_type_name_en=(t.product_type_name_en.strip() if t.product_type_name_en else None),
        sort_no=t.sort_no,
        del_flg=bool(t.del_flg),
        create_date=t.create_date,
        create_user=t.create_user,
        update_date=t.update_date,
        update_user=t.update_user,
    )


@router.get("/", response_model=ProductListResponse)
async def list_products(
    request: Request,
    type_id: Optional[int] = Query(None, description="製品種類ID（product_type_id でフィルタ、m_ProductType の ID）"),
    type_name: Optional[str] = Query(None, description="製品種類名称（m_ProductType.product_type_name でフィルタ、type_id より優先されない）"),
    del_flg: Optional[bool] = Query(
        None,
        description="削除フラグで絞り込み。未指定時は未削除（del_flg=False）のみ。true=削除済みのみ、false=未削除のみ。",
    ),
    db: Session = Depends(get_db),
):
    """
    製品リストを取得（m_Product ベース）
    公開インターフェース、認証不要
    """
    query = (
        db.query(MProduct)
        .options(joinedload(MProduct.product_type_rel))
    )
    # del_flg 未指定: 従来どおり未削除のみ
    if del_flg is None:
        query = query.filter(MProduct.del_flg == False)
    else:
        query = query.filter(MProduct.del_flg == del_flg)
    if type_id is not None:
        query = query.filter(MProduct.product_type_id == type_id)
    elif type_name and type_name.strip():
        tn = type_name.strip()
        query = query.join(MProductType, MProduct.product_type_id == MProductType.product_type_id).filter(
            or_(MProductType.product_type_name == tn, MProductType.product_type_name_en == tn)
        )
    rows = query.order_by(MProduct.product_code).all()
    lang = get_language_from_request(request)
    items = [_to_m_product_response(p, lang) for p in rows]
    return {
        "total": len(items),
        "items": items,
    }


@router.post("/", response_model=MProductResponse, status_code=status.HTTP_201_CREATED)
async def create_product(
    body: MProductCreate,
    request: Request,
    db: Session = Depends(get_db),
):
    """製品を登録（m_Product）"""
    product = MProduct(
        product_name=body.product_name,
        product_name_en=body.product_name_en,
        product_type_id=body.product_type_id,
        product_model=body.product_model,
        product_code=body.product_code,
        min_cycle_time=body.min_cycle_time,
        stroke=body.stroke,
        list_price=body.list_price,
        product_isome_image=body.product_isome_image,
        product_side_view_image=body.product_side_view_image,
        product_top_view_image=body.product_top_view_image,
        del_flg=False,
    )
    db.add(product)
    db.commit()
    db.refresh(product)
    product = (
        db.query(MProduct)
        .options(joinedload(MProduct.product_type_rel))
        .filter(MProduct.product_id == product.product_id)
        .first()
    )
    return _to_m_product_response(product, get_language_from_request(request))


@router.get("/types", response_model=List[MProductTypeResponse])
async def list_product_types(
    request: Request,
    db: Session = Depends(get_db),
):
    """
    製品種類一覧を取得（m_ProductType ベース）
    公開インターフェース、認証不要
    """
    types = (
        db.query(MProductType)
        .filter(MProductType.del_flg == False)
        .order_by(MProductType.sort_no.nulls_last())   # sort_no 昇順、NULL は最後
        .all()
    )
    lang = get_language_from_request(request)
    return [_to_m_product_type_response(t, lang) for t in types]


@router.get("/{product_id}", response_model=MProductResponse)
async def get_product(
    product_id: int,
    request: Request,
    db: Session = Depends(get_db),
):
    """
    製品詳細を取得（m_Product ベース）
    公開インターフェース、認証不要
    """
    product = (
        db.query(MProduct)
        .options(joinedload(MProduct.product_type_rel))
        .filter(
            MProduct.product_id == product_id,
            MProduct.del_flg == False,
        )
        .first()
    )
    if not product:
        raise_http_exception(
            error_code=ErrorCode.PRODUCT_NOT_FOUND,
            status_code=404,
            request=request,
        )
    return _to_m_product_response(product, get_language_from_request(request))


@router.patch("/{product_id}", response_model=MProductResponse)
async def update_product(
    product_id: int,
    body: MProductUpdate,
    request: Request,
    db: Session = Depends(get_db),
):
    """製品を更新（m_Product）"""
    product = (
        db.query(MProduct)
        .options(joinedload(MProduct.product_type_rel))
        .filter(MProduct.product_id == product_id, MProduct.del_flg == False)
        .first()
    )
    if not product:
        raise_http_exception(
            error_code=ErrorCode.PRODUCT_NOT_FOUND,
            status_code=404,
            request=request,
        )
    data = body.model_dump(exclude_unset=True)
    for k, v in data.items():
        setattr(product, k, v)
    db.commit()
    db.refresh(product)
    return _to_m_product_response(product, get_language_from_request(request))


@router.get("/{product_id}/i18n-names", response_model=MProductI18nNamesResponse)
async def get_product_i18n_names(
    product_id: int,
    request: Request,
    db: Session = Depends(get_db),
):
    """
    製品名（日本語/英語）を両方返すための API（特殊编辑场面用）

    Accept-Language は無視し、常に product_name / product_name_en を返す。
    """
    product = (
        db.query(MProduct)
        .options(joinedload(MProduct.product_type_rel))
        .filter(MProduct.product_id == product_id, MProduct.del_flg == False)
        .first()
    )
    if not product:
        raise_http_exception(
            error_code=ErrorCode.PRODUCT_NOT_FOUND,
            status_code=404,
            request=request,
        )

    ptype = product.product_type_rel
    return MProductI18nNamesResponse(
        product_id=product.product_id,
        product_name=product.product_name,
        product_name_en=product.product_name_en,
        product_isome_image=product.product_isome_image,
        product_side_view_image=product.product_side_view_image,
        product_top_view_image=product.product_top_view_image,
        product_type_id=product.product_type_id,
        product_type_name=ptype.product_type_name if ptype else None,
        product_type_name_en=ptype.product_type_name_en if ptype else None,
        product_model=product.product_model,
        product_code=product.product_code,
        min_cycle_time=product.min_cycle_time,
        stroke=product.stroke,
        list_price=product.list_price,
        del_flg=bool(product.del_flg),
    )


@router.patch("/{product_id}/i18n-names", response_model=MProductI18nNamesResponse)
async def update_product_i18n_names(
    product_id: int,
    body: MProductI18nNamesUpdate,
    request: Request,
    db: Session = Depends(get_db),
):
    """
    製品名（日本語/英語）を同時に更新する API（特殊编辑场面用）

    Accept-Language は無視し、常に両フィールドを更新する。
    """
    product = (
        db.query(MProduct)
        .options(joinedload(MProduct.product_type_rel))
        .filter(MProduct.product_id == product_id, MProduct.del_flg == False)
        .first()
    )
    if not product:
        raise_http_exception(
            error_code=ErrorCode.PRODUCT_NOT_FOUND,
            status_code=404,
            request=request,
        )

    product.product_name = body.product_name
    product.product_name_en = body.product_name_en
    db.commit()
    db.refresh(product)
    ptype = product.product_type_rel

    return MProductI18nNamesResponse(
        product_id=product.product_id,
        product_name=product.product_name,
        product_name_en=product.product_name_en,
        product_isome_image=product.product_isome_image,
        product_side_view_image=product.product_side_view_image,
        product_top_view_image=product.product_top_view_image,
        product_type_id=product.product_type_id,
        product_type_name=ptype.product_type_name if ptype else None,
        product_type_name_en=ptype.product_type_name_en if ptype else None,
        product_model=product.product_model,
        product_code=product.product_code,
        min_cycle_time=product.min_cycle_time,
        stroke=product.stroke,
        list_price=product.list_price,
        del_flg=bool(product.del_flg),
    )


@router.delete("/{product_id}", status_code=status.HTTP_200_OK)
async def delete_product(
    product_id: int,
    request: Request,
    db: Session = Depends(get_db),
):
    """製品を論理削除（m_Product の del_flg を True に）"""
    product = (
        db.query(MProduct)
        .filter(MProduct.product_id == product_id, MProduct.del_flg == False)
        .first()
    )
    if not product:
        raise_http_exception(
            error_code=ErrorCode.PRODUCT_NOT_FOUND,
            status_code=404,
            request=request,
        )
    product.del_flg = True
    db.commit()
    return {"detail": "deleted"}


@router.post("/{product_id}/restore", response_model=MProductResponse, status_code=status.HTTP_200_OK)
async def restore_product(
    product_id: int,
    request: Request,
    db: Session = Depends(get_db),
):
    """製品の論理削除を取り消す（m_Product の del_flg を False に戻す）"""
    product = (
        db.query(MProduct)
        .options(joinedload(MProduct.product_type_rel))
        .filter(MProduct.product_id == product_id)
        .first()
    )
    if not product:
        raise_http_exception(
            error_code=ErrorCode.PRODUCT_NOT_FOUND,
            status_code=404,
            request=request,
        )

    product.del_flg = False
    db.commit()
    db.refresh(product)
    return _to_m_product_response(product, get_language_from_request(request))
