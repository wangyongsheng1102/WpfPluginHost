"""
デザイナー画面 API: STEP1～STEP5 の画面初期表示用 context
"""
from typing import List, Literal, Optional
from fastapi import APIRouter, Depends, Request, Query, status
from sqlalchemy.orm import Session

from app.core.database import get_db
from app.core.errors import ErrorCode, get_language_from_request, raise_http_exception
from app.api.m_user_auth import get_current_m_user_from_header
from app.models.vts import MUser
from app.schemas.vts import (
    DesignerStep1ContextResponse,
    DesignerStep2ContextResponse,
    DesignerStep3ContextResponse,
    DesignerStep4ContextResponse,
    DesignerStep3_4ContextResponse,
    DesignerStep5ContextResponse,
    Step5SaveRequest,
    Step5SaveResponse,
    LayoutUniqueCreateRequest,
    LayoutUniqueResponse,
    DesignerSidebarContextResponse,
    MProductResponse,
)
from app.services import vts_service

router = APIRouter()


@router.get("/step1/context", response_model=DesignerStep1ContextResponse)
async def get_designer_step1_context(
    request: Request,
    project_id: Optional[int] = Query(None, description="省略時は新規用 project=null, layouts=[]"),
    db: Session = Depends(get_db),
    current_user: MUser = Depends(get_current_m_user_from_header),
):
    """STEP1 製造目標ライン: project + layouts（ユーザー別）"""
    user_identifier = current_user.user_id
    return vts_service.get_designer_step1_context(db, user_identifier, project_id)


@router.get("/step2/context", response_model=DesignerStep2ContextResponse)
async def get_designer_step2_context(
    request: Request,
    project_id: int = Query(...),
    layout_id: int = Query(...),
    db: Session = Depends(get_db),
    current_user: MUser = Depends(get_current_m_user_from_header),
):
    """STEP2 ワーク・パレット: project + layout（ユーザー別）"""
    user_identifier = current_user.user_id
    return vts_service.get_designer_step2_context(db, user_identifier, project_id, layout_id)


@router.get("/step3/context", response_model=DesignerStep3ContextResponse)
async def get_designer_step3_context(
    request: Request,
    project_id: int = Query(...),
    layout_id: int = Query(...),
    db: Session = Depends(get_db),
    current_user: MUser = Depends(get_current_m_user_from_header),
):
    """STEP3 製造プロセス: project + layout + processes（後方互換性のため、推奨: /step3-4/context）"""
    user_identifier = current_user.user_id
    return vts_service.get_designer_step3_context(db, user_identifier, project_id, layout_id)


@router.get("/step3-4/context", response_model=DesignerStep3_4ContextResponse)
async def get_designer_step3_4_context(
    request: Request,
    project_id: int = Query(...),
    layout_id: int = Query(...),
    db: Session = Depends(get_db),
    current_user: MUser = Depends(get_current_m_user_from_header),
):
    """STEP3/4 統合コンテキスト: project + layout + layout_design + processes（STEP3 と STEP4 は画面上で統合された1ステップ）"""
    user_identifier = current_user.user_id
    return vts_service.get_designer_step3_4_context(db, user_identifier, project_id, layout_id)


@router.get("/step4/context", response_model=DesignerStep4ContextResponse)
async def get_designer_step4_context(
    request: Request,
    project_id: int = Query(...),
    layout_id: int = Query(...),
    db: Session = Depends(get_db),
    current_user: MUser = Depends(get_current_m_user_from_header),
):
    """STEP4 モジュール部: project + layout + layout_design + processes（後方互換性のため、内部で step3-4 を呼び出し）"""
    user_identifier = current_user.user_id
    return vts_service.get_designer_step4_context(db, user_identifier, project_id, layout_id)


@router.get("/step5/context", response_model=DesignerStep5ContextResponse)
async def get_designer_step5_context(
    request: Request,
    project_id: int = Query(...),
    layout_id: int = Query(...),
    db: Session = Depends(get_db),
    current_user: MUser = Depends(get_current_m_user_from_header),
):
    """STEP5 制御配線部: project + layout + layout_design + product_list（ユーザー別）"""
    user_identifier = current_user.user_id
    return vts_service.get_designer_step5_context(db, user_identifier, project_id, layout_id)


@router.post("/step5/save", response_model=Step5SaveResponse, status_code=status.HTTP_201_CREATED)
async def save_designer_step5(
    request: Request,
    body: Step5SaveRequest,
    db: Session = Depends(get_db),
    current_user: MUser = Depends(get_current_m_user_from_header),
):
    """STEP5 完成時の一括保存。キャンバス上のコンポーネント、ケーブル、サイドバーのコンポーネントをすべて保存。"""
    user_identifier = current_user.user_id
    result = vts_service.save_step5(db, user_identifier, body)
    return Step5SaveResponse(**result)


@router.get("/step5/sidebar/products", response_model=List[MProductResponse])
async def get_designer_step5_sidebar_products(
    request: Request,
    category: Literal["controller_unique", "controller", "cable"] = Query(
        ...,
        description="controller_unique/controller=product_type_id 8,9、cable=product_type_id 5,6,7",
    ),
    db: Session = Depends(get_db),
    current_user: MUser = Depends(get_current_m_user_from_header),
):
    """STEP5 制御配線部サイドバー用：m_product 一覧。controller_unique/controller は type 8,9、cable は type 5,6,7。"""
    lang = get_language_from_request(request)
    return vts_service.list_step5_sidebar_products(db, category, lang)


@router.post("/step3-4/layout-unique", response_model=LayoutUniqueResponse, status_code=status.HTTP_201_CREATED)
async def create_layout_unique_api(
    request: Request,
    body: LayoutUniqueCreateRequest,
    db: Session = Depends(get_db),
    current_user: MUser = Depends(get_current_m_user_from_header),
):
    """STEP3/4 レイアウトをユニーク製品として登録。キャンバス上のレイアウト情報を m_prd_user_unique に保存。"""
    user_identifier = current_user.user_id
    lu = vts_service.create_layout_unique(db, user_identifier, body)
    return vts_service.layout_unique_response(lu)


@router.get("/step3-4/sidebar/layout-uniques", response_model=List[LayoutUniqueResponse])
async def get_designer_sidebar_layout_uniques(
    request: Request,
    db: Session = Depends(get_db),
    current_user: MUser = Depends(get_current_m_user_from_header),
):
    """STEP3/4 サイドバー用：ユーザーが作成した layout unique 一覧（m_prd_user_unique）。X-User-Id でユーザーを特定。"""
    return vts_service.list_layout_uniques_responses(db, current_user.user_id)


@router.get("/step3-4/sidebar/products", response_model=List[MProductResponse])
async def get_designer_sidebar_products(
    request: Request,
    category: Literal["module", "accessory"] = Query(..., description="module=モジュール(product_type_id 1,2,3,4), accessory=アクセサリ(product_type_id 11)"),
    db: Session = Depends(get_db),
    current_user: MUser = Depends(get_current_m_user_from_header),
):
    """STEP3/4 サイドバー用：m_product 一覧。category=module でモジュール、category=accessory でアクセサリを取得。"""
    lang = get_language_from_request(request)
    return vts_service.list_sidebar_products(db, category, lang)


@router.get("/step3-4/sidebar/context", response_model=DesignerSidebarContextResponse)
async def get_designer_sidebar_context_api(
    request: Request,
    project_id: int = Query(...),
    layout_id: int = Query(...),
    db: Session = Depends(get_db),
    current_user: MUser = Depends(get_current_m_user_from_header),
):
    """STEP3/4 サイドバー用コンテキスト（循環軸設定・process のみ）。layout_uniques は /sidebar/layout-uniques、modules/アクセサリ は /sidebar/products?category= で取得すること。"""
    user_identifier = current_user.user_id
    return vts_service.get_designer_sidebar_context(db, user_identifier, project_id, layout_id)
