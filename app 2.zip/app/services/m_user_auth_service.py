"""
m_user（vts）を用いた簡易ログインサービス（Azure AD / JWT なし）
"""
from typing import Optional

from sqlalchemy.orm import Session

from app.models.vts import MUser
from app.core.errors import ErrorCode, raise_http_exception
from fastapi import status


def login(
    db: Session,
    mail: str,
    password: str,
    request=None,
) -> MUser:
    """
    シンプルな m_user ログイン:
    - mail（mail_address）と明文パスワードで照合
    - ユーザーが存在しない、またはパスワード不一致の場合は 401 を返す
    """
    user = (
        db.query(MUser)
        .filter(MUser.mail_address == mail, MUser.del_flg == False)
        .first()
    )
    if not user or (user.password or "") != password:
        raise_http_exception(
            error_code=ErrorCode.AUTH_INVALID_CREDENTIALS,
            status_code=status.HTTP_401_UNAUTHORIZED,
            request=request,
        )
    return user


def get_m_user_by_id(db: Session, user_id: str) -> Optional[MUser]:
    """
    user_id から有効な m_user を取得（del_flg=False）。
    見つからない場合は None を返す。
    """
    return (
        db.query(MUser)
        .filter(MUser.user_id == user_id, MUser.del_flg == False)
        .first()
    )

