"""
入力停止位置格納用クラス
InputStopPositionData.cls（VBA）の Python 移植版

[処理概要]
　・ユーザ操作用シートの停止位置データを格納
"""


class InputStopPositionData:
    """
    入力停止位置格納用クラス
    
    VBAのProperty Let/GetをPythonのプロパティに変換
    メンバ変数はPrv（Private）プレフィックスを保持
    """
    
    # クラス名
    CLASS_NAME = "InputStopPositionData"
    
    def __init__(self):
        """
        初期化
        VBAのPrivate変数を初期化
        """
        # 停止位置[mm]
        self._PrvDblStopPosition: float = 0.0
        
        # 最大速度[mm/s]
        self._PrvDblMaximumSpeed: float = 0.0
        
        # 停止時間[s]
        self._PrvDblStopTime: float = 0.0
        
        # 加減速度[mm/s^2]
        self._PrvDblAccDeceleration: float = 0.0
    
    # ===========================================================
    # プロパティ定義
    # VBAのProperty Let/GetをPythonのプロパティに変換
    # ===========================================================
    
    @property
    def dStopPosition(self) -> float:
        """停止位置[mm]を取得"""
        return self._PrvDblStopPosition
    
    @dStopPosition.setter
    def dStopPosition(self, value: float):
        """停止位置[mm]を変更"""
        self._PrvDblStopPosition = value
    
    @property
    def dMaximumSpeed(self) -> float:
        """最大速度[mm/s]を取得"""
        return self._PrvDblMaximumSpeed
    
    @dMaximumSpeed.setter
    def dMaximumSpeed(self, value: float):
        """最大速度[mm/s]を変更"""
        self._PrvDblMaximumSpeed = value
    
    @property
    def dStopTime(self) -> float:
        """停止時間[s]を取得"""
        return self._PrvDblStopTime
    
    @dStopTime.setter
    def dStopTime(self, value: float):
        """停止時間[s]を変更"""
        self._PrvDblStopTime = value
    
    @property
    def dAccDeceleration(self) -> float:
        """加減速度[mm/s^2]を取得"""
        return self._PrvDblAccDeceleration
    
    @dAccDeceleration.setter
    def dAccDeceleration(self, value: float):
        """加減速度[mm/s^2]を変更"""
        self._PrvDblAccDeceleration = value
