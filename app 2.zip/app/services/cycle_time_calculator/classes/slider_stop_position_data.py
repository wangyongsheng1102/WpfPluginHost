"""
スライダ停止位置格納用クラス
SliderStopPositionData.cls（VBA）の Python 移植版

[処理概要]
　・シートで設定した1箇所の停止位置データを格納
"""

from typing import Optional


class SliderStopPositionData:
    """
    スライダ停止位置格納用クラス
    
    VBAのProperty Let/GetをPythonのプロパティに変換
    メンバ変数はPrv（Private）プレフィックスを保持
    """
    
    # クラス名
    CLASS_NAME = "SliderStopPositionData"
    
    def __init__(self):
        """
        初期化
        VBAのPrivate変数を初期化
        """
        # 停止位置ポイント
        self._PrvIntPoint: Optional[int] = None
        self._PrvBlnSetPoint: bool = False
        
        # 停止位置[mm]
        self._PrvDblStopPosition: Optional[float] = None
        self._PrvBlnSetStopPosition: bool = False
        
        # 停止時間[s]
        self._PrvDblStopTime: Optional[float] = None
        self._PrvBlnSetWaitingTime: bool = False
        
        # 最大速度[mm/s]
        self._PrvDblMaximumSpeed: Optional[float] = None
        self._PrvBlnSetMaximumSpeed: bool = False
        
        # 加減速度[mm/s^2]
        self._PrvDblAccDeceleration: Optional[float] = None
        self._PrvBlnSetAccDeceleration: bool = False
        
        # グラフの色番号
        self._PrvIntChartColorNumber: int = 0
    
    # ===========================================================
    # プロパティ定義
    # VBAのProperty Let/GetをPythonのプロパティに変換
    # ===========================================================
    
    @property
    def iPoint(self) -> int:
        """ポイントを取得"""
        return self._PrvIntPoint if self._PrvIntPoint is not None else 0
    
    @iPoint.setter
    def iPoint(self, value: int):
        """ポイントを変更"""
        if not self._PrvBlnSetPoint:
            self._PrvIntPoint = value
            self._PrvBlnSetPoint = True
        else:
            print(f"{self.CLASS_NAME}, ポイントは既に設定されています。")
    
    @property
    def dStopPosition(self) -> float:
        """停止位置[mm]を取得"""
        return self._PrvDblStopPosition if self._PrvDblStopPosition is not None else 0.0
    
    @dStopPosition.setter
    def dStopPosition(self, value: float):
        """停止位置[mm]を変更"""
        if not self._PrvBlnSetStopPosition:
            self._PrvDblStopPosition = value
            self._PrvBlnSetStopPosition = True
        else:
            print(f"{self.CLASS_NAME}, 停止位置[mm]は既に設定されています。")
    
    @property
    def dStopTime(self) -> float:
        """停止時間[s]を取得"""
        return self._PrvDblStopTime if self._PrvDblStopTime is not None else 0.0
    
    @dStopTime.setter
    def dStopTime(self, value: float):
        """停止時間[s]を変更"""
        if not self._PrvBlnSetWaitingTime:
            self._PrvDblStopTime = value
            self._PrvBlnSetWaitingTime = True
        else:
            print(f"{self.CLASS_NAME}, 停止時間[s]は既に設定されています。")
    
    @property
    def dMaximumSpeed(self) -> float:
        """最大速度[mm/s]を取得"""
        return self._PrvDblMaximumSpeed if self._PrvDblMaximumSpeed is not None else 0.0
    
    @dMaximumSpeed.setter
    def dMaximumSpeed(self, value: float):
        """最大速度[mm/s]を変更"""
        if not self._PrvBlnSetMaximumSpeed:
            self._PrvDblMaximumSpeed = value
            self._PrvBlnSetMaximumSpeed = True
        else:
            print(f"{self.CLASS_NAME}, 最大速度[mm/s]は既に設定されています。")
    
    @property
    def dAccDeceleration(self) -> float:
        """加減速度[mm/s^2]を取得"""
        return self._PrvDblAccDeceleration if self._PrvDblAccDeceleration is not None else 0.0
    
    @dAccDeceleration.setter
    def dAccDeceleration(self, value: float):
        """加減速度[mm/s^2]を変更"""
        if not self._PrvBlnSetAccDeceleration:
            self._PrvDblAccDeceleration = value
            self._PrvBlnSetAccDeceleration = True
        else:
            print(f"{self.CLASS_NAME}, 加減速度[mm/s^2]は既に設定されています。")
    
    @property
    def iChartColorNumber(self) -> int:
        """グラフの色番号を取得"""
        return self._PrvIntChartColorNumber
    
    @iChartColorNumber.setter
    def iChartColorNumber(self, value: int):
        """グラフの色番号を変更"""
        self._PrvIntChartColorNumber = value
