"""
スライダデータ格納用クラス
SliderData.cls（VBA）の Python 移植版

[処理概要]
　・シートで設定した1スライダ分のデータを格納
"""

from typing import Optional


class SliderData:
    """
    スライダデータ格納用クラス
    
    VBAのProperty Let/GetをPythonのプロパティに変換
    メンバ変数はPrv（Private）プレフィックスを保持
    """
    
    # クラス名
    CLASS_NAME = "SliderData"
    
    def __init__(self):
        """
        初期化
        VBAのPrivate変数を初期化
        """
        # ID
        self._PrvIntId: Optional[int] = None
        self._PrvBlnSetId: bool = False
        
        # スライダサイズ[mm]
        self._PrvDblSliderSize: Optional[float] = None
        self._PrvBlnSetSliderLength: bool = False
        
        # 現在速度[mm/s]
        self._PrvDblCurrentSpeed: float = 0.0
        
        # 現在位置[mm]
        self._PrvDblCurrentPosition: float = 0.0
        
        # 最短停止位置[mm]
        self._PrvDblShortestStopPosition: float = 0.0
        
        # タスクのポイント位置[mm]
        self._PrvDblTaskPointPosition: float = 0.0
        
        # 停止時間[s]
        self._PrvDblStopTime: float = 0.0
        
        # 処理時間[s]
        self._PrvDblProcessingTime: float = 0.0
        
        # 循環回数
        self._PrvIntLap: int = 0
        
        # 状態
        self._PrvIntState: int = 0
        
        # サイクルタイム計測開始位置[mm]
        self._PrvDblCycleTimeMeasurementStartPosition: float = 0.0
        
        # 停止位置ポイント
        self._PrvIntStopPositionPoint: int = 0
        
        # 総移動距離[mm]
        self._PrvDblTotalTraveledDistance: float = 0.0
        
        # 前回の現在位置[mm]
        self._PrvDblLastTimeCurrentPosition: float = 0.0
        
        # 前回の停止位置ポイント
        self._PrvDblLastStopPositionPoint: float = 0.0
        
        # 加減速度[mm/s^2]
        self._PrvDblAccDeceleration: float = 0.0
        
        # 加速ポイント位置[mm]
        self._PrvDblAccelerationPointPosition: float = 0.0
        
        # 等速ポイント位置[mm]
        self._PrvDblConstantSpeedPointPosition: float = 0.0
        
        # 減速ポイント位置[mm]
        self._PrvDblDecelerationPointPosition: float = 0.0
        
        # 目標位置[mm]
        self._PrvDblTargetPosition: float = 0.0
        
        # 目標位置移動距離[mm]
        self._PrvDblTargetPositionTraveledDistance: float = 0.0
        
        # 状態変更開始時間[s]
        self._PrvDblStatusChangeStartTime: float = 0.0
        
        # 加速開始時間[s]
        self._PrvDblAccelerationStartTime: float = 0.0
        
        # 等速開始時間[s]
        self._PrvDblConstantSpeedStartTime: float = 0.0
        
        # 減速開始時間[s]
        self._PrvDblDecelerationStartTime: float = 0.0
        
        # 速度制御の形
        self._PrvIntSpeedControlShape: int = 0
        
        # 加速状態
        self._PrvIntAccelerationState: int = 0
        
        # 最大速度[mm/s]
        self._PrvDblMaximumSpeed: float = 0.0
        
        # 加速時間[s]
        self._PrvDblAccelerationTime: float = 0.0
        
        # 等速時間[s]
        self._PrvDblConstantSpeedTime: float = 0.0
        
        # 減速時間[s]
        self._PrvDblDecelerationTime: float = 0.0
        
        # 前回の速度[mm/s]
        self._PrvDblLastCurrentSpeed: float = 0.0
    
    # ===========================================================
    # プロパティ定義
    # VBAのProperty Let/GetをPythonのプロパティに変換
    # ===========================================================
    
    @property
    def iId(self) -> int:
        """IDを取得"""
        return self._PrvIntId if self._PrvIntId is not None else 0
    
    @iId.setter
    def iId(self, value: int):
        """IDを変更"""
        if not self._PrvBlnSetId:
            self._PrvIntId = value
            self._PrvBlnSetId = True
        else:
            print(f"{self.CLASS_NAME}, IDは既に設定されています。")
    
    @property
    def dSliderSize(self) -> float:
        """スライダサイズ[mm]を取得"""
        return self._PrvDblSliderSize if self._PrvDblSliderSize is not None else 0.0
    
    @dSliderSize.setter
    def dSliderSize(self, value: float):
        """スライダサイズ[mm]を変更"""
        if not self._PrvBlnSetSliderLength:
            self._PrvDblSliderSize = value
            self._PrvBlnSetSliderLength = True
        else:
            print(f"{self.CLASS_NAME}, テーブルサイズ[mm]は既に設定されています。")
    
    @property
    def dCurrentSpeed(self) -> float:
        """現在速度[mm/s]を取得"""
        return self._PrvDblCurrentSpeed
    
    @dCurrentSpeed.setter
    def dCurrentSpeed(self, value: float):
        """現在速度[mm/s]を変更"""
        self._PrvDblCurrentSpeed = value
    
    @property
    def dCurrentPosition(self) -> float:
        """現在位置[mm]を取得"""
        return self._PrvDblCurrentPosition
    
    @dCurrentPosition.setter
    def dCurrentPosition(self, value: float):
        """現在位置[mm]を変更"""
        self._PrvDblCurrentPosition = value
    
    @property
    def dShortestStopPosition(self) -> float:
        """最短停止位置[mm]を取得"""
        return self._PrvDblShortestStopPosition
    
    @dShortestStopPosition.setter
    def dShortestStopPosition(self, value: float):
        """最短停止位置[mm]を変更"""
        self._PrvDblShortestStopPosition = value
    
    @property
    def dTaskPointPosition(self) -> float:
        """タスクのポイント位置[mm]を取得"""
        return self._PrvDblTaskPointPosition
    
    @dTaskPointPosition.setter
    def dTaskPointPosition(self, value: float):
        """タスクのポイント位置[mm]を変更"""
        self._PrvDblTaskPointPosition = value
    
    @property
    def dStopTime(self) -> float:
        """停止時間[s]を取得"""
        return self._PrvDblStopTime
    
    @dStopTime.setter
    def dStopTime(self, value: float):
        """停止時間[s]を変更"""
        self._PrvDblStopTime = value
    
    @property
    def dProcessingTime(self) -> float:
        """処理時間[s]を取得"""
        return self._PrvDblProcessingTime
    
    @dProcessingTime.setter
    def dProcessingTime(self, value: float):
        """処理時間[s]を変更"""
        self._PrvDblProcessingTime = value
    
    @property
    def iLap(self) -> int:
        """循環回数を取得"""
        return self._PrvIntLap
    
    @iLap.setter
    def iLap(self, value: int):
        """循環回数を変更"""
        self._PrvIntLap = value
    
    @property
    def iState(self) -> int:
        """状態を取得"""
        return self._PrvIntState
    
    @iState.setter
    def iState(self, value: int):
        """状態を変更"""
        self._PrvIntState = value
    
    @property
    def dCycleTimeMeasurementStartPosition(self) -> float:
        """サイクルタイム計測開始位置[mm]を取得"""
        return self._PrvDblCycleTimeMeasurementStartPosition
    
    @dCycleTimeMeasurementStartPosition.setter
    def dCycleTimeMeasurementStartPosition(self, value: float):
        """サイクルタイム計測開始位置[mm]を変更"""
        self._PrvDblCycleTimeMeasurementStartPosition = value
    
    @property
    def iStopPositionPoint(self) -> int:
        """停止位置ポイントを取得"""
        return self._PrvIntStopPositionPoint
    
    @iStopPositionPoint.setter
    def iStopPositionPoint(self, value: int):
        """停止位置ポイントを変更"""
        self._PrvIntStopPositionPoint = value
    
    @property
    def dTotalTraveledDistance(self) -> float:
        """総移動距離を取得"""
        return self._PrvDblTotalTraveledDistance
    
    @dTotalTraveledDistance.setter
    def dTotalTraveledDistance(self, value: float):
        """総移動距離を変更"""
        self._PrvDblTotalTraveledDistance = value
    
    @property
    def dLastTimeCurrentPosition(self) -> float:
        """前回の現在位置[mm]を取得"""
        return self._PrvDblLastTimeCurrentPosition
    
    @dLastTimeCurrentPosition.setter
    def dLastTimeCurrentPosition(self, value: float):
        """前回の現在位置[mm]を変更"""
        self._PrvDblLastTimeCurrentPosition = value
    
    @property
    def dLastStopPositionPoint(self) -> float:
        """前回の停止位置ポイントを取得"""
        return self._PrvDblLastStopPositionPoint
    
    @dLastStopPositionPoint.setter
    def dLastStopPositionPoint(self, value: float):
        """前回の停止位置ポイントを変更"""
        self._PrvDblLastStopPositionPoint = value
    
    @property
    def dAccDeceleration(self) -> float:
        """加減速度[mm/s^2]を取得"""
        return self._PrvDblAccDeceleration
    
    @dAccDeceleration.setter
    def dAccDeceleration(self, value: float):
        """加減速度[mm/s^2]を変更"""
        self._PrvDblAccDeceleration = value
    
    @property
    def dAccelerationPointPosition(self) -> float:
        """加速ポイント位置[mm]を取得"""
        return self._PrvDblAccelerationPointPosition
    
    @dAccelerationPointPosition.setter
    def dAccelerationPointPosition(self, value: float):
        """加速ポイント位置[mm]を変更"""
        self._PrvDblAccelerationPointPosition = value
    
    @property
    def dConstantSpeedPointPosition(self) -> float:
        """等速ポイント位置[mm]を取得"""
        return self._PrvDblConstantSpeedPointPosition
    
    @dConstantSpeedPointPosition.setter
    def dConstantSpeedPointPosition(self, value: float):
        """等速ポイント位置[mm]を変更"""
        self._PrvDblConstantSpeedPointPosition = value
    
    @property
    def dDecelerationPointPosition(self) -> float:
        """減速ポイント位置[mm]を取得"""
        return self._PrvDblDecelerationPointPosition
    
    @dDecelerationPointPosition.setter
    def dDecelerationPointPosition(self, value: float):
        """減速ポイント位置[mm]を変更"""
        self._PrvDblDecelerationPointPosition = value
    
    @property
    def dTargetPosition(self) -> float:
        """目標位置[mm]を取得"""
        return self._PrvDblTargetPosition
    
    @dTargetPosition.setter
    def dTargetPosition(self, value: float):
        """目標位置[mm]を変更"""
        self._PrvDblTargetPosition = value
    
    @property
    def dTargetPositionTraveledDistance(self) -> float:
        """目標位置移動距離[mm]を取得"""
        return self._PrvDblTargetPositionTraveledDistance
    
    @dTargetPositionTraveledDistance.setter
    def dTargetPositionTraveledDistance(self, value: float):
        """目標位置移動距離[mm]を変更"""
        self._PrvDblTargetPositionTraveledDistance = value
    
    @property
    def dStatusChangeStartTime(self) -> float:
        """状態変更開始時間[s]を取得"""
        return self._PrvDblStatusChangeStartTime
    
    @dStatusChangeStartTime.setter
    def dStatusChangeStartTime(self, value: float):
        """状態変更開始時間[s]を変更"""
        self._PrvDblStatusChangeStartTime = value
    
    @property
    def dAccelerationStartTime(self) -> float:
        """加速開始時間[s]を取得"""
        return self._PrvDblAccelerationStartTime
    
    @dAccelerationStartTime.setter
    def dAccelerationStartTime(self, value: float):
        """加速開始時間[s]を変更"""
        self._PrvDblAccelerationStartTime = value
    
    @property
    def dConstantSpeedStartTime(self) -> float:
        """等速開始時間[s]を取得"""
        return self._PrvDblConstantSpeedStartTime
    
    @dConstantSpeedStartTime.setter
    def dConstantSpeedStartTime(self, value: float):
        """等速開始時間[s]を変更"""
        self._PrvDblConstantSpeedStartTime = value
    
    @property
    def dDecelerationStartTime(self) -> float:
        """減速開始時間[s]を取得"""
        return self._PrvDblDecelerationStartTime
    
    @dDecelerationStartTime.setter
    def dDecelerationStartTime(self, value: float):
        """減速開始時間[s]を変更"""
        self._PrvDblDecelerationStartTime = value
    
    @property
    def iSpeedControlShape(self) -> int:
        """速度制御の形を取得"""
        return self._PrvIntSpeedControlShape
    
    @iSpeedControlShape.setter
    def iSpeedControlShape(self, value: int):
        """速度制御の形を変更"""
        self._PrvIntSpeedControlShape = value
    
    @property
    def iAccelerationState(self) -> int:
        """加速状態を取得"""
        return self._PrvIntAccelerationState
    
    @iAccelerationState.setter
    def iAccelerationState(self, value: int):
        """加速状態を変更"""
        self._PrvIntAccelerationState = value
    
    @property
    def dMaximumSpeed(self) -> float:
        """最大速度[mm/s]を取得"""
        return self._PrvDblMaximumSpeed
    
    @dMaximumSpeed.setter
    def dMaximumSpeed(self, value: float):
        """最大速度[mm/s]を変更"""
        self._PrvDblMaximumSpeed = value
    
    @property
    def dAccelerationTime(self) -> float:
        """加速時間[s]を取得"""
        return self._PrvDblAccelerationTime
    
    @dAccelerationTime.setter
    def dAccelerationTime(self, value: float):
        """加速時間[s]を変更"""
        self._PrvDblAccelerationTime = value
    
    @property
    def dConstantSpeedTime(self) -> float:
        """等速時間[s]を取得"""
        return self._PrvDblConstantSpeedTime
    
    @dConstantSpeedTime.setter
    def dConstantSpeedTime(self, value: float):
        """等速時間[s]を変更"""
        self._PrvDblConstantSpeedTime = value
    
    @property
    def dDecelerationTime(self) -> float:
        """減速時間[s]を取得"""
        return self._PrvDblDecelerationTime
    
    @dDecelerationTime.setter
    def dDecelerationTime(self, value: float):
        """減速時間[s]を変更"""
        self._PrvDblDecelerationTime = value
    
    @property
    def dLastCurrentSpeed(self) -> float:
        """前回の速度[mm/s]を取得"""
        return self._PrvDblLastCurrentSpeed
    
    @dLastCurrentSpeed.setter
    def dLastCurrentSpeed(self, value: float):
        """前回の速度[mm/s]を変更"""
        self._PrvDblLastCurrentSpeed = value
