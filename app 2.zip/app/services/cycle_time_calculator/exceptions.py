"""
サイクルタイム計算用カスタム例外
"""
from app.core.errors import ErrorCode


class CycleTimeCalculationError(Exception):
    """サイクルタイム計算エラーの基底クラス"""
    
    def __init__(self, error_code: ErrorCode, message: str = None):
        self.error_code = error_code
        self.message = message
        super().__init__(message or error_code.value)
