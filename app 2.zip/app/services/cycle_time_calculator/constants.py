"""
VBA 実装から移植した定数定義
すべてのモジュールで使用される定数を集約する
"""

# ===========================================================
# モジュール名定数
# ===========================================================
MODULE_NAME_MAIN_CONTROLLER = "MainController"
MODULE_NAME_AXIS_DATA_MANIPULATER = "AxisDataGetter"
MODULE_NAME_SLIDER_DATA_MANIPULATER = "SliderDataManipulater"
MODULE_NAME_STOP_POSITION_MANIPULATER = "StopPositionsManipulater"
MODULE_NAME_SPEED_CONTROL = "SpeedControl"
MODULE_NAME_COLLISION_DETECTER = "CollisionDetecter"
MODULE_NAME_SHORTEST_STOP_POSITION_SETTER = "ShortestStopPositionSetter"

# クラス名定数
CLASS_NAME_SLIDER_DATA = "SliderData"
CLASS_NAME_SLIDER_STOP_POSITION_DATA = "SliderStopPositionData"
CLASS_NAME_INPUT_STOP_POSITION_DATA = "InputStopPositionData"

# ===========================================================
# MainController.bas の定数
# ===========================================================
# 最初の停止位置のキー番号
FIRST_STOP_POSITION_KEY = 1

# 距離の単位
CHART_DISTANCE_UNIT = "mm"

# 除算値
DIVISION_VALUE = 2

# 秒数を時間へ変更するパラメータ
CONVERT_SECONDS_TO_HOURS_VALUE = 3600

# 最小シミュレーション時間[s]
SIMULATION_TIME_MAX = 28800

# 日当たり時間[h]
DAYLIGHT_HOURS = 8

# 現在位置の小数点フォーマット桁数
CURRENT_POSITION_DECIMAL_FORMAT_DIGITS = "0.0"

# 処理時間の小数点フォーマット桁数
PROCESSING_TIME_DECIMAL_FORMAT_DIGITS = "0.000000000000000"

# 計算範囲[s]：セル番号
CALCULATION_RANGE_CELL_RANGE = "B12"

# 出力エリアのセル範囲
OUTPUT_CELL_RANGE = "J2:J4"

# 出力：サイクルタイム[s] のセル番号
TAKT_TIME_CELL_RANGE = "J2"

# 出力：生産性[個/h] のセル番号
HOUR_PRODUCTION_CELL_RANGE = "J3"

# 出力：生産数[個/8h] のセル番号
DAILY_PRODUCTION_CELL_RANGE = "J4"

# IDのオフセット値
OFFSET_ID = 1

# 循環回数加算値
CYCLE_COUNT_ADDITION_VALUE = 1

# 差分範囲
DIFFERENCE_RANGE = 3000

# 最大スライダ数
SLIDER_MAXIMUM_NUMBER = 128

# 最初のスライダID
FIRST_SLIDER_ID = 1

# 繰り返しの初期値
COUNT_INITIAL_VALUE = 1

# 表の行オフセット値
OFFSET_ROW = 1

# 距離算出固定値
DISTANCE_CALCULATION_FIXED_VALUE = 0.5

# 折れ線グラフ用の表データのシート名
DISTANCE_CHANGE_TABLE_SHEET_NAME = "折れ線グラフ用要素_最小の処理時間毎の総移動距離の表"

# 折れ線グラフ出力先のシート名
DISTANCE_CHANGE_OUTPUT_SHEET_NAME = "時間と距離の折れ線グラフ"

# 要素=停止位置番号の積み上げグラフのシート名
STOP_POSITION_NUM_STACKED_CHART_SHEET_NAME = "積み上げグラフ用要素_停止位置ポイント"

# 要素=最小の処理時間の積み上げグラフのシート名
PROCESSING_TIME_STACKED_CHART_SHEET_NAME = "積み上げグラフ用要素_最小の処理時間"

# 積み上げグラフ表示先シート名
CHART_DISPLAY_DESTINATION_SHEET_NAME = "停止位置への移動時間と待機時間の積み上げグラフ"

# デバッグ用：各スライダの最小の処理時間のシート名
MINIMUM_PROCESSING_TIME_SHEET_NAME = "デバッグ用要素_各スライダの最小の処理時間"

# デバッグ用：各スライダの目標位置のシート名
TARGET_POSITION_SHEET_NAME = "デバッグ用要素_各スライダの目標位置"

# デバッグ用：各スライダの現在位置のシート名
CURRENT_POSITION_SHEET_NAME = "デバッグ用要素_各スライダの現在位置"

# デバッグ用：各スライダの現在速度のシート名
CURRENT_SPEED_SHEET_NAME = "デバッグ用要素_各スライダの現在速度"

# ユーザ操作用シート名
USER_OPERATION_SHEET_NAME = "ユーザ操作画面"

# ステータス：停止
STOP_VALUE = 0

# ステータス：移動
MOVE_VALUE = 1

# 表への出力開始の行番号
START_OUTPUT_TO_TABLE_ROW = 1

# 表への出力開始の列番号
START_OUTPUT_TO_TABLE_CLM = 3

# 桁落ちの許容差分範囲
ALLOWABLE_DIFFERENCE_RANGE = 0.1

# 初期値
INITIAL_VALUE = 0

# 速度制御の形：「無」
FORMLESS = 0

# 速度制御の形：「線」
LINE = 1

# 速度制御の形：「三角形」
TRIANGLE = 2

# 速度制御の形：「台形」
TRAPEZOID = 3

# 加速状態：「無」
NONE = 0

# 加速状態：「加速」
ACCELERATION = 1

# 加速状態：「等速」
CONSTANT_SPEED = 2

# 加速状態：「減速」
DECELERATION = 3

# デバッグ用ID
DEBUG_ID = 1

# デバッグフラグ
DEBUG_FLAG = False

# デバッグ値:時間無効値
DEBUG_NO_TIME = 100000000

# デバッグ値取得時間（終了時間の2つ前の時間）[s]
DEBUG_START_TIME = DEBUG_NO_TIME

# デバッグ終了時間[s]
DEBUG_END_TIME = DEBUG_NO_TIME

# ===========================================================
# AxisDataManipulater.bas の定数
# ===========================================================
# オプションONボタン
OPTION_ON_BUTTON = "returnON"

# オプションOFFボタン
OPTION_OFF_BUTTON = "returnOFF"

# オン（有効）
OPTION_BUTTON_STATE_ON = 1

# オフ（無効）
OPTION_BUTTON_STATE_OFF = 0

# VTS全長のセル番号
TOTAL_LENGTH_CELL_NUMBER = "B2"

# 循環軸位置オフセット[mm]：セル番号
CIRCULATION_AXIS_POSITION_OFFSET = "B6"

# 循環軸ストローク[mm]：セル番号
CIRCULATION_AXIS_STROKE_CELL_NUMBER = "B7"

# 長さ増加値
INCREASE_VALUE = 2

# ===========================================================
# SliderDataManipulater.bas の定数
# ===========================================================
# シート名
TARGET_SHEET_NAME = "スライダ情報_初期値"

# 位置設定範囲記載シート名
POSITION_SETTING_RANGE_SHEET_NAME = "位置設定範囲"

# 設定値記入を開始する行番号
SETTING_START_ROW = 2

# 設定値入力範囲
SET_VALUE_INPUT_RANGE = "B2:D129"

# スライダの種類設定のセル番号
SLIDER_TYPE_CELL_NUMBER = "B4"

# ショートの名前
SHORT_NAME = "ショート"

# ショートの長さ[mm]
SHORT_LENGTH = 125

# ショートの両端のストッパ長[mm]
SHORT_STOPPERS_LENGTH = 30

# ロングの長さ[mm]
LONG_LENGTH = 200

# ロングの両端のストッパ長[mm]
LONG_STOPPERS_LENGTH = 30

# スライダ数のセル番号
SLIDER_NUMBER_CELL_NUMBER = "B5"

# スライダ最大数のセル番号
SLIDER_MAX_NUMBER_CELL_NUMBER = "J5"

# スライダギャップのセル番号
SLIDER_GAP_CELL_NUMBER = "B3"

# 生産数カウント位置[mm]
PRODUCTION_NUMBER_COUNT_POSITION = 0

# VTS復路ON
RETURN_TRIP_VALID = 1

# スライダ数増加値
SLIDER_NUMBER_INCREMENT = 2

# スライダーの初期位置設定箇所が往路上
SETTING_OUTWARD = 0

# スライダーの初期位置設定箇所が復路上
SETTING_RETURN = 1

# スライダーIDオフセット
SLIDER_ID_OFFSET = 1

# 最初のスライダID
SLIDER_FIRST_ID = 1

# 最初の停止位置番号
POINT_FIRST_NUMBER = 1

# 列のオフセット
CLM_OFFSET = 1

# IDの列
ID_CLM = 1

# テーブルサイズの列
TABLE_SIZE_CLM = ID_CLM + CLM_OFFSET

# 現在位置の列
CURRENT_POSITION_CLM = TABLE_SIZE_CLM + CLM_OFFSET

# 総走行距離の列
TOTAL_MILEAGE_CLM = CURRENT_POSITION_CLM + CLM_OFFSET

# タクトタイム計測開始位置の列
TAKT_TIME_MEASUREMENT_START_POSITION_CLM = TOTAL_MILEAGE_CLM + CLM_OFFSET

# 停止位置番号の列
STOP_POSITION_NUMBER_CLM = TAKT_TIME_MEASUREMENT_START_POSITION_CLM + CLM_OFFSET

# 最短停止位置の列
SHORTEST_STOP_POSITION_CLM = STOP_POSITION_NUMBER_CLM + CLM_OFFSET

# 循環回数の列
LAP_CLM = SHORTEST_STOP_POSITION_CLM + CLM_OFFSET

# 状態の列
STATE_CLM = LAP_CLM + CLM_OFFSET

# 行のオフセット
ROW_OFFSET = 1

# スライダ初期値の表の表頭：ID
FRONT_PAGE_ID = "ID"

# スライダ初期値の表の表頭：テーブルサイズ
FRONT_PAGE_TABLE_SIZE = "テーブルサイズ[mm]"

# スライダ初期値の表の表頭：現在位置
FRONT_PAGE_CURRENT_POSITION = "現在位置[mm]"

# スライダ初期値の表の表頭：総走行距離
FRONT_PAGE_TOTAL_MILEAGE = "総走行距離[mm]"

# スライダ初期値の表の表頭：タクトタイム計測開始位置
FRONT_PAGE_TAKT_TIME_MEASUREMENT_START_POSITION = "タクトタイム計測開始位置[mm]"

# スライダ初期値の表の表頭：停止位置ポイント
FRONT_PAGE_STOP_POSITION_POINT = "停止位置ポイント"

# スライダ初期値の表の表頭：最短停止位置
FRONT_PAGE_SHORTEST_STOP_POSITION = "最短停止位置"

# スライダ初期値の表の表頭：循環回数
FRONT_PAGE_LAP = "循環回数"

# スライダ初期値の表の表頭：状態
FRONT_PAGE_STATE = "状態"

# スライダ下限数
SLIDER_LOWER_LIMIT_NUM_ = 2

# スライダ上限数
SLIDER_UPPER_LIMIT_NUM_ = 128

# 表頭：IDの行
ID_ROW = 1

# 「処理時間」初期値の行
PROCESSING_TIME_INITIA_ROW = 2

# 表の停止位置ポイント初期値の行
STOP_POSITION_POINT_INITIAL_ROW = 2

# 表側の列
FRONT_SIDE_CLM = 1

# 「停止位置ポイント」の最初の番号
FIRST_POINT_NUMBER = 1

# 「処理時間」の初期値
PROCESSING_TIME_INITIAL_VALUE = 0

# ===========================================================
# StopPositionManipulater.bas の定数
# ===========================================================
# 全停止位置情報記載シート名
ALL_STOP_POSITION_INFORMATION_SHEET_NAME = "停止位置情報_設定値"

# 停止位置情報の表の表頭：ポイント
FRONT_PAGE_POINT = "ポイント"

# 停止位置情報の表の表頭：停止位置
FRONT_PAGE_STOP_POSITION = "停止位置[mm]"

# 停止位置情報の表の表頭：停止時間
FRONT_PAGE_WAITING_TIME = "停止時間[s]"

# 停止位置情報の表の表頭：速度
FRONT_PAGE_SPEED = "速度[mm/s]"

# 停止位置情報の表の表頭：加減速度
FRONT_PAGE_ACC_DECELERATION = "加減速度[mm/s^2]"

# 設定値記入を開始する行番号のオフセット
SETTING_START_ROW_OFFSET = 1

# ユーザ操作用シート：停止位置記入を開始する行番号
INPUT_STOP_POSITION_START_ROW = 17

# ユーザ操作用シート：停止位置記入を終了する行番号
INPUT_STOP_POSITION_END_ROW = 272

# ポイント列のテーブル内列番号
POINT_CLM = 1

# 停止位置[mm]列のテーブル内列番号
STOP_POSITION_CLM = POINT_CLM + 1

# 停止時間[s]列のテーブル内列番号
WAITING_TIME_CLM = STOP_POSITION_CLM + 1

# 速度[mm/s]列のテーブル内列番号
SPEED_CLM = WAITING_TIME_CLM + 1

# 加速度[mm/s^2]列のテーブル内列番号
ACCELERATION_CLM = SPEED_CLM + 1

# ユーザ操作用シート：停止位置[mm]列のテーブル内列番号
INPUT_STOP_POSITION_CLM = 2

# ユーザ操作用シート：停止時間[s]列のテーブル内列番号
INPUT_WAITING_TIME_CLM = INPUT_STOP_POSITION_CLM + 1

# ユーザ操作用シート：速度[mm/s]列のテーブル内列番号
INPUT_SPEED_CLM = INPUT_WAITING_TIME_CLM + 1

# ユーザ操作用シート：加速度[mm/s^2]列のテーブル内列番号
INPUT_ACCELERATION_CLM = INPUT_SPEED_CLM + 1

# キー初期値
KEY_INITIAL_VALUE = 1

# キーオフセット
KEY_OFFSET = 1

# キー加算値
KEY_ADD_VALUE = 1

# 最初のスライダID
FIRST_SLIDER_ID_STOP_POSITION = 1

# 作業停止位置数
TASK_STOP_POSITIONS_NUMBER = 256

# 末端停止位置数
END_STOP_POSITIONS_NUMBER = 8

# 作業停止位置の初期値
TASK_STOP_POSITIONS_INITIAL_VALUE = 0

# 循環軸速度[mm/s]：セル番
CIRCULATION_AXIS_SPEED_CELL_NUMBER = "B8"

# 循環軸加減速度[mm/s^2]：セル番
CIRCULATION_AXIS_ACC_DECELERATION_CELL_NUMBER = "B9"

# 排出速度[mm/s]：セル番
RETRACT_EXTRACT_SPEED_CELL_NUMBER = "B10"

# 排出加減速度[mm/s^2]：セル番
RETRACT_EXTRACT_ACC_DECELERATION_CELL_NUMBER = "B11"

# 制御コントローラパターン：セル番
CONTROL_CONTROLLER_PATTERN = "B13"

# 制御コントローラパターン
PATTERN = 1

# 循環軸位置A
CIRCULATION_AXIS_POSITION_A = 0

# 乗数値
MULTIPLIER_VALUE = 2

# 除数値
DIVISOR_VALUE = 2

# 時間算出固定値
TIME_CALCULATION_FIXED_VALUE = 2

# 到達時間算出固定値
ARRIVAL_TIME_CALCULATION_FIXED_VALUE = 8

# 加減速度変更点算出固定値
SWITCHING_SPEED_FIXED_VALUE = 0.5

# 距離算出固定値（StopPositionManipulater用）
DISTANCE_CALCULATION_FIXED_VALUE_STOP_POSITION = 0.5

# 停止時間無し
STOP_TIME_ZERO = 0

# 最大速度[mm/s]
MAX_SPEED = 3000

# 最大加減速度[mm/s^2]
MAX_ACC_DECELERATION = 9000

# 「復路設定範囲の開始位置c」用のID
TEMP_START_POSITION_C_ID_NUM = 1

# 「往路設定範囲の開始位置a」用のID
TEMP_START_POSITION_A_ID_NUM = 2

# ===========================================================
# SpeedControl.bas の定数
# ===========================================================
# 除算値（SpeedControl用）
DIVISION_VALUE_SPEED_CONTROL = 2

# 乗数値（SpeedControl用）
MULTIPLIER_VALUE_SPEED_CONTROL = 2

# 時間算出固定値（SpeedControl用）
TIME_CALCULATION_FIXED_VALUE_SPEED_CONTROL = 2

# 加速状態切り替え速度算出固定値
SWITCHING_SPEED_FIXED_VALUE_SPEED_CONTROL = 0.5

# 距離算出固定値（SpeedControl用）
DISTANCE_CALCULATION_FIXED_VALUE_SPEED_CONTROL = 0.5

# ===========================================================
# CollisionDetecter.bas の定数
# ===========================================================
# 除算値（CollisionDetecter用）
DIVISION_VALUE_COLLISION = 2

# 乗数値（CollisionDetecter用）
MULTIPLIER_VALUE_COLLISION = 2

# 時間算出固定値（CollisionDetecter用）
TIME_CALCULATION_FIXED_VALUE_COLLISION = 2

# 距離算出固定値（CollisionDetecter用）
DISTANCE_CALCULATION_FIXED_VALUE_COLLISION = 0.5

# 衝突無
NO_COLLISION = -1

# 衝突有
COLLISION = 1

# ===========================================================
# ShortestStopPositionSetter.bas の定数
# ===========================================================
# 最初の停止位置番号
FIRST_STOP_POSITION_NUMBER = 1

# ポイントのオフセット値
POINT_OFFSET_VALUE = 1
