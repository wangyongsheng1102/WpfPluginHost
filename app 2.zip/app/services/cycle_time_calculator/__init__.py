"""
VTS サイクルタイム計算機
VBA 実装（CONFIDENTIAL_THK_VTS 向けタクト計算処理 Ver 2.0）の Python 移植版
"""
