"""
軸情報の取得
AxisDataManipulater.bas（VBA）の Python 移植版

[処理概要]
　・ユーザ操作用シートの軸に関連する情報を取得

[索引]
　□1.VTS復路有無の取得
　□2.ON/OFF確認処理
　□3.VTS全長の取得
　□4.循環軸ストロークの取得
　□5.外部モジュールからの循環システム1周分の長さ参照
　□6.外部モジュールからの「循環軸位置オフセット」参照
"""

from .. import constants
from ..constants import (
    MODULE_NAME_AXIS_DATA_MANIPULATER,
    OPTION_ON_BUTTON,
    OPTION_OFF_BUTTON,
    OPTION_BUTTON_STATE_ON,
    OPTION_BUTTON_STATE_OFF,
    TOTAL_LENGTH_CELL_NUMBER,
    CIRCULATION_AXIS_POSITION_OFFSET,
    CIRCULATION_AXIS_STROKE_CELL_NUMBER,
    INCREASE_VALUE,
)


class AxisDataManipulater:
    """
    軸情報の取得クラス
    
    VBAのモジュール関数をクラスのメソッドに変換
    Excelシートからの読み込みは、代わりにパラメータとして受け取る
    """
    
    def __init__(self, user_input_data: dict):
        """
        初期化
        
        Args:
            user_input_data: ユーザ操作画面からの入力データ
                - vts_total_length: VTS全長[mm] (B2)
                - return_trip_available: VTS復路有無 (bool)
                - circulation_axis_offset: 循環軸位置オフセット[mm] (B6)
                - circulation_axis_stroke: 循環軸ストローク[mm] (B7)
        """
        self._user_input_data = user_input_data
        self._return_trip_available = user_input_data.get('return_trip_available', False)
        self._vts_total_length = user_input_data.get('vts_total_length', 0.0)
        self._circulation_axis_offset = user_input_data.get('circulation_axis_offset', 0.0)
        self._circulation_axis_stroke = user_input_data.get('circulation_axis_stroke', 0.0)
    
    # ===========================================================
    # 1.VTS復路有無の取得
    # ===========================================================
    def checkReturnTripAvailable(self) -> int:
        """
        VTS復路有無の取得
        
        Returns:
            int: OPTION_BUTTON_STATE_ON (1) または OPTION_BUTTON_STATE_OFF (0)
        """
        try:
            # VBA相当：wsUserOperationt.OptionButtons(OPTION_ON_BUTTON).Value
            # Python実装：ユーザ入力データから直接取得
            if self._return_trip_available:
                return OPTION_BUTTON_STATE_ON
            else:
                return OPTION_BUTTON_STATE_OFF
        except Exception as e:
            print(f"{MODULE_NAME_AXIS_DATA_MANIPULATER}.checkReturnTripAvailable: Error - {e}")
            return OPTION_BUTTON_STATE_OFF
    
    # ===========================================================
    # 2.ON/OFF確認処理
    # ===========================================================
    def checkOnOff(self, iValue: int) -> int:
        """
        ON/OFF確認処理
        
        Args:
            iValue: 確認する値
            
        Returns:
            int: OPTION_BUTTON_STATE_ON (1) または OPTION_BUTTON_STATE_OFF (0)
        """
        try:
            if iValue == OPTION_BUTTON_STATE_ON:
                return OPTION_BUTTON_STATE_ON
            else:
                return OPTION_BUTTON_STATE_OFF
        except Exception as e:
            print(f"{MODULE_NAME_AXIS_DATA_MANIPULATER}.checkOnOff: Error - {e}")
            return OPTION_BUTTON_STATE_OFF
    
    # ===========================================================
    # 3.VTS全長の取得
    # ===========================================================
    def getTotalLength(self) -> float:
        """
        VTS全長の取得
        
        Returns:
            float: VTS全長[mm]
        """
        try:
            # VBA相当：wsUserOperationt.Range(TOTAL_LENGTH_CELL_NUMBER).Value
            # Python実装：ユーザ入力データから直接取得
            return self._vts_total_length
        except Exception as e:
            print(f"{MODULE_NAME_AXIS_DATA_MANIPULATER}.getTotalLength: Error - {e}")
            return 0.0
    
    # ===========================================================
    # 4.循環軸ストロークの取得
    # ===========================================================
    def getCirculationAxisStroke(self) -> float:
        """
        循環軸ストロークの取得
        
        Returns:
            float: 循環軸ストローク[mm]
        """
        try:
            # VBA相当：wsUserOperationt.Range(CIRCULATION_AXIS_STROKE_CELL_NUMBER).Value
            # Python実装：ユーザ入力データから直接取得
            return self._circulation_axis_stroke
        except Exception as e:
            print(f"{MODULE_NAME_AXIS_DATA_MANIPULATER}.getCirculationAxisStroke: Error - {e}")
            return 0.0
    
    # ===========================================================
    # 5.外部モジュールからの循環システム1周分の長さ参照
    # ===========================================================
    def readOneLap(self, slider_size: float) -> float:
        """
        外部モジュールからの循環システム1周分の長さ参照
        
        Args:
            slider_size: スライダサイズ[mm] (SliderDataManipulater.readSliderSize()から取得)
        
        Returns:
            float: 循環システム1周分の長さ[mm]
        
        計算式:
        「循環システム1周分の長さ」=（「VTS全長」* 2) +（循環ストローク * 2）+（「スライダテーブルサイズ」*2）
        """
        try:
            dTotalLength = self.getTotalLength()
            dCirculationAxisStroke = self.getCirculationAxisStroke()
            
            # 「循環システム1周分の長さ」=（「VTS全長」* 2) +（循環ストローク * 2）+（「スライダテーブルサイズ」*2）
            dOneLap = (dTotalLength * INCREASE_VALUE) + (dCirculationAxisStroke * INCREASE_VALUE) + (slider_size * INCREASE_VALUE)
            
            return dOneLap
        except Exception as e:
            print(f"{MODULE_NAME_AXIS_DATA_MANIPULATER}.readOneLap: Error - {e}")
            return 0.0
    
    # ===========================================================
    # 6.外部モジュールからの「循環軸位置オフセット」参照
    # ===========================================================
    def getCirculationAxisPositionOffset(self) -> float:
        """
        外部モジュールからの「循環軸位置オフセット」参照
        
        Returns:
            float: 循環軸位置オフセット[mm]
        """
        try:
            # VBA相当：wsUserOperationt.Range(CIRCULATION_AXIS_POSITION_OFFSET).Value
            # Python実装：ユーザ入力データから直接取得
            return self._circulation_axis_offset
        except Exception as e:
            print(f"{MODULE_NAME_AXIS_DATA_MANIPULATER}.getCirculationAxisPositionOffset: Error - {e}")
            return 0.0
