"""
VTSサイクルタイム算出用プログラム
MainController.bas（VBA）の Python 移植版

[処理概要]
　・シート内で設定されたスライダと停止位置の情報を取得し、
   サイクルタイムを算出する

[索引]
　□1,メイン処理
　□2,入力処理
　□3.全軸長の参照用モジュール
　□4.VTS上に搭載可能なスライダ数の確認
　□5.「計算範囲」参照用モジュール
　□6.「生産数」と「サイクルタイム」の算出処理
　□7.外部モジュールからの「現在時間」参照
　□8.前方スライダ追い越し確認
　□9.デバッグ：時間指定で計算停止する処理
　□10.現在位置の更新
　□11.目標位置無視確認
　□12.現在速度負の数確認
　□13.排出位置停止判定
"""

import math
import os
from typing import Dict, Optional

from .. import constants
from ..exceptions import CycleTimeCalculationError
from app.core.errors import ErrorCode
from ..constants import (
    MODULE_NAME_MAIN_CONTROLLER,
    FIRST_STOP_POSITION_KEY,
    DIVISION_VALUE,
    CONVERT_SECONDS_TO_HOURS_VALUE,
    SIMULATION_TIME_MAX,
    DAYLIGHT_HOURS,
    CALCULATION_RANGE_CELL_RANGE,
    OFFSET_ID,
    CYCLE_COUNT_ADDITION_VALUE,
    DIFFERENCE_RANGE,
    SLIDER_MAXIMUM_NUMBER,
    FIRST_SLIDER_ID,
    COUNT_INITIAL_VALUE,
    OFFSET_ROW,
    DISTANCE_CALCULATION_FIXED_VALUE,
    ALLOWABLE_DIFFERENCE_RANGE,
    INITIAL_VALUE,
    FORMLESS,
    NONE,
    ACCELERATION,
    CONSTANT_SPEED,
    DECELERATION,
    STOP_VALUE,
    MOVE_VALUE,
    DEBUG_FLAG,
    DEBUG_ID,
    DEBUG_START_TIME,
    DEBUG_END_TIME,
    DEBUG_NO_TIME,
)
from ..classes.slider_data import SliderData
from ..classes.slider_stop_position_data import SliderStopPositionData


class MainController:
    """
    メインコントローラークラス
    
    VBAのモジュール関数をクラスのメソッドに変換
    """
    
    def __init__(
        self,
        user_input_data: dict,
        axis_data_manipulater,
        slider_data_manipulater,
        stop_position_manipulater,
        speed_control,
        collision_detecter,
        shortest_stop_position_setter
    ):
        """
        初期化
        
        Args:
            user_input_data: ユーザ操作画面からの入力データ
            axis_data_manipulater: AxisDataManipulaterインスタンス
            slider_data_manipulater: SliderDataManipulaterインスタンス
            stop_position_manipulater: StopPositionManipulaterインスタンス
            speed_control: SpeedControlインスタンス
            collision_detecter: CollisionDetecterインスタンス
            shortest_stop_position_setter: ShortestStopPositionSetterインスタンス
        """
        self._user_input_data = user_input_data
        self._axis_data_manipulater = axis_data_manipulater
        self._slider_data_manipulater = slider_data_manipulater
        self._stop_position_manipulater = stop_position_manipulater
        self._speed_control = speed_control
        self._collision_detecter = collision_detecter
        self._shortest_stop_position_setter = shortest_stop_position_setter
        
        # 計算範囲[s]
        # VBA相当：Private DblCalculationRange As Double
        self._DblCalculationRange: float = 0.0
        
        # 現在時間時間[s]
        # VBA相当：Private DblCurrentTime As Double
        self._DblCurrentTime: float = 0.0
        
        # 速度制御の形を構築定実行回数
        # VBA相当：Public IntBuildSpeedControlFormExeNumber As Integer
        self._IntBuildSpeedControlFormExeNumber: int = 0
        
        # 衝突判定実行回数
        # VBA相当：Public IntDetectionCollisionExeNumber As Integer
        self._IntDetectionCollisionExeNumber: int = 0
    
    # ===========================================================
    # 1.メイン処理
    # ===========================================================
    def exec(self) -> Dict[str, float]:
        """
        メイン処理
        
        Returns:
            Dict[str, float]: 計算結果
                - cycle_time: サイクルタイム[s]
                - production_per_hour: 生産性[個/h]
                - production_per_8h: 生産数[個/8h]
                - total_laps: 全スライダ循環回数の合計値
                - calculation_time: 計算範囲[s]
        """
        try:
            dMinimumProcessingTime = 0.0
            dShortestPositionDifference = 0.0
            dTaskPointPositionDifference = 0.0
            dTargetPositionDifference = 0.0
            dShortestStopPositionDifference = 0.0
            dLastTimePositionDifference = 0.0
            dTempCurrentPosition = 0.0
            dStopJudgmentResult = 0.0
            iForwardID = 0
            iBackwardID = 0
            isInput = False
            
            # 入力処理
            # VBA相当：isInput = inputProcess()
            isInput = self.inputProcess()
            
            # 入力処理の返り値=Falseか判定：分岐範囲
            if not isInput:
                # 本関数を強制終了
                return {}
            
            # 外部モジュールからのスライダ情報参照
            # VBA相当：Set readSliderData = SliderDataManipulater.readSliderData
            readSliderData = self._slider_data_manipulater.readSliderData()
            
            # 外部モジュールからの停止位置情報参照
            # VBA相当：Set readStopPosition = StopPositionManipulater.readStopPosition
            readStopPosition = self._stop_position_manipulater.readStopPosition()
            
            # 「現在時間」 = 0
            self._DblCurrentTime = 0.0
            
            # 「現在時間」<=「計算範囲」までループ：開始
            # VBA相当：Do While DblCurrentTime <= DblCalculationRange
            while self._DblCurrentTime <= self._DblCalculationRange:
                # スライダ総数分ループ：開始
                # VBA相当：For Each vID In readSliderData.Keys
                for vID in readSliderData.keys():
                    # 「処理時間」= 0か判定：分岐範囲
                    if readSliderData[vID].dProcessingTime == 0:
                        # 「加速状態」= 「加速」か判定：分岐範囲
                        if readSliderData[vID].iAccelerationState == ACCELERATION:
                            # [SWITCHING_START] 加速状態切り替え开始
                            before_proc_time = readSliderData[vID].dProcessingTime
                            before_acc_state = readSliderData[vID].iAccelerationState
                            
                            # 加速状態切り替え
                            # VBA相当：Call SpeedControl.switchingAccelerationState(readSliderData(vID))
                            self._speed_control.switchingAccelerationState(readSliderData[vID])
                            
                            # [SWITCHING_END] 加速状態切り替え结束
                            after_proc_time = readSliderData[vID].dProcessingTime
                            after_acc_state = readSliderData[vID].iAccelerationState
                        
                        # 「加速状態」= 「等速」か判定
                        elif readSliderData[vID].iAccelerationState == CONSTANT_SPEED:
                            # [SWITCHING_START] 加速状態切り替え开始
                            before_proc_time = readSliderData[vID].dProcessingTime
                            before_acc_state = readSliderData[vID].iAccelerationState
                            
                            # 加速状態切り替え
                            # VBA相当：Call SpeedControl.switchingAccelerationState(readSliderData(vID))
                            self._speed_control.switchingAccelerationState(readSliderData[vID])
                            
                            # [SWITCHING_END] 加速状態切り替え结束
                            after_proc_time = readSliderData[vID].dProcessingTime
                            after_acc_state = readSliderData[vID].iAccelerationState
                        
                        # 「加速状態」= 「減速」Or 「加速状態」=「無」か判定
                        elif (readSliderData[vID].iAccelerationState == DECELERATION or
                              readSliderData[vID].iAccelerationState == NONE):
                            # 「最短停止位置差分」=「現在位置」と「最短停止位置」の差分
                            dShortestStopPositionDifference = abs(
                                readSliderData[vID].dCurrentPosition - readSliderData[vID].dShortestStopPosition
                            )
                            
                            # 「最短停止位置差分」 < 「許容差分」か判定：分岐範囲
                            if dShortestStopPositionDifference < ALLOWABLE_DIFFERENCE_RANGE:
                                # 「現在位置」=「最短位置」
                                readSliderData[vID].dCurrentPosition = readSliderData[vID].dShortestStopPosition
                            
                            # 「現在位置」=「最短停止位置」か判定：分岐範囲
                            if readSliderData[vID].dCurrentPosition == readSliderData[vID].dShortestStopPosition:
                                # 「指定ID」= 1か判定：分岐範囲
                                if vID == FIRST_SLIDER_ID:
                                    # 「前方ID」=「最終ID」
                                    iForwardID = len(readSliderData)
                                else:
                                    # 「前方ID」=「指定ID」- 1
                                    iForwardID = vID - OFFSET_ID
                                
                                # 「後方ID」=「指定ID」
                                iBackwardID = vID
                                
                                # 排出位置停止判定
                                # VBA相当：dStopJudgmentResult = judgmentDischargePositionStop(readSliderData(iForwardID).dCurrentPosition, readSliderData(iBackwardID).dCurrentPosition)
                                dStopJudgmentResult = self.judgmentDischargePositionStop(
                                    readSliderData[iForwardID].dCurrentPosition,
                                    readSliderData[iBackwardID].dCurrentPosition
                                )
                                
                                # 「停止判定結果」=「移動」か判定：分岐範囲
                                if dStopJudgmentResult == MOVE_VALUE:
                                    # 「状態」=「移動」か判定：分岐範囲
                                    if readSliderData[vID].iState == MOVE_VALUE:
                                        # 停止開始のための最短停止位置情報設定
                                        # VBA相当：Call ShortestStopPositionSetter.settingShortestStopPositionInformationForStartingStop(...)
                                        self._shortest_stop_position_setter.settingShortestStopPositionInformationForStartingStop(
                                            readSliderData[vID],
                                            readStopPosition[readSliderData[vID].iStopPositionPoint]
                                        )
                                        
                                        # 「処理時間」= 0か判定：分岐範囲
                                        if readSliderData[vID].dProcessingTime == 0:
                                            # 移動開始のための最短停止位置情報設定
                                            # VBA相当：Call ShortestStopPositionSetter.settingShortestStopPositionInformationForStartingMovement(...)
                                            self._shortest_stop_position_setter.settingShortestStopPositionInformationForStartingMovement(
                                                readSliderData[vID],
                                                readStopPosition
                                            )
                                            
                                            # 速度制御の形を構築
                                            # VBA相当：Call SpeedControl.buildSpeedControlForm(readSliderData(vID))
                                            self._speed_control.buildSpeedControlForm(readSliderData[vID])
                                    else:
                                        # 移動開始のための最短停止位置情報設定
                                        # VBA相当：Call ShortestStopPositionSetter.settingShortestStopPositionInformationForStartingMovement(...)
                                        self._shortest_stop_position_setter.settingShortestStopPositionInformationForStartingMovement(
                                            readSliderData[vID],
                                            readStopPosition
                                        )
                                        
                                        # 速度制御の形を構築
                                        # VBA相当：Call SpeedControl.buildSpeedControlForm(readSliderData(vID))
                                        self._speed_control.buildSpeedControlForm(readSliderData[vID])
                                else:
                                    # 停止開始のための最短停止位置情報設定
                                    # VBA相当：Call ShortestStopPositionSetter.settingShortestStopPositionInformationForStartingStop(...)
                                    self._shortest_stop_position_setter.settingShortestStopPositionInformationForStartingStop(
                                        readSliderData[vID],
                                        readStopPosition[readSliderData[vID].iStopPositionPoint]
                                    )
                                    
                            else:
                                # 「状態」=「移動」
                                readSliderData[vID].iState = MOVE_VALUE
                                
                                # 「目標位置」=「最短停止位置」
                                readSliderData[vID].dTargetPosition = readSliderData[vID].dShortestStopPosition
                                
                                # 最短停止位置の速度情報設定
                                # VBA相当：Call ShortestStopPositionSetter.settingShortestStopPositionSpeedInformation(...)
                                self._shortest_stop_position_setter.settingShortestStopPositionSpeedInformation(
                                    readSliderData[vID],
                                    readStopPosition
                                )
                                
                                # 速度制御の形を構築
                                # VBA相当：Call SpeedControl.buildSpeedControlForm(readSliderData(vID))
                                self._speed_control.buildSpeedControlForm(readSliderData[vID])
                
                # スライダ総数分ループ：開始
                # VBA相当：For Each vID In readSliderData.Keys
                for vID in readSliderData.keys():
                    # 「状態」=「移動」か判定：分岐範囲
                    if readSliderData[vID].iState == MOVE_VALUE:
                        # 速度制御の形変更を判定
                        # VBA相当：Set objTempSliderData = SpeedControl.changeJudgmentSpeedControlForm(readSliderData, CInt(vID))
                        self._speed_control.changeJudgmentSpeedControlForm(readSliderData, vID)
                
                # スライダ総数分ループ：開始（dMinimumProcessingTime を算出）
                # VBA 690–798 行目の第 3 ループに相当。最小処理時間を算出する
                for vID in readSliderData.keys():
                    # 「処理時間」≠  0か判定：分岐範囲
                    if readSliderData[vID].dProcessingTime != 0:
                        # 「最小の処理時間」=  0か判定：分岐範囲
                        if dMinimumProcessingTime == 0:
                            # 「最小の処理時間」=「処理時間」
                            dMinimumProcessingTime = readSliderData[vID].dProcessingTime
                        else:
                            # 「最小の処理時間」> 「処理時間」か判定：分岐範囲
                            if dMinimumProcessingTime > readSliderData[vID].dProcessingTime:
                                # 「最小の処理時間」=「処理時間」
                                dMinimumProcessingTime = readSliderData[vID].dProcessingTime
                
                # スライダ総数分ループ：開始
                # VBA相当：For Each vID In readSliderData.Keys
                for vID in readSliderData.keys():
                    # 「状態」=「移動」か判定:分岐範囲
                    if readSliderData[vID].iState == MOVE_VALUE:
                        # 現在速度の更新
                        # VBA相当：Call SpeedControl.updateCurrentSpeed(readSliderData(vID), dMinimumProcessingTime)
                        self._speed_control.updateCurrentSpeed(readSliderData[vID], dMinimumProcessingTime)
                        
                        # 現在位置の更新
                        # 「現在位置（一時保存）」の設定
                        # VBA相当：dTempCurrentPosition = updateCurrentPosition(readSliderData(vID), dMinimumProcessingTime)
                        dTempCurrentPosition = self.updateCurrentPosition(readSliderData[vID], dMinimumProcessingTime)
                        
                        # 「目標位置差分」=「現在位置（一時保存）」と「目標位置」の差分
                        dTargetPositionDifference = abs(dTempCurrentPosition - readSliderData[vID].dTargetPosition)
                        
                        # 「目標位置差分」<「許容差分」か判定：分岐範囲
                        if dTargetPositionDifference < ALLOWABLE_DIFFERENCE_RANGE:
                            # 「現在速度」=　0
                            readSliderData[vID].dCurrentSpeed = 0.0
                        
                        # 「タスクのポイント位置差分」=「現在位置（一時保存）」と「タスクのポイント位置」の差分
                        # VBA 822 行目相当
                        dTaskPointPositionDifference = abs(dTempCurrentPosition - readSliderData[vID].dTaskPointPosition)
                        
                        # 「タスクのポイント位置差分」 < 「許容差分」か判定：分岐範囲
                        # VBA 825 行目相当
                        if dTaskPointPositionDifference < ALLOWABLE_DIFFERENCE_RANGE:
                            # 「現在位置」=「タスクのポイント位置」
                            # VBA 828 行目相当
                            readSliderData[vID].dCurrentPosition = readSliderData[vID].dTaskPointPosition
                            
                            # 「処理時間」= 0
                            # VBA 831 行目相当
                            readSliderData[vID].dProcessingTime = 0.0
                        else:
                            # 「現在位置」=「現在位置（一時保存）」
                            # VBA 847 行目相当
                            readSliderData[vID].dCurrentPosition = dTempCurrentPosition
                        
                        # 「前回の現在位置」>「現在位置」か判定：分岐範囲
                        if readSliderData[vID].dLastTimeCurrentPosition > readSliderData[vID].dCurrentPosition:
                            # 「現在位置」>=「サイクルタイム計測開始位置」か判定：分岐範囲
                            if readSliderData[vID].dCurrentPosition >= readSliderData[vID].dCycleTimeMeasurementStartPosition:
                                # 「循環回数」=「循環回数」+ 1
                                readSliderData[vID].iLap = readSliderData[vID].iLap + CYCLE_COUNT_ADDITION_VALUE
                        
                        # 「前回の現在位置」=「現在位置」
                        readSliderData[vID].dLastTimeCurrentPosition = readSliderData[vID].dCurrentPosition
                    
                    # 「処理時間」≠ 0か判定：分岐範囲
                    # VBA 902–909 行目相当：内側ループ内で処理時間を更新（Next vID の直前）
                    if readSliderData[vID].dProcessingTime != 0:
                        # 「処理時間」=「処理時間」-「最小の処理時間」
                        readSliderData[vID].dProcessingTime = readSliderData[vID].dProcessingTime - dMinimumProcessingTime
                
                # 「現在時間」=「現在時間」+「最小の処理時間」
                # VBA 972 行目相当：内側ループ終了後に時刻を更新
                # 注意：dMinimumProcessingTime が 0 でも VBA は本行を実行する（0 加算のため実質不変）
                self._DblCurrentTime = self._DblCurrentTime + dMinimumProcessingTime
                
                # 前方スライダ追い越し確認
                # VBA相当：Set objTempSliderData = checkOvertakingForwardSlider(readSliderData, dMinimumProcessingTime)
                self.checkOvertakingForwardSlider(readSliderData, dMinimumProcessingTime)
                
                # 目標位置無視確認
                # VBA相当：Set objTempSliderData = checkIgnoredTargetPosition(readSliderData, dMinimumProcessingTime)
                self.checkIgnoredTargetPosition(readSliderData, dMinimumProcessingTime)
                
                # 現在速度負の数確認
                # VBA相当：Set objTempSliderData = checkNegativeNumbersCurrentSpeed(readSliderData, dMinimumProcessingTime)
                self.checkNegativeNumbersCurrentSpeed(readSliderData, dMinimumProcessingTime)
                
                # 「最小の処理時間」= 0
                dMinimumProcessingTime = 0.0
            
            # 「生産数」と「サイクルタイム」の算出
            # VBA相当：Set objTempSliderData = calculatingProductionVolumeAndCycleTime(readSliderData)
            result = self.calculatingProductionVolumeAndCycleTime(readSliderData)
            
            return result
            
        except CycleTimeCalculationError:
            # APIレイヤーで捕捉し、明示的なエラー情報を返す
            raise
        except Exception as e:
            print(f"{MODULE_NAME_MAIN_CONTROLLER}.exec: Error - {e}")
            return {}
    
    # ===========================================================
    # 2.入力処理
    # ===========================================================
    def inputProcess(self) -> bool:
        """
        入力処理
        
        Returns:
            bool: 処理実行結果
        """
        try:
            isInput = False
            
            # 返り値=False
            isInput = False
            
            # 「計算範囲」の設定
            # VBA相当：DblCalculationRange = WsAllStopPositionInformation.Range(CALCULATION_RANGE_CELL_RANGE)
            self._DblCalculationRange = self._user_input_data.get('calculation_range', 0.0)
            
            # 停止位置情報の初期設定
            # 返り値=停止位置データ初期値の設定の「処理実行結果」
            # VBA相当：isInput = StopPositionManipulater.settingInitialData()
            isInput = self._stop_position_manipulater.settingInitialData()
            
            # 返り値=Falseか判定：分岐範囲
            if not isInput:
                # 返り値=False
                return isInput
            
            # スライダ情報の初期設定
            # 返り値=スライダ情報の設定の「処理実行結果」
            # VBA相当：isInput = SliderDataManipulater.settingInitialData()
            isInput = self._slider_data_manipulater.settingInitialData()
            
            # 返り値=Falseか判定：分岐範囲
            if not isInput:
                # 返り値=False
                return isInput
            
            # 返り値=「処理実行結果」
            return isInput
            
        except CycleTimeCalculationError:
            # 計算例外の意味を維持し、APIレイヤーへ伝播する
            raise
        except Exception as e:
            print(f"{MODULE_NAME_MAIN_CONTROLLER}.inputProcess: Error - {e}")
            return False
    
    # ===========================================================
    # 5.「計算範囲」参照用モジュール
    # ===========================================================
    def readCalculationRange(self) -> float:
        """
        「計算範囲」参照用モジュール
        
        Returns:
            float: 計算範囲[s]
        """
        try:
            # 返り値=「計算範囲」
            return self._DblCalculationRange
        except Exception as e:
            print(f"{MODULE_NAME_MAIN_CONTROLLER}.readCalculationRange: Error - {e}")
            return 0.0
    
    # ===========================================================
    # 6.「生産数」と「サイクルタイム」の算出処理
    # ===========================================================
    def calculatingProductionVolumeAndCycleTime(
        self,
        objInput: Dict[int, SliderData]
    ) -> Dict[str, float]:
        """
        「生産数」と「サイクルタイム」の算出処理
        
        Args:
            objInput: スライダデータの辞書
            
        Returns:
            Dict[str, float]: 計算結果
                - cycle_time: サイクルタイム[s]
                - production_per_hour: 生産性[個/h]
                - production_per_8h: 生産数[個/8h]
                - total_laps: 全スライダ循環回数の合計値
                - calculation_time: 計算範囲[s]
        """
        try:
            dAllSlidersTotalLapNum = 0.0
            dSecondsProductionNumber = 0.0
            dHourProductionNumber = 0.0
            dDailyProductionNumber = 0.0
            dCycleTime = 0.0
            dTempCalculationRange = 0.0
            
            # スライダ総数分ループ：開始
            # VBA相当：For Each vID In objInput.Keys
            for vID in objInput.keys():
                # 「全スライダ循環回数の合計値」=「全スライダ循環回数の合計値」+「スライダ単体の循環回数」
                dAllSlidersTotalLapNum = dAllSlidersTotalLapNum + objInput[vID].iLap
            
            # 「全スライダ循環回数の合計値」= 0か判定：分岐範囲
            if dAllSlidersTotalLapNum == 0:
                # ダイアログ表示
                # VBA相当：MsgBox "生産数0[個]です。"
                # Python実装：例外を発生
                raise CycleTimeCalculationError(
                    ErrorCode.CYCLE_TIME_PRODUCTION_ZERO
                )
            else:
                # 「計算範囲（一時保存）」=「現在時間」
                dTempCalculationRange = self._DblCurrentTime
                
                # サイクルタイム[s] = 「計算範囲（一時保存）」 / 「全スライダ循環回数の合計値」
                dCycleTime = dTempCalculationRange / dAllSlidersTotalLapNum
                
                # 生産性[個/h] =  3600[s]  / サイクルタイム[s]
                dHourProductionNumber = CONVERT_SECONDS_TO_HOURS_VALUE / dCycleTime
                
                # 生産数[個/8h] = 生産性[個/h] * 8[h]
                dDailyProductionNumber = dHourProductionNumber * DAYLIGHT_HOURS
            
            # 返り値=計算結果
            result = {
                'cycle_time': dCycleTime,
                'production_per_hour': dHourProductionNumber,
                'production_per_8h': dDailyProductionNumber,
                'total_laps': int(dAllSlidersTotalLapNum),
                'calculation_time': dTempCalculationRange
            }
            
            return result
            
        except Exception as e:
            print(f"{MODULE_NAME_MAIN_CONTROLLER}.calculatingProductionVolumeAndCycleTime: Error - {e}")
            return {
                'cycle_time': 0.0,
                'production_per_hour': 0.0,
                'production_per_8h': 0.0,
                'total_laps': 0,
                'calculation_time': 0.0
            }
    
    # ===========================================================
    # 7.外部モジュールからの「現在時間」参照
    # ===========================================================
    def readCurrentTime(self) -> float:
        """
        外部モジュールからの「現在時間」参照
        
        Returns:
            float: 現在時間[s]
        """
        try:
            # 返り値=「現在時間」
            return self._DblCurrentTime
        except Exception as e:
            print(f"{MODULE_NAME_MAIN_CONTROLLER}.readCurrentTime: Error - {e}")
            return 0.0
    
    # ===========================================================
    # 8.前方スライダ追い越し確認
    # ===========================================================
    def checkOvertakingForwardSlider(
        self,
        objInput: Dict[int, SliderData],
        dMinimumProcessingTime: float
    ) -> Dict[int, SliderData]:
        """
        前方スライダ追い越し確認
        
        Args:
            objInput: スライダデータの辞書
            dMinimumProcessingTime: 最小の処理時間[s]
            
        Returns:
            Dict[int, SliderData]: スライダデータの辞書
        """
        try:
            dForBackwardIdPositionDiff = 0.0
            dSliderSizeDiff = 0.0
            dTempForwardCurrentPosition = 0.0
            dTempForwardTotalTraveledDistance = 0.0
            dTempBackwardTotalTraveledDistance = 0.0
            dMovingDifference = 0.0
            dCurrentPositionDifference = 0.0
            iForwardID = 0
            iBackwardID = 0
            sSentence = ""
            
            # 「ダイアログ表示の文章」= 「前方スライダ追い越し発生：計算強制終了」
            sSentence = "前方スライダ追い越し発生：計算強制終了"
            
            # 「スライダ総数」分繰り返す：開始
            # VBA相当：For Each vID In objInput.Keys
            for vID in objInput.keys():
                # 「ID」= 1か判定：分岐範囲
                if vID == FIRST_SLIDER_ID:
                    # 「前方のID」=　「最終スライダID」
                    iForwardID = len(objInput)
                    
                    # 「前方の総移動距離（一時保存）」=「前方の総移動距離」+「循環システム1周分の長さ」-「スライダサイズ / 2」
                    dSliderSize = self._slider_data_manipulater.readSliderSize()
                    dOneLap = self._axis_data_manipulater.readOneLap(dSliderSize)
                    dTempForwardTotalTraveledDistance = (
                        objInput[iForwardID].dTotalTraveledDistance +
                        dOneLap -
                        (dSliderSize / DIVISION_VALUE)
                    )
                    
                    # 「後方のID」=  1
                    iBackwardID = FIRST_SLIDER_ID
                    
                    # 「後方の総移動距離（一時保存）」=「後方の総移動距離」+「スライダサイズ / 2」
                    dTempBackwardTotalTraveledDistance = (
                        objInput[iBackwardID].dTotalTraveledDistance +
                        (dSliderSize / DIVISION_VALUE)
                    )
                else:
                    # 「前方のID」=　「指定ID」- 1
                    iForwardID = vID - OFFSET_ID
                    
                    # 「前方の総移動距離（一時保存）」=「前方の総移動距離」-「スライダサイズ / 2」
                    dSliderSize = self._slider_data_manipulater.readSliderSize()
                    dTempForwardTotalTraveledDistance = (
                        objInput[iForwardID].dTotalTraveledDistance -
                        (dSliderSize / DIVISION_VALUE)
                    )
                    
                    # 「後方のID」=　「指定ID」
                    iBackwardID = vID
                    
                    # 「後方の総移動距離（一時保存）」=「後方の総移動距離」+「スライダサイズ / 2」
                    dTempBackwardTotalTraveledDistance = (
                        objInput[iBackwardID].dTotalTraveledDistance +
                        (dSliderSize / DIVISION_VALUE)
                    )
                
                # 「移動差分」=「前方の総移動距離（一時保存）」と「後方の総移動距離（一時保存）」の差分（コメント上の表記は VBA 原文に合わせたもの）
                # 注意：VBA コードに誤りがある可能性（本来は前方・後方の総移動距離（一時保存）同士の差分であるべき）
                # 補足：VBA 1468 行付近は上記と異なる式だが、VBA を厳密に踏襲するため現行式を使用
                dMovingDifference = abs(dTempForwardTotalTraveledDistance - dTempBackwardTotalTraveledDistance)
                
                # 「移動距離差分」 >= 「 許容差分」か判定：分岐範囲
                if dMovingDifference >= ALLOWABLE_DIFFERENCE_RANGE:
                    # 「現在位置差分」=「前方の現在位置」と「後方の現在位置」の差分
                    dCurrentPositionDifference = abs(
                        objInput[iForwardID].dCurrentPosition - objInput[iBackwardID].dCurrentPosition
                    )
                    
                    # 「 スライダサイズ」>「現在位置差分（四捨五入）」か判定：分岐範囲
                    dSliderSize = self._slider_data_manipulater.readSliderSize()
                    if dSliderSize > round(dCurrentPositionDifference):
                        # 「後方の総移動距離（一時保存）」 > 「前方の総移動距離（一時保存）」か判定：分岐処理
                        if dTempBackwardTotalTraveledDistance > dTempForwardTotalTraveledDistance:
                            # ダイアログ表示
                            # VBA相当：MsgBox sSentence
                            # Python実装：例外を発生
                            raise CycleTimeCalculationError(
                                ErrorCode.CYCLE_TIME_OVERTAKING_DETECTED,
                                sSentence
                            )
            
            # 返り値=「スライダ情報」
            return objInput
            
        except Exception as e:
            print(f"{MODULE_NAME_MAIN_CONTROLLER}.checkOvertakingForwardSlider: Error - {e}")
            raise
    
    # ===========================================================
    # 10.現在位置の更新
    # ===========================================================
    def updateCurrentPosition(
        self,
        objSliderData: SliderData,
        dMinimumProcessingTime: float
    ) -> float:
        """
        現在位置の更新
        
        Args:
            objSliderData: スライダデータオブジェクト
            dMinimumProcessingTime: 最小の処理時間[s]
            
        Returns:
            float: 現在位置[mm]
        """
        try:
            dCurrentPosition = 0.0
            
            # VBA相当：With objSliderData ... End With
            # Python実装：直接アクセス
            
            # 「加速状態」=「加速」か判定：分岐範囲
            if objSliderData.iAccelerationState == ACCELERATION:
                # 「総移動距離」= 「総移動距離」
                # +「前回の速度」*「最小の処理時間」
                # + 0.5 *｛「加減速度」*「最小の処理時間」｝*「最小の処理時間」
                objSliderData.dTotalTraveledDistance = (
                    objSliderData.dTotalTraveledDistance +
                    objSliderData.dLastCurrentSpeed * dMinimumProcessingTime +
                    DISTANCE_CALCULATION_FIXED_VALUE * (objSliderData.dAccDeceleration * dMinimumProcessingTime) * dMinimumProcessingTime
                )
                
                # 「現在位置(一時保存)」=「前回の速度」*「最小の処理時間」
                # +0.5 *｛「加減速度」*「最小の処理時間」｝*「最小の処理時間」
                # +「現在位置」
                dCurrentPosition = (
                    objSliderData.dLastCurrentSpeed * dMinimumProcessingTime +
                    DISTANCE_CALCULATION_FIXED_VALUE * (objSliderData.dAccDeceleration * dMinimumProcessingTime) * dMinimumProcessingTime +
                    objSliderData.dCurrentPosition
                )
                
                # 「現在位置(一時保存)」>=「循環システム1周分の長さ」か判定
                dSliderSize = self._slider_data_manipulater.readSliderSize()
                dOneLap = self._axis_data_manipulater.readOneLap(dSliderSize)
                if dCurrentPosition >= dOneLap:
                    # 「現在位置(一時保存)」=「現在位置(一時保存)」-「循環システム1周分の長さ」
                    dCurrentPosition = dCurrentPosition - dOneLap
            
            # 「加速状態」=「等速」か判定
            elif objSliderData.iAccelerationState == CONSTANT_SPEED:
                # 「総移動距離」= 「総移動距離」+(「最大速度」*「最小の処理時間」)
                objSliderData.dTotalTraveledDistance = (
                    objSliderData.dTotalTraveledDistance +
                    (objSliderData.dMaximumSpeed * dMinimumProcessingTime)
                )
                
                # 「現在位置(一時保存)」=「最大速度」*「最小の処理時間」+「現在位置」
                dCurrentPosition = objSliderData.dMaximumSpeed * dMinimumProcessingTime + objSliderData.dCurrentPosition
                
                # 「現在位置(一時保存)」>=「循環システム1周分の長さ」か判定:分岐範囲
                dSliderSize = self._slider_data_manipulater.readSliderSize()
                dOneLap = self._axis_data_manipulater.readOneLap(dSliderSize)
                if dCurrentPosition >= dOneLap:
                    # 「現在位置(一時保存)」=「現在位置(一時保存)」-「循環システム1周分の長さ」
                    dCurrentPosition = dCurrentPosition - dOneLap
            
            # 「加速状態」=「減速」か判定：分岐範囲
            elif objSliderData.iAccelerationState == DECELERATION:
                # 「総移動距離」= 「総移動距離」
                # + {　0.5*（「前回の速度」-「現在速度」）*　「最小の処理時間」　｝
                # + {　「現在速度」*「最小の処理時間」　｝
                objSliderData.dTotalTraveledDistance = (
                    objSliderData.dTotalTraveledDistance +
                    DISTANCE_CALCULATION_FIXED_VALUE * (objSliderData.dLastCurrentSpeed - objSliderData.dCurrentSpeed) * dMinimumProcessingTime +
                    objSliderData.dCurrentSpeed * dMinimumProcessingTime
                )
                
                # 「現在位置(一時保存)」=　{　0.5*（「前回の速度」-「現在速度」）*　「最小の処理時間」　｝
                # + {「現在速度」*「最小の処理時間」｝
                # +「現在位置」
                dCurrentPosition = (
                    DISTANCE_CALCULATION_FIXED_VALUE * (objSliderData.dLastCurrentSpeed - objSliderData.dCurrentSpeed) * dMinimumProcessingTime +
                    objSliderData.dCurrentSpeed * dMinimumProcessingTime +
                    objSliderData.dCurrentPosition
                )
                
                # 「現在位置(一時保存)」>=「循環システム1周分の長さ」か判定：分岐範囲
                dSliderSize = self._slider_data_manipulater.readSliderSize()
                dOneLap = self._axis_data_manipulater.readOneLap(dSliderSize)
                if dCurrentPosition >= dOneLap:
                    # 「現在位置(一時保存)」=「現在位置(一時保存)」-「循環システム1周分の長さ」
                    dCurrentPosition = dCurrentPosition - dOneLap
            else:
                # 「現在位置(一時保存)」=　「現在位置」
                dCurrentPosition = objSliderData.dCurrentPosition
            
            # 返り値=「現在位置」
            return dCurrentPosition
            
        except Exception as e:
            print(f"{MODULE_NAME_MAIN_CONTROLLER}.updateCurrentPosition: Error - {e}")
            return 0.0
    
    # ===========================================================
    # 11.目標位置無視確認
    # ===========================================================
    def checkIgnoredTargetPosition(
        self,
        objInput: Dict[int, SliderData],
        dMinimumProcessingTime: float
    ) -> Dict[int, SliderData]:
        """
        目標位置無視確認
        
        Args:
            objInput: スライダデータの辞書
            dMinimumProcessingTime: 最小の処理時間[s]
            
        Returns:
            Dict[int, SliderData]: スライダデータの辞書
        """
        try:
            dTempTargetPosition = 0.0
            dCurrentPositionDiff = 0.0
            sSentence = ""
            
            # 「ダイアログ表示の文章」= 「目標位置無視：計算強制終了」
            sSentence = "目標位置無視：計算強制終了"
            
            # 「スライダ総数」分繰り返す：開始
            # VBA相当：For Each vID In objInput.Keys
            for vID in objInput.keys():
                # 「目標位置」= 0か判定：分岐範囲
                if objInput[vID].dTargetPosition == 0:
                    # 「目標位置（一時保存）」=「目標位置」+「循環システム1周分の長さ」
                    dSliderSize = self._slider_data_manipulater.readSliderSize()
                    dOneLap = self._axis_data_manipulater.readOneLap(dSliderSize)
                    dTempTargetPosition = objInput[vID].dTargetPosition + dOneLap
                else:
                    # 「目標位置（一時保存）」=「目標位置」
                    dTempTargetPosition = objInput[vID].dTargetPosition
                
                # 「現在位置差分」=「目標位置（一時保存）」と「現在位置」の差分
                dCurrentPositionDiff = abs(dTempTargetPosition - objInput[vID].dCurrentPosition)
                
                # 「現在位置差分」< 「許容差分」か判定：分岐範囲
                if dCurrentPositionDiff < ALLOWABLE_DIFFERENCE_RANGE:
                    # 「目標位置（一時保存）」=「現在位置」
                    dTempTargetPosition = objInput[vID].dCurrentPosition
                
                # 「現在位置」>「目標位置（一時保存）」か判定：分岐範囲
                if objInput[vID].dCurrentPosition > dTempTargetPosition:
                    # ダイアログ表示
                    # VBA相当：MsgBox sSentence
                    # Python実装：例外を発生
                    raise CycleTimeCalculationError(
                        ErrorCode.CYCLE_TIME_TARGET_POSITION_IGNORED,
                        sSentence
                    )
            
            # 返り値=「スライダ情報」
            return objInput
            
        except Exception as e:
            print(f"{MODULE_NAME_MAIN_CONTROLLER}.checkIgnoredTargetPosition: Error - {e}")
            raise
    
    # ===========================================================
    # 12.現在速度負の数確認
    # ===========================================================
    def checkNegativeNumbersCurrentSpeed(
        self,
        objInput: Dict[int, SliderData],
        dMinimumProcessingTime: float
    ) -> Dict[int, SliderData]:
        """
        現在速度負の数確認
        
        Args:
            objInput: スライダデータの辞書
            dMinimumProcessingTime: 最小の処理時間[s]
            
        Returns:
            Dict[int, SliderData]: スライダデータの辞書
        """
        try:
            sSentence = ""
            
            # 「ダイアログ表示の文章」= 「現在速度が負の数：計算強制終了」
            sSentence = "現在速度が負の数：計算強制終了"
            
            # 「スライダ総数」分繰り返す：開始
            # VBA相当：For Each vID In objInput.Keys
            for vID in objInput.keys():
                # 「現在速度」< 0か判定：分岐範囲
                if objInput[vID].dCurrentSpeed < 0:
                    # ダイアログ表示
                    # VBA相当：MsgBox sSentence
                    # Python実装：例外を発生
                    raise CycleTimeCalculationError(
                        ErrorCode.CYCLE_TIME_NEGATIVE_SPEED,
                        sSentence
                    )
            
            # 返り値=「スライダ情報」
            return objInput
            
        except Exception as e:
            print(f"{MODULE_NAME_MAIN_CONTROLLER}.checkNegativeNumbersCurrentSpeed: Error - {e}")
            raise
    
    # ===========================================================
    # 13.排出位置停止判定
    # ===========================================================
    def judgmentDischargePositionStop(
        self,
        dForwardCurrentPosition: float,
        dBackwardCurrentPosition: float
    ) -> float:
        """
        排出位置停止判定
        
        Args:
            dForwardCurrentPosition: 前方の現在位置[mm]
            dBackwardCurrentPosition: 後方の現在位置[mm]
            
        Returns:
            float: 停止判定結果（STOP_VALUE(0) または MOVE_VALUE(1)）
        """
        try:
            dStopJudgmentResult = 0.0
            dTempForwardCurrentPosition = 0.0
            dForwardCollisionAvoidancePosition = 0.0
            
            # 「停止判定結果」=「移動」
            dStopJudgmentResult = MOVE_VALUE
            
            # 「後方の現在位置」>「前方の現在位置」か判定：分岐範囲
            if dBackwardCurrentPosition > dForwardCurrentPosition:
                # 「前方の現在位置（一時保存）」=「前方の現在位置」+「循環システム1周分の長さ」
                dSliderSize = self._slider_data_manipulater.readSliderSize()
                dOneLap = self._axis_data_manipulater.readOneLap(dSliderSize)
                dTempForwardCurrentPosition = dForwardCurrentPosition + dOneLap
            else:
                # 「前方の現在位置（一時保存）」=「前方の現在位置」
                dTempForwardCurrentPosition = dForwardCurrentPosition
            
            # 「後方の現在位置」=「排出位置d」か判定：分岐範囲
            if dBackwardCurrentPosition == self._stop_position_manipulater.readReturnRouteSettingRangeEndPositionD():
                # 「前方の衝突回避位置」=「往路設定範囲の開始位置a」+「スライダサイズ」+「循環システム1周分の長さ」
                dSliderSize = self._slider_data_manipulater.readSliderSize()
                dOneLap = self._axis_data_manipulater.readOneLap(dSliderSize)
                dForwardCollisionAvoidancePosition = (
                    self._stop_position_manipulater.readOutboundRouteSettingRangeStartPositionA() +
                    dSliderSize +
                    dOneLap
                )
                
                # 「前方の現在位置（一時保存）」<「前方の衝突回避位置」か判定：分岐範囲
                if dTempForwardCurrentPosition < dForwardCollisionAvoidancePosition:
                    # 「停止判定結果」=「停止」
                    dStopJudgmentResult = STOP_VALUE
            
            # 「後方の現在位置」=「排出位置b」
            elif dBackwardCurrentPosition == self._stop_position_manipulater.readOutboundRouteSettingRangeEndPositionB():
                # 「前方の衝突回避位置」=「復路設定範囲の開始位置c」+「スライダサイズ」
                dSliderSize = self._slider_data_manipulater.readSliderSize()
                dForwardCollisionAvoidancePosition = (
                    self._stop_position_manipulater.readReturnRouteSettingRangeStartPositionC() +
                    dSliderSize
                )
                
                # 「前方の現在位置（一時保存）」<「前方の衝突回避位置」か判定：分岐範囲
                if dTempForwardCurrentPosition < dForwardCollisionAvoidancePosition:
                    # 「停止判定結果」=「停止」
                    dStopJudgmentResult = STOP_VALUE
            
            # 返り値=「停止判定結果」
            return dStopJudgmentResult
            
        except Exception as e:
            print(f"{MODULE_NAME_MAIN_CONTROLLER}.judgmentDischargePositionStop: Error - {e}")
            return MOVE_VALUE