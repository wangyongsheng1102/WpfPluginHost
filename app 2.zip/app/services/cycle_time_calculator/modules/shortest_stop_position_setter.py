"""
「最短の停止位置」を設定するプログラム
ShortestStopPositionSetter.bas（VBA）の Python 移植版

[処理概要]
　・「停止位置」の一覧の中から対象スライダの「現在位置」と
   最も距離が近い「停止位置」を設定する

[索引]
　□1.移動開始のための最短停止位置情報設定
　□2.停止開始のための最短停止位置情報設定
　□3.最短停止位置の速度情報設定
"""

from typing import Dict
from .. import constants
from ..constants import (
    MODULE_NAME_SHORTEST_STOP_POSITION_SETTER,
    FIRST_STOP_POSITION_NUMBER,
    POINT_OFFSET_VALUE,
    MOVE_VALUE,
    STOP_VALUE,
    FORMLESS,
    NONE,
)
from ..classes.slider_data import SliderData
from ..classes.slider_stop_position_data import SliderStopPositionData


class ShortestStopPositionSetter:
    """
    最短停止位置設定クラス
    
    VBAのモジュール関数をクラスのメソッドに変換
    """
    
    # ===========================================================
    # 1.移動開始のための最短停止位置情報設定
    # ===========================================================
    @staticmethod
    def settingShortestStopPositionInformationForStartingMovement(
        objSiderData: SliderData,
        objPosition: Dict[int, SliderStopPositionData]
    ) -> None:
        """
        移動開始のための最短停止位置情報設定
        
        Args:
            objSiderData: スライダデータオブジェクト
            objPosition: 停止位置情報の辞書
        """
        try:
            # 「停止位置ポイント」=「最終停止位置番号」か判定：分岐範囲
            if objSiderData.iStopPositionPoint == len(objPosition):
                # 「停止位置ポイント」=　1
                objSiderData.iStopPositionPoint = FIRST_STOP_POSITION_NUMBER
                
                # 「最短停止位置」=　「停止位置ポイント1の停止位置」
                objSiderData.dShortestStopPosition = objPosition[FIRST_STOP_POSITION_NUMBER].dStopPosition
                
                # 「最大速度」=　「停止位置ポイント1までの移動最大速度」
                objSiderData.dMaximumSpeed = objPosition[FIRST_STOP_POSITION_NUMBER].dMaximumSpeed
                
                # 「加減速度」=　「停止位置ポイント1までの加減速度」
                objSiderData.dAccDeceleration = objPosition[FIRST_STOP_POSITION_NUMBER].dAccDeceleration
            else:
                # 「停止位置ポイント」=　「現在の停止位置ポイント」+ 1
                objSiderData.iStopPositionPoint = objSiderData.iStopPositionPoint + POINT_OFFSET_VALUE
                
                # 「最短停止位置」=　「現在の停止位置ポイント+ 1の停止位置」
                objSiderData.dShortestStopPosition = objPosition[objSiderData.iStopPositionPoint].dStopPosition
                
                # 「最大速度」=　「現在の停止位置ポイント+ 1までの移動最大速度」
                objSiderData.dMaximumSpeed = objPosition[objSiderData.iStopPositionPoint].dMaximumSpeed
                
                # 「加減速度」=　「停止位置ポイント1までの加減速度」
                objSiderData.dAccDeceleration = objPosition[objSiderData.iStopPositionPoint].dAccDeceleration
            
            # 「状態」=「移動」
            objSiderData.iState = MOVE_VALUE
            
            # 「目標位置」=「最短停止位置」
            objSiderData.dTargetPosition = objSiderData.dShortestStopPosition
            
        except Exception as e:
            print(f"{MODULE_NAME_SHORTEST_STOP_POSITION_SETTER}.settingShortestStopPositionInformationForStartingMovement: Error - {e}")
    
    # ===========================================================
    # 2.停止開始のための最短停止位置情報設定
    # ===========================================================
    @staticmethod
    def settingShortestStopPositionInformationForStartingStop(
        objSiderData: SliderData,
        objPosition: SliderStopPositionData
    ) -> None:
        """
        停止開始のための最短停止位置情報設定
        
        Args:
            objSiderData: スライダデータオブジェクト
            objPosition: 停止位置データオブジェクト
        """
        try:
            # 「目標位置」=「停止位置」
            objSiderData.dTargetPosition = objPosition.dStopPosition
            
            # 「処理時間」=「停止時間」
            objSiderData.dProcessingTime = objPosition.dStopTime
            
            # 「最大速度」= 0
            objSiderData.dMaximumSpeed = 0.0
            
            # 「現在速度」= 0
            objSiderData.dCurrentSpeed = 0.0
            
            # 「加減速度」= 0
            objSiderData.dAccDeceleration = 0.0
            
            # 「状態」=「停止」
            objSiderData.iState = STOP_VALUE
            
            # 「速度制御の形」=「無」
            objSiderData.iSpeedControlShape = FORMLESS
            
            # 「加速状態」=「無」
            objSiderData.iAccelerationState = NONE
            
        except Exception as e:
            print(f"{MODULE_NAME_SHORTEST_STOP_POSITION_SETTER}.settingShortestStopPositionInformationForStartingStop: Error - {e}")
    
    # ===========================================================
    # 3.最短停止位置の速度情報設定
    # ===========================================================
    @staticmethod
    def settingShortestStopPositionSpeedInformation(
        objSiderData: SliderData,
        objPosition: Dict[int, SliderStopPositionData]
    ) -> None:
        """
        最短停止位置の速度情報設定
        
        Args:
            objSiderData: スライダデータオブジェクト
            objPosition: 停止位置情報の辞書
        """
        try:
            # 停止位置総数分ループ：開始
            # VBA相当：For Each vPoint In objPosition.Keys
            for vPoint in objPosition.keys():
                # 「停止位置ポイント」=「停止位置情報のポイント」か判定：分岐範囲
                if objSiderData.iStopPositionPoint == objPosition[vPoint].iPoint:
                    # 「最大速度」=「停止位置情報の最大速度」
                    objSiderData.dMaximumSpeed = objPosition[vPoint].dMaximumSpeed
                    
                    # 「加減速度」=「停止位置情報の加減速度」
                    objSiderData.dAccDeceleration = objPosition[vPoint].dAccDeceleration
                    
                    # 本関数強制終了
                    return
            
        except Exception as e:
            print(f"{MODULE_NAME_SHORTEST_STOP_POSITION_SETTER}.settingShortestStopPositionSpeedInformation: Error - {e}")
