"""
停止位置データ設定/参照用プログラム
StopPositionManipulater.bas（VBA）の Python 移植版

[処理概要]
　・シート内で設定された停止位置情報を取得し、
   別モジュールから各停止位置の設定値を参照する

[索引]
　□1.停止位置情報の初期設定
　□2.外部モジュールからの停止位置情報参照
　□3.ユーザ操作用シートから停止位置情報読み込み
　□4.ユーザ操作用シートから未設定の停止位置情報削除
　□5.末端位置の情報算出
　□6.位置情報の追加
　□7.停止位置情報のソート
　□8.往路設定範囲の終了位置bを取得
　□9.復路設定範囲の開始位置c
　□10.復路設定範囲の終了位置dを取得
　□11.停止位置の範囲確認
　□13.移動時間を算出
　□14.自動算出位置の算出
　□15.指定位置の停止時間を設定
　□16.前方の最短停止位置の検索
　□17.設定範囲の開始位置通過時間算出
　□18.往路設定範囲の開始位置aを取得
　□19.後方の最短停止位置の検索
"""

import math
from typing import Dict, List, Optional
from .. import constants
from ..exceptions import CycleTimeCalculationError
from app.core.errors import ErrorCode

from ..constants import (
    MODULE_NAME_STOP_POSITION_MANIPULATER,
    KEY_INITIAL_VALUE,
    KEY_ADD_VALUE,
    KEY_OFFSET,
    FIRST_SLIDER_ID_STOP_POSITION,
    TASK_STOP_POSITIONS_INITIAL_VALUE,
    CIRCULATION_AXIS_POSITION_A,
    MULTIPLIER_VALUE,
    DIVISOR_VALUE,
    TIME_CALCULATION_FIXED_VALUE,
    ARRIVAL_TIME_CALCULATION_FIXED_VALUE,
    DISTANCE_CALCULATION_FIXED_VALUE_STOP_POSITION,
    STOP_TIME_ZERO,
    MAX_SPEED,
    MAX_ACC_DECELERATION,
    TEMP_START_POSITION_C_ID_NUM,
    TEMP_START_POSITION_A_ID_NUM,
    PATTERN,
    OPTION_BUTTON_STATE_ON,
    TRIANGLE,
    DEBUG_FLAG,
)
from ..classes.input_stop_position_data import InputStopPositionData
from ..classes.slider_stop_position_data import SliderStopPositionData
from ..classes.slider_data import SliderData


class StopPositionManipulater:
    """
    停止位置データ設定/参照用クラス
    
    VBAのモジュール関数をクラスのメソッドに変換
    """
    
    def __init__(self, user_input_data: dict, axis_data_manipulater, slider_data_manipulater, speed_control):
        """
        初期化
        
        Args:
            user_input_data: ユーザ操作画面からの入力データ
            axis_data_manipulater: AxisDataManipulaterインスタンス
            slider_data_manipulater: SliderDataManipulaterインスタンス
            speed_control: SpeedControlインスタンス
        """
        self._user_input_data = user_input_data
        self._axis_data_manipulater = axis_data_manipulater
        self._slider_data_manipulater = slider_data_manipulater
        self._speed_control = speed_control
        
        # 停止位置情報格納のオブジェクト
        # VBA相当：Private ObjSliderStopPosition As Object
        # Python実装：Dict[int, SliderStopPositionData]
        self._ObjSliderStopPosition: Dict[int, SliderStopPositionData] = {}
        
        # 往路設定範囲の開始位置a
        # VBA相当：Private DblOutboundRouteSettingRangeStartPositionA As Double
        self._DblOutboundRouteSettingRangeStartPositionA: float = 0.0
        
        # 往路設定範囲の終了位置b
        # VBA相当：Private DblOutboundRouteSettingRangeEndPositionB As Double
        self._DblOutboundRouteSettingRangeEndPositionB: float = 0.0
        
        # 循環軸位置B
        # VBA相当：Private DblCirculationAxisPositionB As Double
        self._DblCirculationAxisPositionB: float = 0.0
        
        # 循環軸位置C
        # VBA相当：Private DblCirculationAxisPositionC As Double
        self._DblCirculationAxisPositionC: float = 0.0
        
        # 復路設定範囲の開始位置c
        # VBA相当：Private DblReturnRouteSettingRangeStartPositionC As Double
        self._DblReturnRouteSettingRangeStartPositionC: float = 0.0
        
        # 復路設定範囲の終了位置d
        # VBA相当：Private DblReturnRouteSettingRangeEndPositionD As Double
        self._DblReturnRouteSettingRangeEndPositionD: float = 0.0
        
        # 循環軸位置D
        # VBA相当：Private DblCirculationAxisPositionD As Double
        self._DblCirculationAxisPositionD: float = 0.0
    
    # ===========================================================
    # 1.停止位置情報の初期設定
    # ===========================================================
    def settingInitialData(self) -> bool:
        """
        停止位置情報の初期設定
        
        Returns:
            bool: 処理実行結果
        """
        try:
            # 返り値=True
            isInput = True
            
            # ユーザ操作用シートからの停止位置情報読み込み
            # VBA相当：Set objInputStopPosition = readInputStopPosition
            objInputStopPosition = self.readInputStopPosition()
            
            # ユーザ操作用シートから未設定の停止位置情報削除
            # VBA相当：Set objInputStopPosition = deleteUnsetValue(objInputStopPosition)
            objInputStopPosition = self.deleteUnsetValue(objInputStopPosition)
            
            # 自動算出位置の算出
            # VBA相当：Set objInputStopPosition = calculationAutomaticCalculationPosition(objInputStopPosition)
            objInputStopPosition = self.calculationAutomaticCalculationPosition(objInputStopPosition)
            
            # 停止位置の範囲確認
            # VBA相当：Set objInputStopPosition = checkStopPositionRange(objInputStopPosition)
            objInputStopPosition = self.checkStopPositionRange(objInputStopPosition)
            
            # 末端位置の情報算出
            # VBA相当：Set objInputStopPosition = calculatEndPositionInformation(objInputStopPosition)
            objInputStopPosition = self.calculatEndPositionInformation(objInputStopPosition)
            
            # 停止位置情報のソート
            # VBA相当：Call sortStopPositionInformation(objInputStopPosition)
            self.sortStopPositionInformation(objInputStopPosition)
            
            # 指定位置の停止時間を設定
            # VBA相当：Call setDesignationPositionStopTime(objInputStopPosition)
            self.setDesignationPositionStopTime(objInputStopPosition)
            
            # 停止位置情報のソート
            # VBA相当：Call sortStopPositionInformation(objInputStopPosition)
            self.sortStopPositionInformation(objInputStopPosition)
            
            # コレクションを初期化
            # VBA相当：Set ObjSliderStopPosition = CreateObject("Scripting.Dictionary")
            self._ObjSliderStopPosition = {}
            
            # 停止位置情報の設定
            # 「停止位置」の総数分繰り返す：開始
            # VBA相当：For iKey = KEY_INITIAL_VALUE To objInputStopPosition.Count
            for iKey in range(KEY_INITIAL_VALUE, len(objInputStopPosition) + 1):
                # クラス名「SliderStopPositionData」のインスタンスを生成
                # VBA相当：ObjSliderStopPosition.Add iKey, New SliderStopPositionData
                self._ObjSliderStopPosition[iKey] = SliderStopPositionData()
                
                # プロパティに値を設定
                # VBA相当：With ObjSliderStopPosition(iKey) ... End With
                objStopPosition = self._ObjSliderStopPosition[iKey]
                
                # クラス名『SliderStopPositionData』の「ポイント」=「キー」
                objStopPosition.iPoint = iKey
                
                # クラス名『SliderStopPositionData』の「停止位置」=クラス名「InputStopPositionData」の「停止位置」
                objStopPosition.dStopPosition = objInputStopPosition[iKey].dStopPosition
                
                # クラス名『SliderStopPositionData』の「停止時間」=クラス名「InputStopPositionData」の「停止時間」
                objStopPosition.dStopTime = objInputStopPosition[iKey].dStopTime
                
                # クラス名『SliderStopPositionData』の「最大速度」=クラス名「InputStopPositionData」の「最大速度」
                objStopPosition.dMaximumSpeed = objInputStopPosition[iKey].dMaximumSpeed
                
                # クラス名『SliderStopPositionData』の「加減速度」=クラス名「InputStopPositionData」の「加減速度」
                objStopPosition.dAccDeceleration = objInputStopPosition[iKey].dAccDeceleration
            
            # 返り値=「処理実行結果」
            return isInput
            
        except CycleTimeCalculationError:
            # 呼び出し元で明示的な計算エラーを伝播する
            raise
        except Exception as e:
            print(f"{MODULE_NAME_STOP_POSITION_MANIPULATER}.settingInitialData: Error - {e}")
            return False
    
    # ===========================================================
    # 2.外部モジュールからの停止位置情報参照
    # ===========================================================
    def readStopPosition(self) -> Dict[int, SliderStopPositionData]:
        """
        外部モジュールからの停止位置情報参照
        
        Returns:
            Dict[int, SliderStopPositionData]: 停止位置情報の辞書
        """
        try:
            # 返り値=「停止位置情報」
            return self._ObjSliderStopPosition
        except Exception as e:
            print(f"{MODULE_NAME_STOP_POSITION_MANIPULATER}.readStopPosition: Error - {e}")
            return {}
    
    # ===========================================================
    # 3.ユーザ操作用シートから停止位置情報読み込み
    # ===========================================================
    def readInputStopPosition(self) -> Dict[int, InputStopPositionData]:
        """
        ユーザ操作用シートから停止位置情報読み込み
        
        Returns:
            Dict[int, InputStopPositionData]: 入力停止位置情報の辞書
        """
        try:
            # コレクションを初期化
            # VBA相当：Set objInputStopPosition = CreateObject("Scripting.Dictionary")
            objInputStopPosition: Dict[int, InputStopPositionData] = {}
            
            # キーの初期化
            iKeyCount = KEY_INITIAL_VALUE
            
            # ユーザ操作用シートの「停止位置」の総数分ループ：開始
            # VBA相当：For i = INPUT_STOP_POSITION_START_ROW To INPUT_STOP_POSITION_END_ROW
            # Python実装：ユーザ入力データから停止位置リストを取得
            stop_positions = self._user_input_data.get('stop_positions', [])
            
            for stop_pos in stop_positions:
                # 「停止位置ポイント」= キー番号
                iKey = iKeyCount
                
                # キーカウント加算
                iKeyCount = iKeyCount + KEY_ADD_VALUE
                
                # クラス名「InputStopPositionData」のインスタンスを生成
                # VBA相当：objInputStopPosition.Add iKey, New InputStopPositionData
                objInputStopPosition[iKey] = InputStopPositionData()
                
                # プロパティに値を設定
                # VBA相当：With objInputStopPosition(iKey) ... End With
                objInput = objInputStopPosition[iKey]
                
                # 「停止位置」= ユーザ操作用シートの「停止位置」
                # VBA相当：.dStopPosition = wsUserOperationt.Cells(i, INPUT_STOP_POSITION_CLM).Value
                objInput.dStopPosition = stop_pos.get('stop_position', 0.0)
                
                # 「停止時間」= ユーザ操作用シートの「停止時間」
                # VBA相当：.dStopTime = wsUserOperationt.Cells(i, INPUT_WAITING_TIME_CLM).Value
                objInput.dStopTime = stop_pos.get('stop_time', 0.0)
                
                # 「最大速度」= ユーザ操作用シートの「最大速度」
                # VBA相当：.dMaximumSpeed = wsUserOperationt.Cells(i, INPUT_SPEED_CLM).Value
                objInput.dMaximumSpeed = stop_pos.get('maximum_speed', 0.0)
                
                # 「加減速度」= ユーザ操作用シートの「加減速度」
                # VBA相当：.dAccDeceleration = wsUserOperationt.Cells(i, INPUT_ACCELERATION_CLM).Value
                objInput.dAccDeceleration = stop_pos.get('acc_deceleration', 0.0)
            
            # 返り値=ユーザ操作用シートの「停止位置」
            return objInputStopPosition
            
        except Exception as e:
            print(f"{MODULE_NAME_STOP_POSITION_MANIPULATER}.readInputStopPosition: Error - {e}")
            return {}
    
    # ===========================================================
    # 4.ユーザ操作用シートから未設定の停止位置情報削除
    # ===========================================================
    def deleteUnsetValue(self, objInput: Dict[int, InputStopPositionData]) -> Dict[int, InputStopPositionData]:
        """
        ユーザ操作用シートから未設定の停止位置情報削除
        
        Args:
            objInput: 入力停止位置情報の辞書
            
        Returns:
            Dict[int, InputStopPositionData]: 未設定値を削除した停止位置情報の辞書
        """
        try:
            # ユーザ操作用シートの「停止位置」の総数分ループ
            # VBA相当：For Each vKey In objInput.Keys
            # Python実装：削除するキーのリストを作成してから削除
            keys_to_remove = []
            
            for vKey in objInput.keys():
                # 「読み込み停止位置」=「0」か判定
                if objInput[vKey].dStopPosition == TASK_STOP_POSITIONS_INITIAL_VALUE:
                    # 「未設定の停止位置」の削除
                    keys_to_remove.append(vKey)
            
            # 削除実行
            for key in keys_to_remove:
                del objInput[key]
            
            # 入力された停止位置を返答
            return objInput
            
        except Exception as e:
            print(f"{MODULE_NAME_STOP_POSITION_MANIPULATER}.deleteUnsetValue: Error - {e}")
            return objInput
    
    # ===========================================================
    # 5.末端位置の情報算出
    # ===========================================================
    def calculatEndPositionInformation(self, objInputStopPosition: Dict[int, InputStopPositionData]) -> Dict[int, InputStopPositionData]:
        """
        末端位置の情報算出
        
        Args:
            objInputStopPosition: 入力停止位置情報の辞書
            
        Returns:
            Dict[int, InputStopPositionData]: 末端位置を追加した停止位置情報の辞書
        """
        try:
            iControlControllerPattern = 0
            dTotalLength = 0.0
            dCirculationAxisStroke = 0.0
            dSliderSize = 0.0
            dEjectPositionA = 0.0
            dEjectPositionB = 0.0
            dEjectPositionC = 0.0
            dEjectPositionD = 0.0
            dEjectMaximumSpeed = 0.0
            dEjectAccDeceleration = 0.0
            dCirculationAxisMaximumSpeed = 0.0
            dCirculationAxisAccDeceleration = 0.0
            
            # 「VTS全長」の取得
            dTotalLength = self._axis_data_manipulater.getTotalLength()
            
            # 「循環軸のストローク」の取得
            dCirculationAxisStroke = self._axis_data_manipulater.getCirculationAxisStroke()
            
            # 循環軸上の停止位置までの最大速度を取得
            # VBA相当：dCirculationAxisMaximumSpeed = wsUserOperationt.Range(CIRCULATION_AXIS_SPEED_CELL_NUMBER).Value
            dCirculationAxisMaximumSpeed = self._user_input_data.get('circulation_axis_speed', 0.0)
            
            # 循環軸上の停止位置までの加減速度を取得
            # VBA相当：dCirculationAxisAccDeceleration = wsUserOperationt.Range(CIRCULATION_AXIS_ACC_DECELERATION_CELL_NUMBER).Value
            dCirculationAxisAccDeceleration = self._user_input_data.get('circulation_axis_acc_decel', 0.0)
            
            # 外部モジュールからの「スライダサイズ」参照
            # 「スライダサイズ」の取得
            dSliderSize = self._slider_data_manipulater.readSliderSize()
            
            # 排出速度を取得
            # VBA相当：dEjectMaximumSpeed = wsUserOperationt.Range(RETRACT_EXTRACT_SPEED_CELL_NUMBER).Value
            dEjectMaximumSpeed = self._user_input_data.get('discharge_speed', 0.0)
            
            # 排出加減速度を取得
            # VBA相当：dEjectAccDeceleration = wsUserOperationt.Range(RETRACT_EXTRACT_ACC_DECELERATION_CELL_NUMBER).Value
            dEjectAccDeceleration = self._user_input_data.get('discharge_acc_decel', 0.0)
            
            # 「循環軸位置A」= 0を「停止位置」へ追加
            self.addEndPosition(
                objInputStopPosition,
                CIRCULATION_AXIS_POSITION_A,
                STOP_TIME_ZERO,
                dCirculationAxisMaximumSpeed,
                dCirculationAxisAccDeceleration
            )
            
            # 「制御コントローラパターン」の取得
            # VBA相当：iControlControllerPattern = wsUserOperationt.Range(CONTROL_CONTROLLER_PATTERN).Value
            iControlControllerPattern = self._user_input_data.get('control_pattern', 1)
            
            # 「制御コントローラパターン」= 「1」　か判定：分岐範囲
            if iControlControllerPattern == PATTERN:
                # 「排出位置a」=「往路設定範囲の開始位置a」
                dEjectPositionA = self._DblOutboundRouteSettingRangeStartPositionA
                
                # 「位置情報の追加」：「排出位置a」を「停止位置」へ追加
                self.addEndPosition(
                    objInputStopPosition,
                    dEjectPositionA,
                    STOP_TIME_ZERO,
                    dEjectMaximumSpeed,
                    dEjectAccDeceleration
                )
                
                # 「位置情報の追加」：「循環軸位置B」を「停止位置」へ追加
                self.addEndPosition(
                    objInputStopPosition,
                    self._DblCirculationAxisPositionB,
                    STOP_TIME_ZERO,
                    MAX_SPEED,
                    MAX_ACC_DECELERATION
                )
            else:
                # 「排出位置b」=「往路設定範囲の終了位置b」
                dEjectPositionB = self._DblOutboundRouteSettingRangeEndPositionB
                
                # 「位置情報の追加」：「排出位置b」を「停止位置」へ追加
                self.addEndPosition(
                    objInputStopPosition,
                    dEjectPositionB,
                    STOP_TIME_ZERO,
                    MAX_SPEED,
                    MAX_ACC_DECELERATION
                )
                
                # 「位置情報の追加」：「循環軸位置B」を「停止位置」へ追加
                self.addEndPosition(
                    objInputStopPosition,
                    self._DblCirculationAxisPositionB,
                    STOP_TIME_ZERO,
                    dEjectMaximumSpeed,
                    dEjectAccDeceleration
                )
            
            # 「位置情報の追加」：「循環軸位置C」を「停止位置」へ追加
            self.addEndPosition(
                objInputStopPosition,
                self._DblCirculationAxisPositionC,
                STOP_TIME_ZERO,
                dCirculationAxisMaximumSpeed,
                dCirculationAxisAccDeceleration
            )
            
            # 「制御コントローラパターン」= 「1」　か判定：分岐範囲
            if iControlControllerPattern == PATTERN:
                # 「排出位置c」=「復路設定範囲の開始位置c」
                dEjectPositionC = self._DblReturnRouteSettingRangeStartPositionC
                
                # 「位置情報の追加」：「排出位置c」を「停止位置」へ追加
                self.addEndPosition(
                    objInputStopPosition,
                    dEjectPositionC,
                    STOP_TIME_ZERO,
                    dEjectMaximumSpeed,
                    dEjectAccDeceleration
                )
                
                # 「位置情報の追加」：「循環軸位置D」を「停止位置」へ追加
                self.addEndPosition(
                    objInputStopPosition,
                    self._DblCirculationAxisPositionD,
                    STOP_TIME_ZERO,
                    MAX_SPEED,
                    MAX_ACC_DECELERATION
                )
            else:
                # 「排出位置d」=「復路設定範囲の終了位置d」
                dEjectPositionD = self._DblReturnRouteSettingRangeEndPositionD
                
                # 「位置情報の追加」：「排出位置d」を「停止位置」へ追加
                self.addEndPosition(
                    objInputStopPosition,
                    dEjectPositionD,
                    STOP_TIME_ZERO,
                    MAX_SPEED,
                    MAX_ACC_DECELERATION
                )
                
                # 「位置情報の追加」：「循環軸位置D」を「停止位置」へ追加
                self.addEndPosition(
                    objInputStopPosition,
                    self._DblCirculationAxisPositionD,
                    STOP_TIME_ZERO,
                    dEjectMaximumSpeed,
                    dEjectAccDeceleration
                )
            
            # 入力された停止位置を返答
            return objInputStopPosition
            
        except Exception as e:
            print(f"{MODULE_NAME_STOP_POSITION_MANIPULATER}.calculatEndPositionInformation: Error - {e}")
            return objInputStopPosition
    
    # ===========================================================
    # 6.位置情報の追加
    # ===========================================================
    def addEndPosition(
        self,
        objInputStopPosition: Dict[int, InputStopPositionData],
        dEndStopPosition: float,
        dStopTime: float,
        dMaximumSpeed: float,
        dAccDeceleration: float
    ) -> None:
        """
        位置情報の追加
        
        Args:
            objInputStopPosition: 入力停止位置情報の辞書
            dEndStopPosition: 追加位置[mm]
            dStopTime: 停止時間[s]
            dMaximumSpeed: 最大速度[mm/s]
            dAccDeceleration: 加減速度[mm/s²]
        """
        try:
            # 「追加の位置情報のキー」=「キーの総数」+ 1
            iKey = len(objInputStopPosition) + KEY_ADD_VALUE
            
            # クラスのインスタンスを生成
            # VBA相当：objInputStopPosition.Add iKey, New InputStopPositionData
            objInputStopPosition[iKey] = InputStopPositionData()
            
            # プロパティに値を設定
            # VBA相当：With objInputStopPosition(iKey) ... End With
            objInput = objInputStopPosition[iKey]
            
            # 「追加の位置情報の停止位置」=「追加位置」
            objInput.dStopPosition = dEndStopPosition
            
            # 「追加の位置情報の停止時間」=「停止時間」
            objInput.dStopTime = dStopTime
            
            # 「追加の位置情報の最大速度」=「最大速度」
            objInput.dMaximumSpeed = dMaximumSpeed
            
            # 「追加の位置情報の加減速度」=「加減速度」
            objInput.dAccDeceleration = dAccDeceleration
            
        except Exception as e:
            print(f"{MODULE_NAME_STOP_POSITION_MANIPULATER}.addEndPosition: Error - {e}")
    
    # ===========================================================
    # 7.停止位置情報のソート
    # 処理概要：バブルソートで停止位置を昇順にソート
    # ===========================================================
    def sortStopPositionInformation(self, objAllStopPosition: Dict[int, InputStopPositionData]) -> None:
        """
        停止位置情報のソート
        
        処理概要：バブルソートで停止位置を昇順にソート
        
        Args:
            objAllStopPosition: 全停止位置情報の辞書
        """
        try:
            dTempPosition = 0.0
            dTempTime = 0.0
            dTempMaximumSpeed = 0.0
            dTempSpeedChangeAmount = 0.0
            
            # スライダの総数分ループ：開始
            # VBA相当：For i = FIRST_SLIDER_ID To objAllStopPosition.Count
            # Python実装：dictのキーをソートして処理
            keys = sorted(objAllStopPosition.keys())
            
            for i_idx, i in enumerate(keys):
                # スライダ数をオフセットした数からスライダ総数までループ：開始
                # VBA相当：For j = i + FIRST_SLIDER_ID To objAllStopPosition.Count
                for j_idx in range(i_idx + 1, len(keys)):
                    j = keys[j_idx]
                    
                    # 「外ループの停止位置」>「内ループの停止位置」か判定
                    if objAllStopPosition[i].dStopPosition > objAllStopPosition[j].dStopPosition:
                        # 「停止位置（一時保存）」=「外ループの停止位置」
                        dTempPosition = objAllStopPosition[i].dStopPosition
                        
                        # 「外ループの停止位置」=「内ループの停止位置」
                        objAllStopPosition[i].dStopPosition = objAllStopPosition[j].dStopPosition
                        
                        # 「内ループの停止位置」=「停止位置（一時保存）」
                        objAllStopPosition[j].dStopPosition = dTempPosition
                        
                        # 「停止時間（一時保存）」=「外ループの停止時間」
                        dTempTime = objAllStopPosition[i].dStopTime
                        
                        # 「外ループの停止時間」=「内ループの停止時間」
                        objAllStopPosition[i].dStopTime = objAllStopPosition[j].dStopTime
                        
                        # 「内ループの停止時間」=「停止時間（一時保存）」
                        objAllStopPosition[j].dStopTime = dTempTime
                        
                        # 「最大速度（一時保存）」=「外ループの最大速度」
                        dTempMaximumSpeed = objAllStopPosition[i].dMaximumSpeed
                        
                        # 「外ループの最大速度」=「内ループの最大速度」
                        objAllStopPosition[i].dMaximumSpeed = objAllStopPosition[j].dMaximumSpeed
                        
                        # 「内ループの最大速度」=「最大速度（一時保存）」
                        objAllStopPosition[j].dMaximumSpeed = dTempMaximumSpeed
                        
                        # 「加減速度（一時保存）」=「外ループの加減速度」
                        dTempSpeedChangeAmount = objAllStopPosition[i].dAccDeceleration
                        
                        # 「外ループの加減速度」=「内ループの加減速度」
                        objAllStopPosition[i].dAccDeceleration = objAllStopPosition[j].dAccDeceleration
                        
                        # 「内ループの加減速度」=「加減速度（一時保存）」
                        objAllStopPosition[j].dAccDeceleration = dTempSpeedChangeAmount
            
        except Exception as e:
            print(f"{MODULE_NAME_STOP_POSITION_MANIPULATER}.sortStopPositionInformation: Error - {e}")
    
    # ===========================================================
    # 8.往路設定範囲の終了位置bを取得
    # ===========================================================
    def readOutboundRouteSettingRangeEndPositionB(self) -> float:
        """
        往路設定範囲の終了位置bを取得
        
        Returns:
            float: 往路設定範囲の終了位置b[mm]
        """
        try:
            # 総スライダ数を返答
            return self._DblOutboundRouteSettingRangeEndPositionB
        except Exception as e:
            print(f"{MODULE_NAME_STOP_POSITION_MANIPULATER}.readOutboundRouteSettingRangeEndPositionB: Error - {e}")
            return 0.0
    
    # ===========================================================
    # 9.復路設定範囲の開始位置c
    # ===========================================================
    def readReturnRouteSettingRangeStartPositionC(self) -> float:
        """
        復路設定範囲の開始位置cを取得
        
        Returns:
            float: 復路設定範囲の開始位置c[mm]
        """
        try:
            # 総スライダ数を返答
            return self._DblReturnRouteSettingRangeStartPositionC
        except Exception as e:
            print(f"{MODULE_NAME_STOP_POSITION_MANIPULATER}.readReturnRouteSettingRangeStartPositionC: Error - {e}")
            return 0.0
    
    # ===========================================================
    # 10.復路設定範囲の終了位置dを取得
    # ===========================================================
    def readReturnRouteSettingRangeEndPositionD(self) -> float:
        """
        復路設定範囲の終了位置dを取得
        
        Returns:
            float: 復路設定範囲の終了位置d[mm]
        """
        try:
            # 総スライダ数を返答
            return self._DblReturnRouteSettingRangeEndPositionD
        except Exception as e:
            print(f"{MODULE_NAME_STOP_POSITION_MANIPULATER}.readReturnRouteSettingRangeEndPositionD: Error - {e}")
            return 0.0
    
    # ===========================================================
    # 11.停止位置の範囲確認
    # ===========================================================
    def checkStopPositionRange(self, objInput: Dict[int, InputStopPositionData]) -> Dict[int, InputStopPositionData]:
        """
        停止位置の範囲確認
        
        Args:
            objInput: 入力停止位置情報の辞書
            
        Returns:
            Dict[int, InputStopPositionData]: 範囲内の停止位置情報の辞書
        """
        try:
            isRange = False
            
            # コレクションのインスタンスを生成
            # VBA相当：Set clcKeysToRemove = New Collection
            # Python実装：リストを使用
            clcKeysToRemove: List[int] = []
            
            # 「停止位置」数分ループ：開始
            # VBA相当：For Each vKey In objInput.Keys
            for vKey in list(objInput.keys()):
                # 範囲判定フラグ=False
                isRange = False
                
                # VBA相当：With objInput(vKey) ... End With
                objInputItem = objInput[vKey]
                
                # 「往路設定範囲の開始位置 a」<「停止位置」かつ「停止位置」<「往路設定範囲の終了位置 b」か判定：分岐範囲
                if (self._DblOutboundRouteSettingRangeStartPositionA < objInputItem.dStopPosition and
                    objInputItem.dStopPosition < self._DblOutboundRouteSettingRangeEndPositionB):
                    # 範囲判定フラグ = True
                    isRange = True
                else:
                    # 「VTS復路」=ONか判定：分岐範囲
                    if self._axis_data_manipulater.checkReturnTripAvailable() == OPTION_BUTTON_STATE_ON:
                        # 「復路設定範囲の開始位置 c」<「停止位置」かつ「停止位置」<「復路設定範囲の終了位置 d」か判定：分岐範囲
                        if (self._DblReturnRouteSettingRangeStartPositionC < objInputItem.dStopPosition and
                            objInputItem.dStopPosition < self._DblReturnRouteSettingRangeEndPositionD):
                            # 範囲判定フラグ= True
                            isRange = True
                
                # 範囲判定フラグ= Falseか判定：分岐範囲
                if not isRange:
                    # 範囲外の「停止位置」のため削除
                    clcKeysToRemove.append(vKey)
            
            # 削除対象のキーの数分ループ：開始
            # VBA相当：For Each vKey In clcKeysToRemove
            for vKey in clcKeysToRemove:
                # 削除したキー以降のキーの数分ループ：開始
                # VBA相当：For lKey = vKey To objInput.Count
                # Python実装：削除するキー以降の要素を前にシフト
                keys_after = [k for k in sorted(objInput.keys()) if k > vKey]
                
                for lKey in keys_after:
                    # 「最終の停止位置」か判定：分岐範囲
                    if lKey == max(objInput.keys()):
                        # 削除したキー以降のキーの数分ループ強制終了
                        break
                    
                    # メモ：「範囲外の停止位置」を「次の停止位置」へ上書き
                    # 削除対処となるキーの「停止位置」=1つ後の「停止位置」
                    next_key = lKey + KEY_OFFSET
                    if next_key in objInput:
                        objInput[lKey].dStopPosition = objInput[next_key].dStopPosition
                        objInput[lKey].dStopTime = objInput[next_key].dStopTime
                        objInput[lKey].dMaximumSpeed = objInput[next_key].dMaximumSpeed
                        objInput[lKey].dAccDeceleration = objInput[next_key].dAccDeceleration
                
                # 最後のキーを削除（ずらした後、重複するため）
                if objInput:
                    max_key = max(objInput.keys())
                    del objInput[max_key]
            
            # オフセットした「停止位置」を返答
            return objInput
            
        except Exception as e:
            print(f"{MODULE_NAME_STOP_POSITION_MANIPULATER}.checkStopPositionRange: Error - {e}")
            return objInput
    
    # ===========================================================
    # 13.移動時間を算出
    # ===========================================================
    def calculateTraveledTime(
        self,
        dTargetPositionTraveledDistance: float,
        dMaximumSpeed: float,
        dAccDeceleration: float
    ) -> float:
        """
        移動時間を算出
        
        Args:
            dTargetPositionTraveledDistance: 目標位置移動距離[mm]
            dMaximumSpeed: 最大速度[mm/s]
            dAccDeceleration: 加減速度[mm/s²]
            
        Returns:
            float: 移動時間[s]
        """
        try:
            dAccDecelerationSwitchPoint = 0.0
            dAccelerationTime = 0.0
            dDecelerationTime = 0.0
            dTraveledDistanceTime = 0.0
            dConstantSpeedTime = 0.0
            dAccelerationDistance = 0.0
            dDecelerationDistance = 0.0
            dConstantSpeedDistance = 0.0
            
            # 「加減速度変更点」の算出
            # =√「目標位置移動距離」*「加減速度」
            # VBA相当：Sqr(...)
            # Python実装：math.sqrt(...)
            dAccDecelerationSwitchPoint = math.sqrt(dTargetPositionTraveledDistance * dAccDeceleration)
            
            # 「加速時間」=　「加減速度変更点 /「加減速度」
            dAccelerationTime = dAccDecelerationSwitchPoint / dAccDeceleration
            
            # 「加減速度変更点」>「最大速度」:分岐範囲
            if dAccDecelerationSwitchPoint > dMaximumSpeed:
                # 「加速距離」=　0.5  * 「最大速度」*「加速時間」
                dAccelerationDistance = DISTANCE_CALCULATION_FIXED_VALUE_STOP_POSITION * dMaximumSpeed * dAccelerationTime
                
                # 「減速時間」 = 「最大速度」 / 「加減速度」
                dDecelerationTime = dMaximumSpeed / dAccDeceleration
                
                # 「減速距離」=  0.5 *「最大速度」* 「減速時間」
                dDecelerationDistance = DISTANCE_CALCULATION_FIXED_VALUE_STOP_POSITION * dMaximumSpeed * dDecelerationTime
                
                # 「等速距離」=「目標位置移動距離」-（　「加速距離」+「減速距離」　）
                # 注意：VBA コードに誤りがある可能性（減算ではなく加算であるべき）
                # 補足：VBA 1051 行付近は減算になっているが、本来は加算とみなして移植している
                dConstantSpeedDistance = dTargetPositionTraveledDistance - (dAccelerationDistance + dDecelerationDistance)
                
                # 「等速時間」=「等速距離」/「最大速度」
                dConstantSpeedTime = dConstantSpeedDistance / dMaximumSpeed
                
                # 「移動時間」=　「加速時間」+「等速時間」+「減速時間」
                dTraveledDistanceTime = dAccelerationTime + dConstantSpeedTime + dDecelerationTime
            # 「最大速度」>=「加減速度変更点」
            elif dMaximumSpeed >= dAccDecelerationSwitchPoint:
                # 「減速時間」=「加減速度変更点」/「加減速度」
                dDecelerationTime = dAccDecelerationSwitchPoint / dAccDeceleration
                
                # 「移動時間」=「加速時間」+「減速時間」
                dTraveledDistanceTime = dAccelerationTime + dDecelerationTime
            
            # 返答=「移動時間」
            return dTraveledDistanceTime
            
        except Exception as e:
            print(f"{MODULE_NAME_STOP_POSITION_MANIPULATER}.calculateTraveledTime: Error - {e}")
            return 0.0
    
    # ===========================================================
    # 14.自動算出位置の算出
    # ===========================================================
    def calculationAutomaticCalculationPosition(
        self,
        objInputStopPosition: Dict[int, InputStopPositionData]
    ) -> Dict[int, InputStopPositionData]:
        """
        自動算出位置の算出
        
        Args:
            objInputStopPosition: 入力停止位置情報の辞書
            
        Returns:
            Dict[int, InputStopPositionData]: 自動算出位置を追加した停止位置情報の辞書
        """
        try:
            dTotalLength = 0.0
            dCirculationAxisStroke = 0.0
            dCirculationAxisPositionOffset = 0.0
            dSliderSize = 0.0
            
            # 外部モジュールからの「VTS全長」参照
            # 「VTS全長」の取得
            dTotalLength = self._axis_data_manipulater.getTotalLength()
            
            # 外部モジュールからの「循環軸ストローク」参照
            # 「循環軸ストローク」の取得
            dCirculationAxisStroke = self._axis_data_manipulater.getCirculationAxisStroke()
            
            # 外部モジュールからの「循環軸位置オフセット」参照
            # 「循環軸位置オフセット」の取得
            dCirculationAxisPositionOffset = self._axis_data_manipulater.getCirculationAxisPositionOffset()
            
            # 外部モジュールからの「スライダサイズ」参照
            # 「スライダサイズ」の取得
            dSliderSize = self._slider_data_manipulater.readSliderSize()
            
            # 「往路設定範囲の開始位置a」=「循環軸位置A」+「循環軸位置オフセット」+（「スライダサイズ」/2）
            self._DblOutboundRouteSettingRangeStartPositionA = (
                CIRCULATION_AXIS_POSITION_A +
                dCirculationAxisPositionOffset +
                (dSliderSize / DIVISOR_VALUE)
            )
            
            # 「往路設定範囲の終了位置b」=「循環軸位置A」+「循環軸位置オフセット」+｛「VTS全長」-（「スライダサイズ」/2)｝
            self._DblOutboundRouteSettingRangeEndPositionB = (
                CIRCULATION_AXIS_POSITION_A +
                dCirculationAxisPositionOffset +
                (dTotalLength - (dSliderSize / DIVISOR_VALUE))
            )
            
            # 「循環軸位置B」=「循環軸位置A」+「循環軸位置オフセット」+「VTS全長」+「循環軸位置オフセット」
            self._DblCirculationAxisPositionB = (
                CIRCULATION_AXIS_POSITION_A +
                dCirculationAxisPositionOffset +
                dTotalLength +
                dCirculationAxisPositionOffset
            )
            
            # 「循環軸位置C」=「循環軸位置B」+「循環軸ストローク」
            self._DblCirculationAxisPositionC = self._DblCirculationAxisPositionB + dCirculationAxisStroke
            
            # 「復路設定範囲の開始位置c」=「循環軸位置C」+「循環軸位置オフセット」+（「スライダサイズ」/2）
            self._DblReturnRouteSettingRangeStartPositionC = (
                self._DblCirculationAxisPositionC +
                dCirculationAxisPositionOffset +
                (dSliderSize / DIVISOR_VALUE)
            )
            
            # 「復路設定範囲の開始位置d」=「循環軸位置C」+「循環軸位置オフセット」+｛「VTS全長」-（「スライダサイズ」/2)｝
            self._DblReturnRouteSettingRangeEndPositionD = (
                self._DblCirculationAxisPositionC +
                dCirculationAxisPositionOffset +
                (dTotalLength - (dSliderSize / DIVISOR_VALUE))
            )
            
            # 「循環軸位置D」=「循環軸位置C」+「循環軸位置オフセット」+「VTS全長」+「循環軸位置オフセット」
            self._DblCirculationAxisPositionD = (
                self._DblCirculationAxisPositionC +
                dCirculationAxisPositionOffset +
                dTotalLength +
                dCirculationAxisPositionOffset
            )
            
            # 入力された停止位置を返答
            return objInputStopPosition
            
        except Exception as e:
            print(f"{MODULE_NAME_STOP_POSITION_MANIPULATER}.calculationAutomaticCalculationPosition: Error - {e}")
            return objInputStopPosition
    
    # ===========================================================
    # 15.指定位置の停止時間を設定
    # ===========================================================
    def setDesignationPositionStopTime(self, objInputStopPosition: Dict[int, InputStopPositionData]) -> None:
        """
        指定位置の停止時間を設定
        
        Args:
            objInputStopPosition: 入力停止位置情報の辞書
        """
        try:
            dCirculationAxisStroke = 0.0
            dCirculationAxisMaximumSpeed = 0.0
            dCirculationAxisAccDeceleration = 0.0
            dCirculationAxisStrokeTime = 0.0
            dSettingRangeStartPositionTransitTimeA = 0.0
            dSettingRangeStartPositionTransitTimeC = 0.0
            dEjectionTime = 0.0
            dEjectionDistance = 0.0
            dEjectMaximumSpeed = 0.0
            dEjectAccDeceleration = 0.0
            dTempStopTime = 0.0
            dEjectPositionB = 0.0
            dEjectPositionC = 0.0
            dEjectPositionD = 0.0
            iPoint = 0
            iControlControllerPattern = 0
            
            # 「循環軸のストローク」の取得
            dCirculationAxisStroke = self._axis_data_manipulater.getCirculationAxisStroke()
            
            # 循環軸上の停止位置までの最大速度を取得
            dCirculationAxisMaximumSpeed = self._user_input_data.get('circulation_axis_speed', 0.0)
            
            # 循環軸上の停止位置までの加減速度を取得
            dCirculationAxisAccDeceleration = self._user_input_data.get('circulation_axis_acc_decel', 0.0)
            
            # 「制御コントローラパターン」の取得
            iControlControllerPattern = self._user_input_data.get('control_pattern', 1)
            
            # 移動時間を算出
            dCirculationAxisStrokeTime = self.calculateTraveledTime(
                dCirculationAxisStroke,
                dCirculationAxisMaximumSpeed,
                dCirculationAxisAccDeceleration
            )
            
            # 「循環時間」=「算出移動時間」* 2
            dCirculationAxisStrokeTime = dCirculationAxisStrokeTime * MULTIPLIER_VALUE
            
            # 排出速度を取得
            dEjectMaximumSpeed = self._user_input_data.get('discharge_speed', 0.0)
            
            # 排出加減速度を取得
            dEjectAccDeceleration = self._user_input_data.get('discharge_acc_decel', 0.0)
            
            # 「制御コントローラパターン」= 「1」　か判定：分岐範囲
            if iControlControllerPattern == PATTERN:
                # 「排出位置c」=「復路設定範囲の開始位置c」
                dEjectPositionC = self._DblReturnRouteSettingRangeStartPositionC
                
                # 「排出距離」=「排出位置c」-「循環軸位置C」
                dEjectionDistance = dEjectPositionC - self._DblCirculationAxisPositionC
                
                # 移動時間を算出
                # 「排出時間」の設定
                dEjectionTime = self.calculateTraveledTime(
                    dEjectionDistance,
                    dEjectMaximumSpeed,
                    dEjectAccDeceleration
                )
                
                # 後方の最短停止位置の検索
                # 「停止位置nの停止位置ポイント」の設定
                iPoint = self.searchBackwardShortestStopPosition(
                    objInputStopPosition,
                    self._DblCirculationAxisPositionB
                )
                
                # 「停止時間（一時保存）」=「循環時間」+「排出時間」
                dTempStopTime = dCirculationAxisStrokeTime + dEjectionTime
                
                # 「停止時間n」<「停止時間（一時保存）」か判定：分岐範囲
                if objInputStopPosition[iPoint].dStopTime < dTempStopTime:
                    # 「停止時間n」=「停止時間n」+｛  (「循環時間」+「排出時間」) - 「停止時間n」}
                    objInputStopPosition[iPoint].dStopTime = (
                        objInputStopPosition[iPoint].dStopTime +
                        ((dCirculationAxisStrokeTime + dEjectionTime) - objInputStopPosition[iPoint].dStopTime)
                    )
                
                # 後方の最短停止位置の検索
                # 「停止位置mの停止位置ポイント」の設定
                iPoint = self.searchBackwardShortestStopPosition(
                    objInputStopPosition,
                    self._DblCirculationAxisPositionD
                )
                
                # 「停止位置mの停止時間」<「停止時間（一時保存）」か判定：分岐範囲
                if objInputStopPosition[iPoint].dStopTime < dTempStopTime:
                    # 「停止時間m」=「停止時間m」+｛  (「循環時間」+「排出時間」) - 「停止時間m」}
                    objInputStopPosition[iPoint].dStopTime = (
                        objInputStopPosition[iPoint].dStopTime +
                        ((dCirculationAxisStrokeTime + dEjectionTime) - objInputStopPosition[iPoint].dStopTime)
                    )
            else:
                # 前方の最短停止位置の検索
                # 「停止位置ポイント」の設定
                iPoint = self.searchForwardShortestStopPosition(
                    objInputStopPosition,
                    self._DblCirculationAxisPositionC
                )
                
                # コレクションを初期化
                # VBA相当：Set dicTempSliderData = CreateObject("Scripting.Dictionary")
                dicTempSliderData: Dict[int, SliderData] = {}
                
                # クラス名「dicTempSliderData」のインスタンスを生成
                # VBA相当：dicTempSliderData.Add TEMP_START_POSITION_C_ID_NUM, New SliderData
                dicTempSliderData[TEMP_START_POSITION_C_ID_NUM] = SliderData()
                
                # プロパティに値を設定
                # VBA相当：With dicTempSliderData(TEMP_START_POSITION_C_ID_NUM) ... End With
                objTempSlider = dicTempSliderData[TEMP_START_POSITION_C_ID_NUM]
                
                # 「最大速度（一時保存）」=「最短停止位置の最大速度」
                objTempSlider.dMaximumSpeed = objInputStopPosition[iPoint].dMaximumSpeed
                
                # 「加減速度（一時保存）」=「最短停止位置の加減速度」
                objTempSlider.dAccDeceleration = objInputStopPosition[iPoint].dAccDeceleration
                
                # 「現在位置（一時保存）」=「循環軸位置C」
                objTempSlider.dCurrentPosition = self._DblCirculationAxisPositionC
                
                # 「目標位置（一時保存）」=「最短停止位置」
                objTempSlider.dTargetPosition = objInputStopPosition[iPoint].dStopPosition
                
                # 速度制御の形を構築
                # VBA相当：Call SpeedControl.buildSpeedControlForm(dicTempSliderData(TEMP_START_POSITION_C_ID_NUM))
                self._speed_control.buildSpeedControlForm(objTempSlider)
                
                # 設定範囲の開始位置通過時間算出
                # 「通過時間C」の設定
                dSettingRangeStartPositionTransitTimeC = self.calculateStartRangePositionTransitTime(
                    objTempSlider,
                    self._DblReturnRouteSettingRangeStartPositionC
                )
                
                # 停止位置総数分ループ：開始
                # VBA相当：For Each vPoint In objInputStopPosition.Keys
                for vPoint in objInputStopPosition.keys():
                    # 「往路設定範囲の終了位置b」=「指定の位置」か判定：分岐範囲
                    if self._DblOutboundRouteSettingRangeEndPositionB == objInputStopPosition[vPoint].dStopPosition:
                        # 「排出位置bの停止時間」=「循環時間」+「通過時間C」
                        objInputStopPosition[vPoint].dStopTime = dCirculationAxisStrokeTime + dSettingRangeStartPositionTransitTimeC
                
                # 前方の最短停止位置の検索
                # 「停止位置ポイント」の設定
                iPoint = self.searchForwardShortestStopPosition(
                    objInputStopPosition,
                    CIRCULATION_AXIS_POSITION_A
                )
                
                # クラス名「dicTempSliderData」のインスタンスを生成
                # VBA相当：dicTempSliderData.Add TEMP_START_POSITION_A_ID_NUM, New SliderData
                dicTempSliderData[TEMP_START_POSITION_A_ID_NUM] = SliderData()
                
                # プロパティに値を設定
                # VBA相当：With dicTempSliderData(TEMP_START_POSITION_A_ID_NUM) ... End With
                objTempSliderA = dicTempSliderData[TEMP_START_POSITION_A_ID_NUM]
                
                # 「最大速度（一時保存）」=「最短停止位置の最大速度」
                objTempSliderA.dMaximumSpeed = objInputStopPosition[iPoint].dMaximumSpeed
                
                # 「加減速度（一時保存）」=「最短停止位置の加減速度」
                objTempSliderA.dAccDeceleration = objInputStopPosition[iPoint].dAccDeceleration
                
                # 「現在位置（一時保存）」=「循環軸位置A」
                objTempSliderA.dCurrentPosition = CIRCULATION_AXIS_POSITION_A
                
                # 「目標位置（一時保存）」=「最短停止位置」
                objTempSliderA.dTargetPosition = objInputStopPosition[iPoint].dStopPosition
                
                # 速度制御の形を構築
                # VBA相当：Call SpeedControl.buildSpeedControlForm(dicTempSliderData(TEMP_START_POSITION_A_ID_NUM))
                self._speed_control.buildSpeedControlForm(objTempSliderA)
                
                # 設定範囲の開始位置通過時間算出
                # 「通過時間a」の設定
                dSettingRangeStartPositionTransitTimeA = self.calculateStartRangePositionTransitTime(
                    objTempSliderA,
                    self._DblOutboundRouteSettingRangeStartPositionA
                )
                
                # 停止位置総数分ループ:開始
                # VBA相当：For Each vPoint In objInputStopPosition.Keys
                for vPoint in objInputStopPosition.keys():
                    # 「復路設定範囲の終了位置d」=「指定の位置」か判定：分岐範囲
                    if self._DblReturnRouteSettingRangeEndPositionD == objInputStopPosition[vPoint].dStopPosition:
                        # 「排出位置bの停止時間」=「循環時間」+「通過時間A」
                        objInputStopPosition[vPoint].dStopTime = dCirculationAxisStrokeTime + dSettingRangeStartPositionTransitTimeA
            
        except CycleTimeCalculationError:
            raise
        except Exception as e:
            print(f"{MODULE_NAME_STOP_POSITION_MANIPULATER}.setDesignationPositionStopTime: Error - {e}")
    
    # ===========================================================
    # 16.前方の最短停止位置の検索
    # ===========================================================
    def searchForwardShortestStopPosition(
        self,
        objInputStopPosition: Dict[int, InputStopPositionData],
        blCirculationAxisPosition: float
    ) -> int:
        """
        前方の最短停止位置の検索
        
        Args:
            objInputStopPosition: 入力停止位置情報の辞書
            blCirculationAxisPosition: 循環軸位置[mm]
            
        Returns:
            int: 停止位置ポイント
        """
        try:
            # 停止位置総数分ループ: 開始
            # VBA相当：For Each vPoint In objInputStopPosition.Keys
            # Python実装：キーをソートして順番に検索
            for vPoint in sorted(objInputStopPosition.keys()):
                # 「指定の停止位置」>「循環軸位置」か判定：分岐範囲
                if objInputStopPosition[vPoint].dStopPosition > blCirculationAxisPosition:
                    # 返り値=「停止位置ポイント」
                    return vPoint
            
            # ダイアログ表示
            # VBA相当：MsgBox "「循環軸位置」からの「最短停止位置」が存在しません。"
            # Python実装：例外を発生
            raise CycleTimeCalculationError(
                ErrorCode.CYCLE_TIME_SHORTEST_STOP_NOT_FOUND
            )
            
        except CycleTimeCalculationError:
            raise
        except Exception as e:
            print(f"{MODULE_NAME_STOP_POSITION_MANIPULATER}.searchForwardShortestStopPosition: Error - {e}")
            raise
    
    # ===========================================================
    # 17.設定範囲の開始位置通過時間算出
    # ===========================================================
    def calculateStartRangePositionTransitTime(
        self,
        objSiderData: SliderData,
        dSettingRangeStartPosition: float
    ) -> float:
        """
        設定範囲の開始位置通過時間算出
        
        Args:
            objSiderData: スライダデータオブジェクト
            dSettingRangeStartPosition: 設定範囲の開始位置[mm]
            
        Returns:
            float: 設定範囲の開始位置通過時間[s]
        """
        try:
            dSettingRangeStartPositionTransitTime = 0.0
            
            # VBA相当：With objSiderData ... End With
            # Python実装：直接アクセス
            
            # 「加速ポイント位置」>=「設定範囲の開始位置」か判定：分岐範囲
            if objSiderData.dAccelerationPointPosition >= dSettingRangeStartPosition:
                # 「設定範囲の開始位置通過時間」の算出
                # =√ {  2 * ( 「設定範囲の開始位置」-「現在位置」 )  }
                # / 「加減速度」
                # VBA相当：Sqr(...)
                # Python実装：math.sqrt(...)
                dSettingRangeStartPositionTransitTime = (
                    math.sqrt(TIME_CALCULATION_FIXED_VALUE * (dSettingRangeStartPosition - objSiderData.dCurrentPosition)) /
                    objSiderData.dAccDeceleration
                )
            # 「速度制御の形」=「三角形」か判定
            elif objSiderData.iSpeedControlShape == TRIANGLE:
                # 「設定範囲の開始位置通過時間」の算出
                # ={-「最大速度」
                # +√(「最大速度」^ 2
                # ＋ 8 *「加減速度」
                # * [ 「設定範囲の開始位置」-「加速ポイント位置」 ] }
                # / (2 * 「加減速度」)
                dSettingRangeStartPositionTransitTime = (
                    (-objSiderData.dMaximumSpeed +
                     math.sqrt(
                         objSiderData.dMaximumSpeed ** MULTIPLIER_VALUE +
                         ARRIVAL_TIME_CALCULATION_FIXED_VALUE * objSiderData.dAccDeceleration *
                         (dSettingRangeStartPosition - objSiderData.dAccelerationPointPosition)
                     )) /
                    (TIME_CALCULATION_FIXED_VALUE * objSiderData.dAccDeceleration)
                )
            # 「等速ポイント位置」>=「設定範囲の開始位置」か判定
            elif objSiderData.dConstantSpeedPointPosition >= dSettingRangeStartPosition:
                # 「設定範囲の開始位置通過時間」の算出
                # =(「設定範囲の開始位置」-「加速ポイント位置」)
                # /「最大速度」
                dSettingRangeStartPositionTransitTime = (
                    (dSettingRangeStartPosition - objSiderData.dAccelerationPointPosition) /
                    objSiderData.dMaximumSpeed
                )
            # 「減速ポイント位置」>=「設定範囲の開始位置」か判定
            elif objSiderData.dDecelerationPointPosition >= dSettingRangeStartPosition:
                # 「設定範囲の開始位置通過時間」の算出
                # ={-「最大速度」
                # +√(「最大速度」^ 2
                # '+ 8 *「加減速度」
                # '*  [ (「設定範囲の開始位置」-「現在位置」)
                # '- (「加速ポイント位置」-「現在位置」)
                # '- (「等速ポイント位置」-「現在位置」) ] ) }
                # '/ (2 *「加減速度」)
                dSettingRangeStartPositionTransitTime = (
                    (-objSiderData.dMaximumSpeed +
                     math.sqrt(
                         objSiderData.dMaximumSpeed ** MULTIPLIER_VALUE +
                         ARRIVAL_TIME_CALCULATION_FIXED_VALUE * objSiderData.dAccDeceleration *
                         ((dSettingRangeStartPosition - objSiderData.dCurrentPosition) -
                          (objSiderData.dAccelerationPointPosition - objSiderData.dCurrentPosition) -
                          (objSiderData.dConstantSpeedPointPosition - objSiderData.dCurrentPosition))
                     )) /
                    (TIME_CALCULATION_FIXED_VALUE * objSiderData.dAccDeceleration)
                )
            
            # 返り値=「設定範囲の開始位置通過時間」
            return dSettingRangeStartPositionTransitTime
            
        except Exception as e:
            print(f"{MODULE_NAME_STOP_POSITION_MANIPULATER}.calculateStartRangePositionTransitTime: Error - {e}")
            return 0.0
    
    # ===========================================================
    # 18.往路設定範囲の開始位置aを取得
    # ===========================================================
    def readOutboundRouteSettingRangeStartPositionA(self) -> float:
        """
        往路設定範囲の開始位置aを取得
        
        Returns:
            float: 往路設定範囲の開始位置a[mm]
        """
        try:
            # 返り値=「往路設定範囲の開始位置a」
            return self._DblOutboundRouteSettingRangeStartPositionA
        except Exception as e:
            print(f"{MODULE_NAME_STOP_POSITION_MANIPULATER}.readOutboundRouteSettingRangeStartPositionA: Error - {e}")
            return 0.0
    
    # ===========================================================
    # 19.後方の最短停止位置の検索
    # ===========================================================
    def searchBackwardShortestStopPosition(
        self,
        objInputStopPosition: Dict[int, InputStopPositionData],
        blCirculationAxisPosition: float
    ) -> int:
        """
        後方の最短停止位置の検索
        
        Args:
            objInputStopPosition: 入力停止位置情報の辞書
            blCirculationAxisPosition: 循環軸位置[mm]
            
        Returns:
            int: 停止位置ポイント
        """
        try:
            # 「全停止位置情報のキー（配列）」=「全停止位置情報のキー」
            # VBA相当：vInputStopPositionKeys = objInputStopPosition.Keys
            # Python実装：キーのリストを作成
            vInputStopPositionKeys = list(objInputStopPosition.keys())
            
            # 「全停止位置情報のキー（配列）」の外ループ：開始
            # VBA相当：For i = LBound(vInputStopPositionKeys) To UBound(vInputStopPositionKeys) - KEY_OFFSET
            # Python実装：降順にソート（後方から検索するため）
            # VBAのコードは降順ソートを実装している
            for i in range(len(vInputStopPositionKeys) - KEY_OFFSET):
                # 「全停止位置情報のキー（配列）」の内ループ：開始
                # VBA相当：For j = i + KEY_OFFSET To UBound(vInputStopPositionKeys)
                for j in range(i + KEY_OFFSET, len(vInputStopPositionKeys)):
                    # 外ループの「全停止位置情報のキー（配列）」　<　 内ループの「全停止位置情報のキー（配列）」か判定：分岐範囲
                    if vInputStopPositionKeys[i] < vInputStopPositionKeys[j]:
                        # 「全停止位置情報のキー（一時保存）」= 外ループの「全停止位置情報のキー（配列）」
                        vTemp = vInputStopPositionKeys[i]
                        
                        # 外ループの「全停止位置情報のキー（配列）」= 内ループの「全停止位置情報のキー（配列）」
                        vInputStopPositionKeys[i] = vInputStopPositionKeys[j]
                        
                        # 内ループの「全停止位置情報のキー（配列）」= 「全停止位置情報のキー（一時保存）」
                        vInputStopPositionKeys[j] = vTemp
            
            # 「全停止位置情報のキー（配列）」の配列数分ループ: 開始
            # VBA相当：For Each vPoint In vInputStopPositionKeys
            for vPoint in vInputStopPositionKeys:
                # 「循環軸位置」>「指定の停止位置」か判定：分岐範囲
                if blCirculationAxisPosition > objInputStopPosition[vPoint].dStopPosition:
                    # 返り値=「停止位置ポイント」
                    return vPoint
            
            # ダイアログ表示
            # VBA相当：MsgBox "「循環軸位置」の「後方の最短停止位置」が存在しません。"
            # Python実装：例外を発生
            raise CycleTimeCalculationError(
                ErrorCode.CYCLE_TIME_BACKWARD_SHORTEST_STOP_NOT_FOUND
            )
            
        except CycleTimeCalculationError:
            raise
        except Exception as e:
            print(f"{MODULE_NAME_STOP_POSITION_MANIPULATER}.searchBackwardShortestStopPosition: Error - {e}")
            raise
