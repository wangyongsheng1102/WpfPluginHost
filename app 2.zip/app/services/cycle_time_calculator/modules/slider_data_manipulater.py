"""
スライダデータ処理用プログラム
SliderDataManipulater.bas（VBA）の Python 移植版

[処理概要]
　・シート内で設定されたスライダのIDや長さを取得し、
   別モジュールから各スライダ設定値を参照・更新する

[索引]
　□1.スライダ情報の初期設定
　□2.外部モジュールからのスライダ情報参照
　□3.外部モジュールからの総スライダ数参照
　□4.外部モジュールからの「スライダサイズ」参照
"""

from typing import Dict, Optional
from .. import constants
from ..exceptions import CycleTimeCalculationError
from ..constants import (
    MODULE_NAME_SLIDER_DATA_MANIPULATER,
    SLIDER_LOWER_LIMIT_NUM_,
    SLIDER_UPPER_LIMIT_NUM_,
    SLIDER_FIRST_ID,
    PRODUCTION_NUMBER_COUNT_POSITION,
    RETURN_TRIP_VALID,
    SETTING_OUTWARD,
    SETTING_RETURN,
    SLIDER_ID_OFFSET,
    POINT_FIRST_NUMBER,
    SHORT_NAME,
    SHORT_LENGTH,
    SHORT_STOPPERS_LENGTH,
    LONG_LENGTH,
    LONG_STOPPERS_LENGTH,
    MOVE_VALUE,
    STOP_VALUE,
    FORMLESS,
    NONE,
    DEBUG_FLAG,
)
from ..classes.slider_data import SliderData


class SliderDataManipulater:
    """
    スライダデータ処理用クラス
    
    VBAのモジュール関数をクラスのメソッドに変換
    """
    
    def __init__(self, user_input_data: dict, axis_data_manipulater, stop_position_manipulater, speed_control):
        """
        初期化
        
        Args:
            user_input_data: ユーザ操作画面からの入力データ
            axis_data_manipulater: AxisDataManipulaterインスタンス
            stop_position_manipulater: StopPositionManipulaterインスタンス
            speed_control: SpeedControlインスタンス
        """
        self._user_input_data = user_input_data
        self._axis_data_manipulater = axis_data_manipulater
        self._stop_position_manipulater = stop_position_manipulater
        self._speed_control = speed_control
        
        # スライダデータ格納用のオブジェクト
        # VBA相当：Private DicSliderData As Object
        # Python実装：Dict[int, SliderData]
        self._DicSliderData: Dict[int, SliderData] = {}
    
    # ===========================================================
    # 1.スライダ情報の初期設定
    # ===========================================================
    def settingInitialData(self) -> bool:
        """
        スライダ情報の初期設定
        
        Returns:
            bool: 処理実行結果
        """
        try:
            # 返り値=True
            isInput = True
            
            # 「スライダの初期位置設定箇所」=「往路」
            iCurrentPositionSettingLocation = SETTING_OUTWARD
            
            # 停止位置情報の取得
            # VBA相当：Set objStopPosition = StopPositionManipulater.readStopPosition
            objStopPosition = self._stop_position_manipulater.readStopPosition()
            
            # ユーザ操作用のシートを指定
            # VBA相当：Set WsAllStopPositionInformation = ThisWorkbook.Sheets(USER_OPERATION_SHEET_NAME)
            # Python実装：ユーザ入力データから直接取得
            
            # スライダ数の取得
            # VBA相当：iSliderNum = WsAllStopPositionInformation.Range(SLIDER_NUMBER_CELL_NUMBER)
            iSliderNum = self._user_input_data.get('slider_count', 0)
            
            # 「スライダ数」< 2 Or 「スライダ数」> 128か判定：分岐範囲
            if iSliderNum < SLIDER_LOWER_LIMIT_NUM_ or iSliderNum > SLIDER_UPPER_LIMIT_NUM_:
                # ダイアログ表示
                # VBA相当：MsgBox "スライダ個数は2から128個で設定してください。"
                # Python実装：例外を発生
                from ..exceptions import CycleTimeCalculationError
                from app.core.errors import ErrorCode
                raise CycleTimeCalculationError(
                    ErrorCode.CYCLE_TIME_SLIDER_COUNT_INVALID
                )
            
            # VTS全長の取得
            # VBA相当：dTotalLength = AxisDataManipulater.getTotalLength
            dTotalLength = self._axis_data_manipulater.getTotalLength()
            
            # VTS復路ONか判定：分岐範囲
            if self._axis_data_manipulater.checkReturnTripAvailable() == RETURN_TRIP_VALID:
                # 「現在位置設定箇所」=「復路」
                iCurrentPositionSettingLocation = SETTING_RETURN
            else:
                # 「往路の終了側の払出位置にくるID」=1
                iEjectTargetPositionBId = SLIDER_FIRST_ID
            
            # コレクションを初期化
            # VBA相当：Set DicSliderData = CreateObject("Scripting.Dictionary")
            # Python実装：既に初期化済み（__init__で空のdict）
            self._DicSliderData = {}
            
            # スライダサイズの取得
            dSliderSize = self.readSliderSize()
            
            # スライダの総数分ループ：開始
            for iId in range(SLIDER_FIRST_ID, iSliderNum + 1):
                # クラス名「SliderData」のインスタンスを生成
                # VBA相当：DicSliderData.Add iId, New SliderData
                # Python実装：直接追加
                self._DicSliderData[iId] = SliderData()
                
                # プロパティに値を設定
                # VBA相当：With DicSliderData(iId) ... End With
                # Python実装：直接アクセス
                objSlider = self._DicSliderData[iId]
                
                # 「ID」の設定
                objSlider.iId = iId
                
                # 「スライダサイズ」の設定
                objSlider.dSliderSize = dSliderSize
                
                # 「サイクルタイム測定開始位置」= 0
                objSlider.dCycleTimeMeasurementStartPosition = PRODUCTION_NUMBER_COUNT_POSITION
                
                # 「現在位置」の設定箇所が「復路」か判定：分岐範囲
                if iCurrentPositionSettingLocation == SETTING_RETURN:
                    # 「ID」=1か判定：分岐範囲
                    if objSlider.iId == SLIDER_FIRST_ID:
                        # 「現在位置」=「排出位置d」
                        objSlider.dCurrentPosition = self._stop_position_manipulater.readReturnRouteSettingRangeEndPositionD()
                        
                        # 「総走行距離」=「現在位置」
                        objSlider.dTotalTraveledDistance = objSlider.dCurrentPosition
                    else:
                        # 「現在位置」=「前方のスライダIDの現在位置」-「スライダサイズ」
                        objSlider.dCurrentPosition = self._DicSliderData[iId - SLIDER_FIRST_ID].dCurrentPosition - dSliderSize
                        
                        # 「総移動距離」=「現在位置」
                        objSlider.dTotalTraveledDistance = objSlider.dCurrentPosition
                        
                        # 「後方スライダ位置(一時保存)」=「現在位置」-「スライダサイズ」
                        dBackwardSliderPosition = objSlider.dCurrentPosition - dSliderSize
                        
                        # 「復路設定範囲の開始位置c」>「後方スライダ位置(一時保存)」か判定：分岐範囲
                        if self._stop_position_manipulater.readReturnRouteSettingRangeStartPositionC() > dBackwardSliderPosition:
                            # 「現在位置設定箇所」=「往路」
                            iCurrentPositionSettingLocation = SETTING_OUTWARD
                            
                            # 「排出位置bのID」を設定
                            iEjectTargetPositionBId = objSlider.iId + SLIDER_ID_OFFSET
                else:
                    # 「指定のスライダID」=「排出位置bのID」か判定：分岐範囲
                    if objSlider.iId == iEjectTargetPositionBId:
                        # 「現在位置」=「排出位置b」
                        objSlider.dCurrentPosition = self._stop_position_manipulater.readOutboundRouteSettingRangeEndPositionB()
                        
                        # 「総移動距離」=「現在位置」
                        objSlider.dTotalTraveledDistance = objSlider.dCurrentPosition
                    else:
                        # 「現在位置」=「前方のスライダIDの現在位置」-「スライダサイズ」
                        objSlider.dCurrentPosition = self._DicSliderData[iId - SLIDER_ID_OFFSET].dCurrentPosition - dSliderSize
                        
                        # 「総移動距離」=「現在位置」
                        objSlider.dTotalTraveledDistance = objSlider.dCurrentPosition
                
                # 「停止位置ポイント」の数分ループ：開始
                # VBA相当：For lPoint = POINT_FIRST_NUMBER To objStopPosition.Count
                # Python実装：objStopPositionはdictなので、keys()を使用
                for lPoint in range(POINT_FIRST_NUMBER, len(objStopPosition) + 1):
                    # 「停止位置」>=「現在位置」か判定：分岐範囲
                    if objStopPosition[lPoint].dStopPosition >= objSlider.dCurrentPosition:
                        # 「停止位置ポイント」を設定
                        objSlider.iStopPositionPoint = objStopPosition[lPoint].iPoint
                        
                        # 「最短停止位置」を設定
                        objSlider.dShortestStopPosition = objStopPosition[lPoint].dStopPosition
                        
                        # 「停止位置」≠「現在位置」か判定：分岐範囲
                        if objStopPosition[lPoint].dStopPosition != objSlider.dCurrentPosition:
                            # 「状態」=「移動」
                            objSlider.iState = MOVE_VALUE
                            
                            # 「最大速度」を設定
                            objSlider.dMaximumSpeed = objStopPosition[lPoint].dMaximumSpeed
                            
                            # 「加減速度」を設定
                            objSlider.dAccDeceleration = objStopPosition[lPoint].dAccDeceleration
                            
                            # 「目標位置」=「最短停止位置」
                            objSlider.dTargetPosition = objSlider.dShortestStopPosition
                            
                            # 「目標位置移動距離」=「 最短停止位置」-「現在位置」
                            objSlider.dTargetPositionTraveledDistance = objSlider.dShortestStopPosition - objSlider.dCurrentPosition
                            
                            # 速度制御の形を構築
                            # VBA相当：SpeedControl.buildSpeedControlForm (DicSliderData(iId))
                            self._speed_control.buildSpeedControlForm(objSlider)
                        else:
                            # 「速度制御の形」=「無」
                            objSlider.iSpeedControlShape = FORMLESS
                            
                            # 「加速状態」=「無」
                            objSlider.iAccelerationState = NONE
                            
                            # 「状態」=「停止」
                            objSlider.iState = STOP_VALUE
                            
                            # 「処理時間」= 0
                            objSlider.dProcessingTime = 0.0
                        
                        # 「停止位置ポイント」の数分ループを強制終了
                        break
            
            # 返り値=「処理実行結果」
            return isInput
            
        except CycleTimeCalculationError:
            # 呼び出し元で明示的な計算エラーを伝播する
            raise
        except Exception as e:
            print(f"{MODULE_NAME_SLIDER_DATA_MANIPULATER}.settingInitialData: Error - {e}")
            return False
    
    # ===========================================================
    # 2.外部モジュールからのスライダ情報参照
    # ===========================================================
    def readSliderData(self) -> Dict[int, SliderData]:
        """
        外部モジュールからのスライダ情報参照
        
        Returns:
            Dict[int, SliderData]: スライダ情報の辞書
        """
        try:
            # 返り値=「スライダ情報」
            return self._DicSliderData
        except Exception as e:
            print(f"{MODULE_NAME_SLIDER_DATA_MANIPULATER}.readSliderData: Error - {e}")
            return {}
    
    # ===========================================================
    # 3.外部モジュールからの総スライダ数参照
    # ===========================================================
    def readTotalSliderNum(self) -> int:
        """
        外部モジュールからの総スライダ数参照
        
        Returns:
            int: 総スライダ数
        """
        try:
            # 総スライダ数を返答
            return len(self._DicSliderData)
        except Exception as e:
            print(f"{MODULE_NAME_SLIDER_DATA_MANIPULATER}.readTotalSliderNum: Error - {e}")
            return 0
    
    # ===========================================================
    # 4.外部モジュールからの「スライダサイズ」参照
    # ===========================================================
    def readSliderSize(self) -> float:
        """
        外部モジュールからの「スライダサイズ」参照
        
        Returns:
            float: スライダサイズ[mm]
        """
        try:
            dSliderLength = 0.0
            dSliderSize = 0.0
            dSliderGap = 0.0
            sShortName = ""
            
            # スライダの種類を取得
            # VBA相当：sShortName = wsUserOperationt.Range(SLIDER_TYPE_CELL_NUMBER)
            sShortName = self._user_input_data.get('slider_type', '')
            
            # 「スライダの種類」=「ショート」」か判定
            if sShortName == SHORT_NAME:
                # 「スライダ長さ」=「シートの長さ」
                dSliderLength = SHORT_LENGTH + SHORT_STOPPERS_LENGTH
            else:
                # 「スライダ長さ」=「ロングの長さ」
                dSliderLength = LONG_LENGTH + LONG_STOPPERS_LENGTH
            
            # シート名「位置設定範囲」のセル「B3」から「スライダギャップ」を取得
            # 「スライダギャップ」の設定
            # VBA相当：dSliderGap = wsPositionSettingRange.Range(SLIDER_GAP_CELL_NUMBER).Value
            dSliderGap = self._user_input_data.get('slider_gap', 0.0)
            
            # 「スライダサイズ」=「スライダ長さ」+「スライダギャップ」
            dSliderSize = dSliderLength + dSliderGap
            
            # 「スライダサイズ」を返答
            return dSliderSize
            
        except Exception as e:
            print(f"{MODULE_NAME_SLIDER_DATA_MANIPULATER}.readSliderSize: Error - {e}")
            return 0.0
