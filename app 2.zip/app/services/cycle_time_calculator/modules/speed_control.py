"""
速度制御の構築
SpeedControl.bas（VBA）の Python 移植版

[処理概要]
　・スライダの速度制御

[索引]
　□1.速度の形を構築
　□2.加速状態切り替え
　□3.現在速度の更新
　□4.速度制御の形変更を判定
"""

import math
from typing import Dict
from .. import constants
from ..constants import (
    MODULE_NAME_SPEED_CONTROL,
    DIVISION_VALUE_SPEED_CONTROL,
    MULTIPLIER_VALUE_SPEED_CONTROL,
    TIME_CALCULATION_FIXED_VALUE_SPEED_CONTROL,
    SWITCHING_SPEED_FIXED_VALUE_SPEED_CONTROL,
    DISTANCE_CALCULATION_FIXED_VALUE_SPEED_CONTROL,
    ALLOWABLE_DIFFERENCE_RANGE,
    FORMLESS,
    NONE,
    STOP_VALUE,
    TRAPEZOID,
    ACCELERATION,
    CONSTANT_SPEED,
    DECELERATION,
    TRIANGLE,
    LINE,
    FIRST_SLIDER_ID,
    NO_COLLISION,
    COLLISION,
    DEBUG_FLAG,
    DEBUG_ID,
    DEBUG_START_TIME,
)
from ..classes.slider_data import SliderData


class SpeedControl:
    """
    速度制御クラス
    
    VBAのモジュール関数をクラスのメソッドに変換
    """
    
    def __init__(self, axis_data_manipulater, slider_data_manipulater, collision_detecter, main_controller):
        """
        初期化
        
        Args:
            axis_data_manipulater: AxisDataManipulaterインスタンス
            slider_data_manipulater: SliderDataManipulaterインスタンス
            collision_detecter: CollisionDetecterインスタンス
            main_controller: MainControllerインスタンス（readCurrentTime用）
        """
        self._axis_data_manipulater = axis_data_manipulater
        self._slider_data_manipulater = slider_data_manipulater
        self._collision_detecter = collision_detecter
        self._main_controller = main_controller
    
    # ===========================================================
    # 1.速度の形を構築
    # ===========================================================
    def buildSpeedControlForm(self, objSliderData: SliderData) -> None:
        """
        速度の形を構築
        
        Args:
            objSliderData: スライダデータオブジェクト
        """
        try:
            dDecelerationDistance = 0.0
            dAccelerationDistance = 0.0
            dAccDecelerationSwitchPoint = 0.0
            dConstantSpeedDistance = 0.0
            dSqrArgument = 0.0
            dTargetPositionDifference = 0.0
            
            # VBA相当：With objSliderData ... End With
            # Python実装：直接アクセス
            
            # 「目標位置差分」= 「目標位置」と「現在位置」の差分
            dTargetPositionDifference = abs(objSliderData.dTargetPosition - objSliderData.dCurrentPosition)
            
            # 「目標位置差分」<「許容差分」か判定：分岐範囲
            if dTargetPositionDifference < ALLOWABLE_DIFFERENCE_RANGE:
                # 「目標位置」=「現在位置」
                objSliderData.dTargetPosition = objSliderData.dCurrentPosition
            
            # 「現在位置」>「目標位置」か判定：分岐範囲
            if objSliderData.dCurrentPosition > objSliderData.dTargetPosition:
                # 「目標位置移動距離」= （「目標位置」+「循環システム1周分の長さ」）-「現在位置」
                dSliderSize = self._slider_data_manipulater.readSliderSize()
                dOneLap = self._axis_data_manipulater.readOneLap(dSliderSize)
                objSliderData.dTargetPositionTraveledDistance = (
                    (objSliderData.dTargetPosition + dOneLap) - objSliderData.dCurrentPosition
                )
            else:
                # 「目標位置移動距離」= 「目標位置」-「現在位置」
                objSliderData.dTargetPositionTraveledDistance = (
                    objSliderData.dTargetPosition - objSliderData.dCurrentPosition
                )
            
            # 「目標位置移動距離」= 0か判定：分岐範囲
            if objSliderData.dTargetPositionTraveledDistance == 0:
                # 「速度制御の形」=「無」
                objSliderData.iSpeedControlShape = FORMLESS
                
                # 「加速状態」=「無」
                objSliderData.iAccelerationState = NONE
                
                # 「状態」=「停止」
                objSliderData.iState = STOP_VALUE
                
                # 「最大速度」= 0
                objSliderData.dMaximumSpeed = 0.0
                
                # 「加減速度」= 0
                objSliderData.dAccDeceleration = 0.0
                
                # 「現在速度」= 0
                objSliderData.dCurrentSpeed = 0.0
                
                # 「処理時間」=0
                objSliderData.dProcessingTime = 0.0
            else:
                # 「Sqr関数の引数」算出
                # （「目標位置移動距離」*「加減速度」）
                # +（0.5*「現在速度」^2）
                dSqrArgument = (
                    (objSliderData.dTargetPositionTraveledDistance * objSliderData.dAccDeceleration) +
                    (SWITCHING_SPEED_FIXED_VALUE_SPEED_CONTROL * (objSliderData.dCurrentSpeed ** MULTIPLIER_VALUE_SPEED_CONTROL))
                )
                
                # 「加減速度変更点」の算出
                # =√（「目標位置移動距離」*「加減速度」）
                # +（0.5*「現在速度」^2）
                # VBA相当：Sqr(...)
                # Python実装：math.sqrt(...)
                dAccDecelerationSwitchPoint = math.sqrt(
                    (objSliderData.dTargetPositionTraveledDistance * objSliderData.dAccDeceleration) +
                    (SWITCHING_SPEED_FIXED_VALUE_SPEED_CONTROL * (objSliderData.dCurrentSpeed ** MULTIPLIER_VALUE_SPEED_CONTROL))
                )
                
                # 「加減速度」= 0か判定：分岐範囲
                if objSliderData.dAccDeceleration == 0:
                    # 「加速時間」= 0
                    objSliderData.dAccelerationTime = 0.0
                else:
                    # 「加速時間」=（「加減速度変更点」-「現在速度」）/「加減速度」
                    objSliderData.dAccelerationTime = (
                        (dAccDecelerationSwitchPoint - objSliderData.dCurrentSpeed) / objSliderData.dAccDeceleration
                    )
                
                # 「加減速度変更点」>「最大速度」 And 「現在速度」≠「最大速度」か判定：分岐範囲
                if dAccDecelerationSwitchPoint > objSliderData.dMaximumSpeed and objSliderData.dCurrentSpeed != objSliderData.dMaximumSpeed:
                    # 「速度制御の形」=「台形」
                    objSliderData.iSpeedControlShape = TRAPEZOID
                    
                    # 「加速状態」=「加速」
                    objSliderData.iAccelerationState = ACCELERATION
                    
                    # 「加速時間」= （「最大速度」 - 「現在速度」）/「加減速度」
                    objSliderData.dAccelerationTime = (
                        (objSliderData.dMaximumSpeed - objSliderData.dCurrentSpeed) / objSliderData.dAccDeceleration
                    )
                    
                    # 「加速距離」
                    # =（「現在速度」*「加速時間」）
                    # + 0.5 * （「最大速度」-「現在速度」）*「加速時間」
                    dAccelerationDistance = (
                        (objSliderData.dCurrentSpeed * objSliderData.dAccelerationTime) +
                        DISTANCE_CALCULATION_FIXED_VALUE_SPEED_CONTROL *
                        (objSliderData.dMaximumSpeed - objSliderData.dCurrentSpeed) *
                        objSliderData.dAccelerationTime
                    )
                    
                    # 「減速時間」 = 「最大速度」 / 「加減速度」
                    objSliderData.dDecelerationTime = objSliderData.dMaximumSpeed / objSliderData.dAccDeceleration
                    
                    # 「減速距離」=  0.5 *「最大速度」* 「減速時間」
                    dDecelerationDistance = (
                        DISTANCE_CALCULATION_FIXED_VALUE_SPEED_CONTROL *
                        objSliderData.dMaximumSpeed *
                        objSliderData.dDecelerationTime
                    )
                    
                    # 「等速距離」=「目標位置移動距離」-（「加速距離」+「減速距離」）
                    dConstantSpeedDistance = (
                        objSliderData.dTargetPositionTraveledDistance -
                        (dAccelerationDistance + dDecelerationDistance)
                    )
                    
                    # 「等速時間」=「等速距離」/「最大速度」
                    objSliderData.dConstantSpeedTime = dConstantSpeedDistance / objSliderData.dMaximumSpeed
                    
                    # 「処理時間」=「加速時間」
                    objSliderData.dProcessingTime = objSliderData.dAccelerationTime
                    
                    # 「加速ポイント位置」=「現在位置」+「加速距離」
                    objSliderData.dAccelerationPointPosition = objSliderData.dCurrentPosition + dAccelerationDistance
                    
                    # 「加速ポイント位置」>=「循環システム1周分の長さ」か判定
                    dSliderSize = self._slider_data_manipulater.readSliderSize()
                    dOneLap = self._axis_data_manipulater.readOneLap(dSliderSize)
                    if objSliderData.dAccelerationPointPosition >= dOneLap:
                        # 「加速ポイント位置」= 「加速ポイント位置」-「循環システム1周分の長さ」
                        objSliderData.dAccelerationPointPosition = objSliderData.dAccelerationPointPosition - dOneLap
                    
                    # 「タスクのポイント位置」=「加速ポイント位置」
                    objSliderData.dTaskPointPosition = objSliderData.dAccelerationPointPosition
                    
                    # 「等速ポイント位置」=「現在位置」+「加速距離」+「等速距離」
                    objSliderData.dConstantSpeedPointPosition = (
                        objSliderData.dCurrentPosition + dAccelerationDistance + dConstantSpeedDistance
                    )
                    
                    # 「等速ポイント位置」>=「循環システム1周分の長さ」か判定
                    if objSliderData.dConstantSpeedPointPosition >= dOneLap:
                        # 「等速ポイント位置」= 「等速ポイント位置」-「循環システム1周分の長さ」
                        objSliderData.dConstantSpeedPointPosition = objSliderData.dConstantSpeedPointPosition - dOneLap
                    
                    # 「減速ポイント位置」=「現在位置」+「加速距離」+「等速距離」+「減速距離」
                    objSliderData.dDecelerationPointPosition = (
                        objSliderData.dCurrentPosition +
                        dAccelerationDistance +
                        dConstantSpeedDistance +
                        dDecelerationDistance
                    )
                    
                    # 「減速ポイント位置」>=「循環システム1周分の長さ」か判定
                    if objSliderData.dDecelerationPointPosition >= dOneLap:
                        # 「減速ポイント位置」= 「減速ポイント位置」-「循環システム1周分の長さ」
                        objSliderData.dDecelerationPointPosition = objSliderData.dDecelerationPointPosition - dOneLap
                
                # 「加減速度変更点」>「最大速度」 And 「現在速度」=「最大速度」か判定
                elif (dAccDecelerationSwitchPoint > objSliderData.dMaximumSpeed and
                      objSliderData.dCurrentSpeed == objSliderData.dMaximumSpeed):
                    # 「速度制御の形」=「台形」
                    objSliderData.iSpeedControlShape = TRAPEZOID
                    
                    # 「加速状態」=「等速」
                    objSliderData.iAccelerationState = CONSTANT_SPEED
                    
                    # 「減速時間」 = 「最大速度」 / 「加減速度」
                    objSliderData.dDecelerationTime = objSliderData.dMaximumSpeed / objSliderData.dAccDeceleration
                    
                    # 「減速距離」=  0.5 *「最大速度」* 「減速時間」
                    dDecelerationDistance = (
                        DISTANCE_CALCULATION_FIXED_VALUE_SPEED_CONTROL *
                        objSliderData.dMaximumSpeed *
                        objSliderData.dDecelerationTime
                    )
                    
                    # 「等速距離」=「目標位置移動距離」-「減速距離」
                    dConstantSpeedDistance = objSliderData.dTargetPositionTraveledDistance - dDecelerationDistance
                    
                    # 「等速時間」=「等速距離」/「最大速度」
                    objSliderData.dConstantSpeedTime = dConstantSpeedDistance / objSliderData.dMaximumSpeed
                    
                    # 「処理時間」=「等速時間」
                    objSliderData.dProcessingTime = objSliderData.dConstantSpeedTime
                    
                    # 「等速ポイント位置」=「現在位置」+「等速距離」
                    objSliderData.dConstantSpeedPointPosition = objSliderData.dCurrentPosition + dConstantSpeedDistance
                    
                    # 「等速ポイント位置」>=「循環システム1周分の長さ」か判定：分岐範囲
                    dSliderSize = self._slider_data_manipulater.readSliderSize()
                    dOneLap = self._axis_data_manipulater.readOneLap(dSliderSize)
                    if objSliderData.dConstantSpeedPointPosition >= dOneLap:
                        # 「等速ポイント位置」= 「等速ポイント位置」-「循環システム1周分の長さ」
                        objSliderData.dConstantSpeedPointPosition = objSliderData.dConstantSpeedPointPosition - dOneLap
                    
                    # 「タスクのポイント位置」=「等速ポイント位置」
                    objSliderData.dTaskPointPosition = objSliderData.dConstantSpeedPointPosition
                    
                    # 「減速ポイント位置」=「現在位置」+「等速距離」+「減速距離」
                    objSliderData.dDecelerationPointPosition = (
                        objSliderData.dCurrentPosition + dConstantSpeedDistance + dDecelerationDistance
                    )
                    
                    # 「減速ポイント位置」>=「循環システム1周分の長さ」か判定：分岐範囲
                    if objSliderData.dDecelerationPointPosition >= dOneLap:
                        # 「減速ポイント位置」= 「減速ポイント位置」-「循環システム1周分の長さ」
                        objSliderData.dDecelerationPointPosition = objSliderData.dDecelerationPointPosition - dOneLap
                
                # 「加減速度変更点」=「最大速度」And「加速時間」> 0か判定
                elif dAccDecelerationSwitchPoint == objSliderData.dMaximumSpeed and objSliderData.dAccelerationTime > 0:
                    # 「速度制御の形」=「三角形」
                    objSliderData.iSpeedControlShape = TRIANGLE
                    
                    # 「加速状態」=「加速」
                    objSliderData.iAccelerationState = ACCELERATION
                    
                    # 「処理時間」=「加速時間」
                    objSliderData.dProcessingTime = objSliderData.dAccelerationTime
                    
                    # 「加速距離」
                    # =（「現在速度」*「加速時間」）
                    # + 0.5 * （「最大速度」-「現在速度」）*「加速時間」
                    dAccelerationDistance = (
                        (objSliderData.dCurrentSpeed * objSliderData.dAccelerationTime) +
                        DISTANCE_CALCULATION_FIXED_VALUE_SPEED_CONTROL *
                        (objSliderData.dMaximumSpeed - objSliderData.dCurrentSpeed) *
                        objSliderData.dAccelerationTime
                    )
                    
                    # 「減速時間」 = 「最大速度」 / 「加減速度」
                    objSliderData.dDecelerationTime = objSliderData.dMaximumSpeed / objSliderData.dAccDeceleration
                    
                    # 「減速距離」=  0.5 *「最大速度」* 「減速時間」
                    dDecelerationDistance = (
                        DISTANCE_CALCULATION_FIXED_VALUE_SPEED_CONTROL *
                        objSliderData.dMaximumSpeed *
                        objSliderData.dDecelerationTime
                    )
                    
                    # 「加速ポイント位置」=「現在位置」+「加速距離」
                    objSliderData.dAccelerationPointPosition = objSliderData.dCurrentPosition + dAccelerationDistance
                    
                    # 「加速ポイント位置」>=「循環システム1周分の長さ」か判定：分岐範囲
                    dSliderSize = self._slider_data_manipulater.readSliderSize()
                    dOneLap = self._axis_data_manipulater.readOneLap(dSliderSize)
                    if objSliderData.dAccelerationPointPosition >= dOneLap:
                        # 「加速ポイント位置」= 「加速ポイント位置」-「循環システム1周分の長さ」
                        objSliderData.dAccelerationPointPosition = objSliderData.dAccelerationPointPosition - dOneLap
                    
                    # 「タスクのポイント位置」=「加速ポイント位置」
                    objSliderData.dTaskPointPosition = objSliderData.dAccelerationPointPosition
                    
                    # 「減速ポイント位置」=「現在位置」+「加速距離」+「減速距離」
                    objSliderData.dDecelerationPointPosition = (
                        objSliderData.dCurrentPosition + dAccelerationDistance + dDecelerationDistance
                    )
                    
                    # 「減速ポイント位置」>=「循環システム1周分の長さ」か判定：分岐範囲
                    if objSliderData.dDecelerationPointPosition >= dOneLap:
                        # 「減速ポイント位置」= 「減速ポイント位置」-「循環システム1周分の長さ」
                        objSliderData.dDecelerationPointPosition = objSliderData.dDecelerationPointPosition - dOneLap
                
                # 「最大速度」>「加減速度変更点」 And 「加速時間」> 0か判定
                elif objSliderData.dMaximumSpeed > dAccDecelerationSwitchPoint and objSliderData.dAccelerationTime > 0:
                    # 「速度制御の形」=「三角形」
                    objSliderData.iSpeedControlShape = TRIANGLE
                    
                    # 「加速状態」=「加速」
                    objSliderData.iAccelerationState = ACCELERATION
                    
                    # 「処理時間」=「加速時間」
                    objSliderData.dProcessingTime = objSliderData.dAccelerationTime
                    
                    # 「加速距離」
                    # =（「現在速度」*「加速時間」）
                    # + 0.5 * （「加減速度変更点」-「現在速度」）*「加速時間」
                    dAccelerationDistance = (
                        (objSliderData.dCurrentSpeed * objSliderData.dAccelerationTime) +
                        DISTANCE_CALCULATION_FIXED_VALUE_SPEED_CONTROL *
                        (dAccDecelerationSwitchPoint - objSliderData.dCurrentSpeed) *
                        objSliderData.dAccelerationTime
                    )
                    
                    # 「減速時間」=「加減速度変更点」/「加減速度」
                    objSliderData.dDecelerationTime = dAccDecelerationSwitchPoint / objSliderData.dAccDeceleration
                    
                    # 「減速距離」= 0.5 * 「加減速度変更点」*「減速時間」
                    dDecelerationDistance = (
                        DISTANCE_CALCULATION_FIXED_VALUE_SPEED_CONTROL *
                        dAccDecelerationSwitchPoint *
                        objSliderData.dDecelerationTime
                    )
                    
                    # 「加速ポイント位置」=「現在位置」+「加速距離」
                    objSliderData.dAccelerationPointPosition = objSliderData.dCurrentPosition + dAccelerationDistance
                    
                    # 「加速ポイント位置」>=「循環システム1周分の長さ」か判定：分岐範囲
                    dSliderSize = self._slider_data_manipulater.readSliderSize()
                    dOneLap = self._axis_data_manipulater.readOneLap(dSliderSize)
                    if objSliderData.dAccelerationPointPosition >= dOneLap:
                        # 「加速ポイント位置」= 「加速ポイント位置」-「循環システム1周分の長さ」
                        objSliderData.dAccelerationPointPosition = objSliderData.dAccelerationPointPosition - dOneLap
                    
                    # 「タスクのポイント位置」=「加速ポイント位置」
                    objSliderData.dTaskPointPosition = objSliderData.dAccelerationPointPosition
                    
                    # 「減速ポイント位置」=「現在位置」+「加速距離」+「減速距離」
                    objSliderData.dDecelerationPointPosition = (
                        objSliderData.dCurrentPosition + dAccelerationDistance + dDecelerationDistance
                    )
                    
                    # 「減速ポイント位置」>=「循環システム1周分の長さ」か判定：分岐範囲
                    if objSliderData.dDecelerationPointPosition >= dOneLap:
                        # 「減速ポイント位置」= 「減速ポイント位置」-「循環システム1周分の長さ」
                        objSliderData.dDecelerationPointPosition = objSliderData.dDecelerationPointPosition - dOneLap
                
                # 「最大速度」>=「加減速度変更点」 And  0 >=「加速時間」か判定
                elif objSliderData.dMaximumSpeed >= dAccDecelerationSwitchPoint and 0 >= objSliderData.dAccelerationTime:
                    # 「速度制御の形」=「線」
                    objSliderData.iSpeedControlShape = LINE
                    
                    # 「加速状態」=「減速」
                    objSliderData.iAccelerationState = DECELERATION
                    
                    # 「減速時間」=「現在速度」/「加減速度」
                    objSliderData.dDecelerationTime = objSliderData.dCurrentSpeed / objSliderData.dAccDeceleration
                    
                    # 「減速距離」=0.5 * 「現在速度」*「減速時間」
                    dDecelerationDistance = (
                        DISTANCE_CALCULATION_FIXED_VALUE_SPEED_CONTROL *
                        objSliderData.dCurrentSpeed *
                        objSliderData.dDecelerationTime
                    )
                    
                    # 「処理時間」=「減速時間」
                    objSliderData.dProcessingTime = objSliderData.dDecelerationTime
                    
                    # 「減速ポイント位置」=「現在位置」+「減速距離」
                    objSliderData.dDecelerationPointPosition = objSliderData.dCurrentPosition + dDecelerationDistance
                    
                    # 「減速ポイント位置」>=「循環システム1周分の長さ」か判定：分岐範囲
                    dSliderSize = self._slider_data_manipulater.readSliderSize()
                    dOneLap = self._axis_data_manipulater.readOneLap(dSliderSize)
                    if objSliderData.dDecelerationPointPosition >= dOneLap:
                        # 「減速ポイント位置」= 「減速ポイント位置」-「循環システム1周分の長さ」
                        objSliderData.dDecelerationPointPosition = objSliderData.dDecelerationPointPosition - dOneLap
                    
                    # 「タスクのポイント位置」=「減速ポイント位置」
                    objSliderData.dTaskPointPosition = objSliderData.dDecelerationPointPosition
                    
                    # 「目標位置」=「減速ポイント位置」
                    objSliderData.dTargetPosition = objSliderData.dDecelerationPointPosition
            
        except Exception as e:
            print(f"{MODULE_NAME_SPEED_CONTROL}.buildSpeedControlForm: Error - {e}")
    
    # ===========================================================
    # 2.加速状態切り替え
    # ===========================================================
    def switchingAccelerationState(self, objSliderData: SliderData) -> None:
        """
        加速状態切り替え
        
        Args:
            objSliderData: スライダデータオブジェクト
        """
        try:
            # VBA相当：With objSliderData ... End With
            # Python実装：直接アクセス
            
            # 「速度制御の形」=「台形」か判定
            if objSliderData.iSpeedControlShape == TRAPEZOID:
                # 「加速状態」=「加速」
                if objSliderData.iAccelerationState == ACCELERATION:
                    # 「加速状態」=「等速」
                    objSliderData.iAccelerationState = CONSTANT_SPEED
                    
                    # 「処理時間」=「等速時間」
                    objSliderData.dProcessingTime = objSliderData.dConstantSpeedTime
                    
                    # 「タスクのポイント位置」=「等速ポイント位置」
                    objSliderData.dTaskPointPosition = objSliderData.dConstantSpeedPointPosition
                else:
                    # 「加速状態」=「減速」
                    objSliderData.iAccelerationState = DECELERATION
                    
                    # 「処理時間」=「減速時間」
                    objSliderData.dProcessingTime = objSliderData.dDecelerationTime
                    
                    # 「タスクのポイント位置」=「減速ポイント位置」
                    objSliderData.dTaskPointPosition = objSliderData.dDecelerationPointPosition
            else:
                # 「加速状態」=「減速」
                objSliderData.iAccelerationState = DECELERATION
                
                # 「処理時間」=「減速時間」
                objSliderData.dProcessingTime = objSliderData.dDecelerationTime
                
                # 「タスクのポイント位置」=「減速ポイント位置」
                objSliderData.dTaskPointPosition = objSliderData.dDecelerationPointPosition
            
        except Exception as e:
            print(f"{MODULE_NAME_SPEED_CONTROL}.switchingAccelerationState: Error - {e}")
    
    # ===========================================================
    # 3.現在速度の更新
    # ===========================================================
    def updateCurrentSpeed(self, objSliderData: SliderData, dMinimumProcessingTime: float) -> None:
        """
        現在速度の更新
        
        Args:
            objSliderData: スライダデータオブジェクト
            dMinimumProcessingTime: 最小の処理時間[s]
        """
        try:
            # VBA相当：With objSliderData ... End With
            # Python実装：直接アクセス
            
            # 「加速状態」=「加速」か判定：分岐範囲
            if objSliderData.iAccelerationState == ACCELERATION:
                # 「前回の速度」=「現在速度」
                objSliderData.dLastCurrentSpeed = objSliderData.dCurrentSpeed
                
                # 「現在速度」= 「現在速度」+「加減速度」* 「最小の処理時間」
                objSliderData.dCurrentSpeed = (
                    objSliderData.dCurrentSpeed +
                    objSliderData.dAccDeceleration * dMinimumProcessingTime
                )
                
                # 「現在速度」>=「最大速度」か判定
                if objSliderData.dCurrentSpeed >= objSliderData.dMaximumSpeed:
                    # 「現在速度」= 「最大速度」
                    objSliderData.dCurrentSpeed = objSliderData.dMaximumSpeed
            
            # 「加速状態」=「等速」か判定
            elif objSliderData.iAccelerationState == CONSTANT_SPEED:
                # 「前回の速度」=「現在速度」
                objSliderData.dLastCurrentSpeed = objSliderData.dCurrentSpeed
                
                # 「現在速度」= 「最大速度」
                objSliderData.dCurrentSpeed = objSliderData.dMaximumSpeed
            
            # 「加速状態」=「減速」か判定
            elif objSliderData.iAccelerationState == DECELERATION:
                # 「前回の速度」=「現在速度」
                objSliderData.dLastCurrentSpeed = objSliderData.dCurrentSpeed
                
                # 「現在速度」= 「現在速度」-「加減速度」* 「最小の処理時間」
                objSliderData.dCurrentSpeed = (
                    objSliderData.dCurrentSpeed -
                    objSliderData.dAccDeceleration * dMinimumProcessingTime
                )
                
                # 0 >「現在速度」か判定：分岐範囲
                if 0 > objSliderData.dCurrentSpeed:
                    # 「現在速度」= 0
                    objSliderData.dCurrentSpeed = 0.0
            
        except Exception as e:
            print(f"{MODULE_NAME_SPEED_CONTROL}.updateCurrentSpeed: Error - {e}")
    
    # ===========================================================
    # 4.速度制御の形変更を判定
    # ===========================================================
    def changeJudgmentSpeedControlForm(
        self,
        objSliderData: Dict[int, SliderData],
        iBackwardID: int
    ) -> Dict[int, SliderData]:
        """
        速度制御の形変更を判定
        
        Args:
            objSliderData: スライダデータの辞書
            iBackwardID: 後方ID
            
        Returns:
            Dict[int, SliderData]: スライダデータの辞書
        """
        try:
            iForwardID = 0
            dTempForwardCurrentPosition = 0.0
            dTempBackwardTargetPosition = 0.0
            dForwardCollisionAvoidancePosition = 0.0
            dCollisionDetectionResult = 0.0
            
            # 「衝突判定結果」= 「衝突無」
            dCollisionDetectionResult = NO_COLLISION
            
            # 「後方ID」= 1か判定：分岐範囲
            if iBackwardID == FIRST_SLIDER_ID:
                # 「前方のID」=「最終ID」
                iForwardID = len(objSliderData)
            else:
                # 「前方のID」=「後方ID」- 1
                iForwardID = iBackwardID - FIRST_SLIDER_ID
            
            # 「前方の加減速度」=「後方の加減速度」か判定：分岐範囲
            if objSliderData[iForwardID].dAccDeceleration == objSliderData[iBackwardID].dAccDeceleration:
                # 目標位置設定
                dCollisionDetectionResult = self._collision_detecter.settingTargetPosition(
                    objSliderData[iBackwardID],
                    objSliderData[iForwardID]
                )
            else:
                # 「後方の現在位置」>「前方の現在位置」か判定：分岐範囲
                if objSliderData[iBackwardID].dCurrentPosition > objSliderData[iForwardID].dCurrentPosition:
                    # 「前方の現在位置（一時保存）」=「前方の現在位置」+「循環システム1周分の長さ」
                    dSliderSize = self._slider_data_manipulater.readSliderSize()
                    dOneLap = self._axis_data_manipulater.readOneLap(dSliderSize)
                    dTempForwardCurrentPosition = objSliderData[iForwardID].dCurrentPosition + dOneLap
                else:
                    # 「前方の現在位置（一時保存）」=「前方の現在位置」
                    dTempForwardCurrentPosition = objSliderData[iForwardID].dCurrentPosition
                
                # 「後方の現在位置」>「後方の目標位置」か判定：分岐範囲
                if objSliderData[iBackwardID].dCurrentPosition > objSliderData[iBackwardID].dTargetPosition:
                    # 「後方の目標位置（一時保存）」=「後方の目標位置」+「循環システム1周分の長さ」
                    dSliderSize = self._slider_data_manipulater.readSliderSize()
                    dOneLap = self._axis_data_manipulater.readOneLap(dSliderSize)
                    dTempBackwardTargetPosition = objSliderData[iBackwardID].dTargetPosition + dOneLap
                else:
                    # 「後方の目標位置（一時保存）」=「後方の目標位置」
                    dTempBackwardTargetPosition = objSliderData[iBackwardID].dTargetPosition
                
                # 「前方の衝突回避位置」=「後方の目標位置（一時保存）」+「スライダサイズ」
                dSliderSize = self._slider_data_manipulater.readSliderSize()
                dForwardCollisionAvoidancePosition = dTempBackwardTargetPosition + dSliderSize
                
                # 「前方の現在位置（一時保存）」<「前方の衝突回避位置」か判定：分岐範囲
                if dTempForwardCurrentPosition < dForwardCollisionAvoidancePosition:
                    # 衝突判定
                    dCollisionDetectionResult = self._collision_detecter.detectionCollision(
                        objSliderData[iBackwardID],
                        objSliderData[iForwardID]
                    )
            
            # 「衝突判定結果」=「衝突有」か判定：分岐範囲
            if dCollisionDetectionResult == COLLISION:
                # 速度制御の形を構築
                # VBA相当：Call SpeedControl.buildSpeedControlForm(objSliderData(iBackwardID))
                self.buildSpeedControlForm(objSliderData[iBackwardID])
                
                # 「衝突判定結果」= 「衝突無」
                dCollisionDetectionResult = NO_COLLISION
            
            # 返り値 =「スライダデータ」
            return objSliderData
            
        except Exception as e:
            print(f"{MODULE_NAME_SPEED_CONTROL}.changeJudgmentSpeedControlForm: Error - {e}")
            return objSliderData
