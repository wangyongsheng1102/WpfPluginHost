"""
衝突判定用プログラム
CollisionDetecter.bas（VBA）の Python 移植版

[処理概要]
　・「最短の停止位置」を検索後、その位置へ移動する過程で
   進行方向のスライダと衝突しないか確認する

[索引]
　□1.衝突判定
　□2.加速同士の衝突回避位置の算出
　□3.加速と等速の衝突回避位置の算出
　□4.加速と減速の衝突回避位置の算出
　□5.等速同士の衝突回避位置の算出
　□6.等速と減速の衝突回避位置の算出
　□7.減速同士の衝突回避位置の算出
　□8.停止と加速の衝突回避位置の算出
　□9.停止と等速の衝突回避位置の算出
　□10.停止と減速の衝突回避位置の算出
　□11.目標位置設定
"""

import math
from typing import Dict
from .. import constants
from ..constants import (
    MODULE_NAME_COLLISION_DETECTER,
    DIVISION_VALUE_COLLISION,
    MULTIPLIER_VALUE_COLLISION,
    TIME_CALCULATION_FIXED_VALUE_COLLISION,
    DISTANCE_CALCULATION_FIXED_VALUE_COLLISION,
    NO_COLLISION,
    COLLISION,
    ALLOWABLE_DIFFERENCE_RANGE,
    NONE,
    ACCELERATION,
    CONSTANT_SPEED,
    DECELERATION,
    STOP_VALUE,
    DEBUG_FLAG,
    DEBUG_ID,
    DEBUG_START_TIME,
)
from ..classes.slider_data import SliderData


class CollisionDetecter:
    """
    衝突判定クラス
    
    VBAのモジュール関数をクラスのメソッドに変換
    """
    
    def __init__(self, axis_data_manipulater, slider_data_manipulater, main_controller):
        """
        初期化
        
        Args:
            axis_data_manipulater: AxisDataManipulaterインスタンス
            slider_data_manipulater: SliderDataManipulaterインスタンス
            main_controller: MainControllerインスタンス（readCurrentTime用）
        """
        self._axis_data_manipulater = axis_data_manipulater
        self._slider_data_manipulater = slider_data_manipulater
        self._main_controller = main_controller
    
    # ===========================================================
    # 1.衝突判定
    # ===========================================================
    def detectionCollision(
        self,
        objBackwardSliderData: SliderData,
        objForwardSliderData: SliderData
    ) -> float:
        """
        衝突判定
        
        Args:
            objBackwardSliderData: 後方スライダデータオブジェクト
            objForwardSliderData: 前方スライダデータオブジェクト
            
        Returns:
            float: 衝突判定結果（NO_COLLISION(-1) または COLLISION(1)）
        """
        try:
            dCollisionDetectionResult = 0.0
            dForwardCurrentPosition = 0.0
            dForwardCollisionBoundaryPosition = 0.0
            dBackwardCollisionBoundaryPosition = 0.0
            dBackwardCollisionAvoidancePosition = 0.0
            dTargetPositionDifference = 0.0
            dBackwardAvoidanceDifference = 0.0
            dTempBackwardShortestStopPosition = 0.0
            dTempForwardTargetPosition = 0.0
            dForBackwardCollisionBoundaryPositionDifference = 0.0
            
            # 「後方の衝突回避位置」= -1
            dBackwardCollisionAvoidancePosition = NO_COLLISION
            
            # 「衝突判定結果」= 「衝突有」
            dCollisionDetectionResult = COLLISION
            
            # VBA相当：With objBackwardSliderData ... End With
            # Python実装：直接アクセス
            
            # 「後方の現在位置」>「前方の現在位置」か判定
            if objBackwardSliderData.dCurrentPosition > objForwardSliderData.dCurrentPosition:
                # 「前方の現在位置（一時保存）」=　「前方の現在位置」+「循環システム1周分の長さ」
                dSliderSize = self._slider_data_manipulater.readSliderSize()
                dOneLap = self._axis_data_manipulater.readOneLap(dSliderSize)
                dForwardCurrentPosition = objForwardSliderData.dCurrentPosition + dOneLap
            else:
                # 「前方の現在位置（一時保存）」=「前方の現在位置」
                dForwardCurrentPosition = objForwardSliderData.dCurrentPosition
            
            # 「前方の衝突境界位置」=「前方の現在位置（一時保存）」- ( 「スライダサイズ」/2 )
            dSliderSize = self._slider_data_manipulater.readSliderSize()
            dForwardCollisionBoundaryPosition = dForwardCurrentPosition - (dSliderSize / DIVISION_VALUE_COLLISION)
            
            # 「後方の衝突境界位置」=「後方の現在位置」+ ( 「スライダサイズ」/2 )
            dBackwardCollisionBoundaryPosition = objBackwardSliderData.dCurrentPosition + (dSliderSize / DIVISION_VALUE_COLLISION)
            
            # 「前後の衝突境界位置差分」=「前方の衝突境界位置」-「後方の衝突境界位置」
            dForBackwardCollisionBoundaryPositionDifference = dForwardCollisionBoundaryPosition - dBackwardCollisionBoundaryPosition
            
            # 0 >=「前後の衝突境界位置差分」か判定：分岐範囲
            if 0 >= dForBackwardCollisionBoundaryPositionDifference:
                # 「後方の衝突回避位置」=「現在位置」
                dBackwardCollisionAvoidancePosition = objBackwardSliderData.dCurrentPosition
            
            # 「前方の衝突回避位置」=「後方の衝突回避位置」And 「前方の加速状態」=「無」か判定
            elif (dForwardCollisionBoundaryPosition == dBackwardCollisionBoundaryPosition and
                  objForwardSliderData.iAccelerationState == NONE):
                # 「後方の衝突回避位置」=「現在位置」
                dBackwardCollisionAvoidancePosition = objBackwardSliderData.dCurrentPosition
            
            # 「前方の加速状態」=「加速」And「後方の加速状態」=「加速」か判定
            elif (objForwardSliderData.iAccelerationState == ACCELERATION and
                  objBackwardSliderData.iAccelerationState == ACCELERATION):
                # 加速同士の衝突回避位置の算出
                dBackwardCollisionAvoidancePosition = self.calculationBetweenAccelerationAvoidancePosition(
                    objForwardSliderData,
                    objBackwardSliderData,
                    dForwardCollisionBoundaryPosition,
                    dBackwardCollisionBoundaryPosition
                )
            
            # 「前方の加速状態」=「加速」And「後方の加速状態」=「等速」か判定
            elif (objForwardSliderData.iAccelerationState == ACCELERATION and
                  objBackwardSliderData.iAccelerationState == CONSTANT_SPEED):
                # 加速と等速の衝突回避位置の算出
                dBackwardCollisionAvoidancePosition = self.calculationAccelerationConstantSpeedAvoidancePosition(
                    objForwardSliderData,
                    objBackwardSliderData,
                    dForwardCollisionBoundaryPosition,
                    dBackwardCollisionBoundaryPosition,
                    CONSTANT_SPEED
                )
            
            # 「前方の加速状態」=「加速」And「後方の加速状態」=「減速」か判定
            elif (objForwardSliderData.iAccelerationState == ACCELERATION and
                  objBackwardSliderData.iAccelerationState == DECELERATION):
                # 加速と減速の衝突回避位置の算出
                dBackwardCollisionAvoidancePosition = self.calculationAccelerationDecelerationAvoidancePosition(
                    objForwardSliderData,
                    objBackwardSliderData,
                    dForwardCollisionBoundaryPosition,
                    dBackwardCollisionBoundaryPosition,
                    DECELERATION
                )
            
            # 「前方の加速状態」=「等速」And「後方の加速状態」=「加速」か判定
            elif (objForwardSliderData.iAccelerationState == CONSTANT_SPEED and
                  objBackwardSliderData.iAccelerationState == ACCELERATION):
                # 加速と等速の衝突回避位置の算出
                dBackwardCollisionAvoidancePosition = self.calculationAccelerationConstantSpeedAvoidancePosition(
                    objBackwardSliderData,
                    objForwardSliderData,
                    dBackwardCollisionBoundaryPosition,
                    dForwardCollisionBoundaryPosition,
                    ACCELERATION
                )
            
            # 「前方の加速状態」=「等速」And「後方の加速状態」=「等速」か判定
            elif (objForwardSliderData.iAccelerationState == CONSTANT_SPEED and
                  objBackwardSliderData.iAccelerationState == CONSTANT_SPEED):
                # 等速同士の衝突回避位置の算出
                dBackwardCollisionAvoidancePosition = self.calculationBetweenConstantSpeedAvoidancePosition(
                    objForwardSliderData,
                    objBackwardSliderData,
                    dForwardCollisionBoundaryPosition,
                    dBackwardCollisionBoundaryPosition
                )
            
            # 「前方の加速状態」=「等速」And「後方の加速状態」=「減速」か判定
            elif (objForwardSliderData.iAccelerationState == CONSTANT_SPEED and
                  objBackwardSliderData.iAccelerationState == DECELERATION):
                # 等速と減速の衝突回避位置の算出
                dBackwardCollisionAvoidancePosition = self.calculationConstantSpeedDecelerationAvoidancePosition(
                    objForwardSliderData,
                    objBackwardSliderData,
                    dForwardCollisionBoundaryPosition,
                    dBackwardCollisionBoundaryPosition,
                    DECELERATION
                )
            
            # 「前方の加速状態」=「減速」And「後方の加速状態」=「加速」か判定
            elif (objForwardSliderData.iAccelerationState == DECELERATION and
                  objBackwardSliderData.iAccelerationState == ACCELERATION):
                # 加速と減速の衝突回避位置の算出
                dBackwardCollisionAvoidancePosition = self.calculationAccelerationDecelerationAvoidancePosition(
                    objBackwardSliderData,
                    objForwardSliderData,
                    dBackwardCollisionBoundaryPosition,
                    dForwardCollisionBoundaryPosition,
                    ACCELERATION
                )
            
            # 「前方の加速状態」=「減速」And「後方の加速状態」=「等速」か判定
            elif (objForwardSliderData.iAccelerationState == DECELERATION and
                  objBackwardSliderData.iAccelerationState == CONSTANT_SPEED):
                # 等速と減速の衝突回避位置の算出
                dBackwardCollisionAvoidancePosition = self.calculationConstantSpeedDecelerationAvoidancePosition(
                    objBackwardSliderData,
                    objForwardSliderData,
                    dBackwardCollisionBoundaryPosition,
                    dForwardCollisionBoundaryPosition,
                    CONSTANT_SPEED
                )
            
            # 「前方の加速状態」=「減速」And「後方の加速状態」=「減速」か判定
            elif (objForwardSliderData.iAccelerationState == DECELERATION and
                  objBackwardSliderData.iAccelerationState == DECELERATION):
                # 減速同士の衝突回避位置の算出
                dBackwardCollisionAvoidancePosition = self.calculationBetweenDecelerationAvoidancePosition(
                    objForwardSliderData,
                    objBackwardSliderData,
                    dForwardCollisionBoundaryPosition,
                    dBackwardCollisionBoundaryPosition
                )
            
            # 「前方の加速状態」=「無」And「後方の加速状態」=「加速」か判定
            elif (objForwardSliderData.iAccelerationState == NONE and
                  objBackwardSliderData.iAccelerationState == ACCELERATION):
                # 停止と加速の衝突回避位置の算出
                dBackwardCollisionAvoidancePosition = self.calculationStopAccelerationAvoidancePosition(
                    objForwardSliderData,
                    objBackwardSliderData,
                    dForwardCollisionBoundaryPosition,
                    dBackwardCollisionBoundaryPosition
                )
            
            # 「前方の加速状態」=「無」And「後方の加速状態」=「等速」か判定
            elif (objForwardSliderData.iAccelerationState == NONE and
                  objBackwardSliderData.iAccelerationState == CONSTANT_SPEED):
                # 停止と等速の衝突回避位置の算出
                dBackwardCollisionAvoidancePosition = self.calculationStopConstantSpeedAvoidancePosition(
                    objForwardSliderData,
                    objBackwardSliderData,
                    dForwardCollisionBoundaryPosition,
                    dBackwardCollisionBoundaryPosition
                )
            
            # 「前方の加速状態」=「無」And「後方の加速状態」=「減速」か判定
            elif (objForwardSliderData.iAccelerationState == NONE and
                  objBackwardSliderData.iAccelerationState == DECELERATION):
                # 停止と減速の衝突回避位置の算出
                dBackwardCollisionAvoidancePosition = self.calculationStopDecelerationAvoidancePosition(
                    objForwardSliderData,
                    objBackwardSliderData,
                    dForwardCollisionBoundaryPosition,
                    dBackwardCollisionBoundaryPosition
                )
            
            # 「後方の衝突回避位置」= -1か判定：分岐範囲
            if dBackwardCollisionAvoidancePosition == NO_COLLISION:
                # 「衝突判定結果」= 「衝突無」
                dCollisionDetectionResult = NO_COLLISION
            else:
                # 「後方の最短停止位置」 = 0か判定：分岐範囲
                if objBackwardSliderData.dShortestStopPosition == 0:
                    # 「後方の最短停止位置（一時保存）」=  「循環システム1周分の長さ」
                    dSliderSize = self._slider_data_manipulater.readSliderSize()
                    dOneLap = self._axis_data_manipulater.readOneLap(dSliderSize)
                    dTempBackwardShortestStopPosition = dOneLap
                else:
                    # 「後方の最短停止位置（一時保存）」= 「後方の最短停止位置」
                    dTempBackwardShortestStopPosition = objBackwardSliderData.dShortestStopPosition
                
                # 「後方の衝突回避位置」=＞「後方の最短停止位置（一時保存）」か判定：分岐範囲
                if dBackwardCollisionAvoidancePosition >= dTempBackwardShortestStopPosition:
                    # 「後方の目標位置」=「後方の最短停止位置」
                    objBackwardSliderData.dTargetPosition = objBackwardSliderData.dShortestStopPosition
                    
                    # 「衝突判定結果」= 「衝突無」
                    dCollisionDetectionResult = NO_COLLISION
                else:
                    # 「後方の回避差分」=「後方の衝突回避位置」と「後方の現在位置」の差分
                    dBackwardAvoidanceDifference = abs(dBackwardCollisionAvoidancePosition - objBackwardSliderData.dCurrentPosition)
                    
                    # 「後方の回避差分」 < 許容差分か判定：分岐範囲
                    if dBackwardAvoidanceDifference < ALLOWABLE_DIFFERENCE_RANGE:
                        # 「後方の衝突回避位置」=「後方の現在位置」
                        dBackwardCollisionAvoidancePosition = objBackwardSliderData.dCurrentPosition
                    
                    # 「後方の衝突回避位置」=>「後方の現在位置」か判定：分岐範囲
                    if dBackwardCollisionAvoidancePosition >= objBackwardSliderData.dCurrentPosition:
                        # 「後方の目標位置」=「後方の衝突回避位置」
                        objBackwardSliderData.dTargetPosition = dBackwardCollisionAvoidancePosition
                        
                        # 「衝突判定結果」= 「衝突有」
                        dCollisionDetectionResult = COLLISION
                    else:
                        # 「後方の目標位置」=「後方の現在位置」
                        objBackwardSliderData.dTargetPosition = objBackwardSliderData.dCurrentPosition
                        
                        # 「衝突判定結果」= 「衝突有」
                        dCollisionDetectionResult = COLLISION
            
            # 「後方の目標位置差分」=「後方の現在位置」と「後方の目標位置」の差分
            dTargetPositionDifference = abs(objBackwardSliderData.dCurrentPosition - objBackwardSliderData.dTargetPosition)
            
            # 「後方の目標位置差分」 < 許容差分か判定
            if dTargetPositionDifference < ALLOWABLE_DIFFERENCE_RANGE:
                # 「後方の現在位置」=「後方の目標位置」
                objBackwardSliderData.dCurrentPosition = objBackwardSliderData.dTargetPosition
            
            # 返り値=「衝突判定結果」
            return dCollisionDetectionResult
            
        except Exception as e:
            print(f"{MODULE_NAME_COLLISION_DETECTER}.detectionCollision: Error - {e}")
            return NO_COLLISION
    
    # ===========================================================
    # 2.加速同士の衝突回避位置の算出
    # ===========================================================
    def calculationBetweenAccelerationAvoidancePosition(
        self,
        objForwardSliderData: SliderData,
        objBackwardSliderData: SliderData,
        dForwardCollisionBoundaryPosition: float,
        dBackwardCollisionBoundaryPosition: float
    ) -> float:
        """
        加速同士の衝突回避位置の算出
        
        Args:
            objForwardSliderData: 前方スライダデータオブジェクト
            objBackwardSliderData: 後方スライダデータオブジェクト
            dForwardCollisionBoundaryPosition: 前方衝突境界位置[mm]
            dBackwardCollisionBoundaryPosition: 後方衝突境界位置[mm]
            
        Returns:
            float: 後方の衝突回避位置[mm]（NO_COLLISION(-1)の場合は衝突無）
        """
        try:
            dCollisionBoundaryMatchingPositionTimeA = 0.0
            dCollisionBoundaryMatchingPositionA = 0.0
            dCollisionBoundaryMatchingPositionTimeB = 0.0
            dCollisionBoundaryMatchingPositionB = 0.0
            dCollisionBoundaryMatchingPosition = 0.0
            dBackwardCollisionAvoidancePosition = 0.0
            dSqrArgument = 0.0
            
            # VBA相当：With objBackwardSliderData ... End With
            # Python実装：直接アクセス
            
            # 「前方の加減速度」=「後方の加減速度」か判定：分岐範囲
            if objForwardSliderData.dAccDeceleration == objBackwardSliderData.dAccDeceleration:
                # 「後方の衝突回避位置」= -1
                dBackwardCollisionAvoidancePosition = NO_COLLISION
                
                # 返り値=「後方の衝突回避位置」
                return dBackwardCollisionAvoidancePosition
            
            # 「Sqr関数の引数」の算出：
            # ( (「前方の現在速度」-「後方の現在速度」)^2
            # -2 * (「前方の加減速度」-「後方の加減速度」)
            # * (「前方の衝突境界位置」-「後方の衝突境界位置」)
            dSqrArgument = (
                (objForwardSliderData.dCurrentSpeed - objBackwardSliderData.dCurrentSpeed) ** MULTIPLIER_VALUE_COLLISION -
                TIME_CALCULATION_FIXED_VALUE_COLLISION * (objForwardSliderData.dAccDeceleration - objBackwardSliderData.dAccDeceleration) *
                (dForwardCollisionBoundaryPosition - dBackwardCollisionBoundaryPosition)
            )
            
            # 0 >「Sqr関数の引数」か判定：分岐範囲
            if 0 > dSqrArgument:
                # 「後方の衝突回避位置」= -1
                dBackwardCollisionAvoidancePosition = NO_COLLISION
                
                # 返り値=「後方の衝突回避位置」
                return dBackwardCollisionAvoidancePosition
            
            # 「衝突境界一致位置時間(ta)」の算出
            # ={ - (「前方の現在速度」-「後方の現在速度」)
            # + √ [(「前方の現在速度」-「後方の現在速度」)^2
            # -2 * (「前方の加減速度」-「後方の加減速度」)
            # * (「前方の衝突境界位置」-「後方の衝突境界位置」]}
            # / (「前方の加減速度」-「後方の加減速度」)
            dCollisionBoundaryMatchingPositionTimeA = (
                (-(objForwardSliderData.dCurrentSpeed - objBackwardSliderData.dCurrentSpeed) +
                 math.sqrt((objForwardSliderData.dCurrentSpeed - objBackwardSliderData.dCurrentSpeed) ** MULTIPLIER_VALUE_COLLISION -
                          TIME_CALCULATION_FIXED_VALUE_COLLISION * (objForwardSliderData.dAccDeceleration - objBackwardSliderData.dAccDeceleration) *
                          (dForwardCollisionBoundaryPosition - dBackwardCollisionBoundaryPosition))) /
                (objForwardSliderData.dAccDeceleration - objBackwardSliderData.dAccDeceleration)
            )
            
            # 「衝突境界一致時間(ta)」> 0か判定：分岐範囲
            if dCollisionBoundaryMatchingPositionTimeA > 0:
                # 「衝突境界一致位置(Pa)」の算出
                # =「後方の現在速度」*「衝突境界一致位置時間(ta)」
                # + 0.5 *「後方の加減速度」*「衝突境界一致時間(ta)」^2
                # +「後方の衝突境界位置」
                dCollisionBoundaryMatchingPositionA = (
                    objBackwardSliderData.dCurrentSpeed * dCollisionBoundaryMatchingPositionTimeA +
                    DISTANCE_CALCULATION_FIXED_VALUE_COLLISION * objBackwardSliderData.dAccDeceleration *
                    dCollisionBoundaryMatchingPositionTimeA ** MULTIPLIER_VALUE_COLLISION +
                    dBackwardCollisionBoundaryPosition
                )
            else:
                # 「衝突境界一致位置(Pa)」= -1
                dCollisionBoundaryMatchingPositionA = NO_COLLISION
            
            # 「衝突境界一致位置時間(tb)」の算出
            # ={ - (「前方の現在速度」-「後方の現在速度」)
            # - √ [(「前方の現在速度」-「後方の現在速度」)^2
            # -2 * (「前方の加減速度」-「後方の加減速度」)
            # * (「前方の衝突境界位置」-「後方の衝突境界位置」]}
            # / (「前方の加減速度」-「後方の加減速度」)
            dCollisionBoundaryMatchingPositionTimeB = (
                (-(objForwardSliderData.dCurrentSpeed - objBackwardSliderData.dCurrentSpeed) -
                 math.sqrt((objForwardSliderData.dCurrentSpeed - objBackwardSliderData.dCurrentSpeed) ** MULTIPLIER_VALUE_COLLISION -
                          TIME_CALCULATION_FIXED_VALUE_COLLISION * (objForwardSliderData.dAccDeceleration - objBackwardSliderData.dAccDeceleration) *
                          (dForwardCollisionBoundaryPosition - dBackwardCollisionBoundaryPosition))) /
                (objForwardSliderData.dAccDeceleration - objBackwardSliderData.dAccDeceleration)
            )
            
            # 「衝突境界一致時間(tb)」> 0か判定：分岐範囲
            if dCollisionBoundaryMatchingPositionTimeB > 0:
                # 「衝突境界一致位置(Pb)」の算出
                # =「後方の現在速度」*「衝突境界一致位置時間(tb)」
                # + 0.5 *「後方の加減速度」*「衝突境界一致時間(tb)」^2
                # +「後方の衝突境界位置」
                dCollisionBoundaryMatchingPositionB = (
                    objBackwardSliderData.dCurrentSpeed * dCollisionBoundaryMatchingPositionTimeB +
                    DISTANCE_CALCULATION_FIXED_VALUE_COLLISION * objBackwardSliderData.dAccDeceleration *
                    dCollisionBoundaryMatchingPositionTimeB ** MULTIPLIER_VALUE_COLLISION +
                    dBackwardCollisionBoundaryPosition
                )
            else:
                # 「衝突境界一致位置(Pb)」= -1
                dCollisionBoundaryMatchingPositionB = NO_COLLISION
            
            # 「衝突境界一致位置(Pa)」= -1 かつ「衝突境界一致位置(Pb)」= -1 ：分岐範囲
            if dCollisionBoundaryMatchingPositionA == NO_COLLISION and dCollisionBoundaryMatchingPositionB == NO_COLLISION:
                # 「後方の衝突回避位置」=「後方の現在位置」
                dBackwardCollisionAvoidancePosition = objBackwardSliderData.dCurrentPosition
            else:
                # 「衝突境界一致位置(Pa)」> 「衝突境界一致位置(Pb)」か判定：分岐範囲
                if dCollisionBoundaryMatchingPositionA > dCollisionBoundaryMatchingPositionB:
                    # 0 >= 「衝突境界一致位置(Pb)」か判定：分岐範囲
                    if 0 >= dCollisionBoundaryMatchingPositionB:
                        # 「衝突境界一致位置」= 「衝突境界一致位置(Pa)」
                        dCollisionBoundaryMatchingPosition = dCollisionBoundaryMatchingPositionA
                    else:
                        # 「衝突境界一致位置」= 「衝突境界一致位置(Pb)」
                        dCollisionBoundaryMatchingPosition = dCollisionBoundaryMatchingPositionB
                else:
                    # 0 >= 「衝突境界一致位置(Pa)」か判定：分岐範囲
                    if 0 >= dCollisionBoundaryMatchingPositionA:
                        # 「衝突境界一致位置」= 「衝突境界一致位置(Pb)」
                        dCollisionBoundaryMatchingPosition = dCollisionBoundaryMatchingPositionB
                    else:
                        # 「衝突境界一致位置」= 「衝突境界一致位置(Pa)」
                        dCollisionBoundaryMatchingPosition = dCollisionBoundaryMatchingPositionA
                
                # 「後方の衝突回避位置」=「衝突境界一致位置」-（ 「スライダサイズ」/ 2 ）
                dSliderSize = self._slider_data_manipulater.readSliderSize()
                dBackwardCollisionAvoidancePosition = dCollisionBoundaryMatchingPosition - (dSliderSize / DIVISION_VALUE_COLLISION)
                
                # 「後方の衝突回避位置」>=「後方の目標位置」か判定
                if dBackwardCollisionAvoidancePosition >= objBackwardSliderData.dTargetPosition:
                    # 「後方の衝突回避位置」= -1
                    dBackwardCollisionAvoidancePosition = NO_COLLISION
            
            # 返り値=「後方の衝突回避位置」
            return dBackwardCollisionAvoidancePosition
            
        except Exception as e:
            print(f"{MODULE_NAME_COLLISION_DETECTER}.calculationBetweenAccelerationAvoidancePosition: Error - {e}")
            return NO_COLLISION
    
    # ===========================================================
    # 3.加速と等速の衝突回避位置の算出
    # ===========================================================
    def calculationAccelerationConstantSpeedAvoidancePosition(
        self,
        objAccelerationSliderData: SliderData,
        objConstantSpeedSliderData: SliderData,
        dAccelerationCollisionBoundaryPosition: float,
        dConstantSpeedCollisionBoundaryPosition: float,
        iBackwardAccelerationState: int
    ) -> float:
        """
        加速と等速の衝突回避位置の算出
        
        Args:
            objAccelerationSliderData: 加速中スライダデータオブジェクト
            objConstantSpeedSliderData: 等速中スライダデータオブジェクト
            dAccelerationCollisionBoundaryPosition: 加速中衝突境界位置[mm]
            dConstantSpeedCollisionBoundaryPosition: 等速中衝突境界位置[mm]
            iBackwardAccelerationState: 後方の加速状態
            
        Returns:
            float: 後方の衝突回避位置[mm]（NO_COLLISION(-1)の場合は衝突無）
        """
        try:
            dCollisionBoundaryMatchingPositionTimeA = 0.0
            dCollisionBoundaryMatchingPositionA = 0.0
            dCollisionBoundaryMatchingPositionTimeB = 0.0
            dCollisionBoundaryMatchingPositionB = 0.0
            dCollisionBoundaryMatchingPosition = 0.0
            dBackwardCollisionAvoidancePosition = 0.0
            dSqrArgument = 0.0
            
            # VBA相当：With objConstantSpeedSliderData ... End With
            # Python実装：直接アクセス
            
            # 「Sqr関数の引数」の算出
            # (「加速中スライダの現在速度」-「等速中スライダの現在速度」)^2
            # -2*「加速中スライダの加減速度」
            # *(「加速中スライダの衝突境界位置」-「等速中スライダの衝突境界位置」)
            # 注意：VBA コードに誤りがある可能性（本来は現在速度を用いるべき）
            # 補足：VBA 856 行付近は現在位置を参照しているが、VBA を踏襲して現在位置を使用
            dSqrArgument = (
                (objAccelerationSliderData.dCurrentSpeed - objConstantSpeedSliderData.dCurrentSpeed) ** MULTIPLIER_VALUE_COLLISION -
                TIME_CALCULATION_FIXED_VALUE_COLLISION * objAccelerationSliderData.dAccDeceleration *
                (dAccelerationCollisionBoundaryPosition - dConstantSpeedCollisionBoundaryPosition)
            )
            
            # 0 >「Sqr関数の引数」か判定：分岐範囲
            if 0 > dSqrArgument:
                # 「後方の衝突回避位置」= -1
                dBackwardCollisionAvoidancePosition = NO_COLLISION
                
                # 返り値=「後方の衝突回避位置」
                return dBackwardCollisionAvoidancePosition
            
            # 「衝突境界一致位置時間(ta)」の算出
            # ={-(「加速中スライダの現在速度」-「等速中スライダの現在速度」)
            # +√[(「加速中スライダの現在速度」-「等速中スライダの現在速度」)^2
            # -2*「加速中スライダの加減速度」
            # *(「加速中スライダの衝突境界位置」-「等速中スライダの衝突境界位置」)]}
            # /「加速中スライダの加減速度」
            dCollisionBoundaryMatchingPositionTimeA = (
                (-(objAccelerationSliderData.dCurrentSpeed - objConstantSpeedSliderData.dCurrentSpeed) +
                 math.sqrt((objAccelerationSliderData.dCurrentSpeed - objConstantSpeedSliderData.dCurrentSpeed) ** MULTIPLIER_VALUE_COLLISION -
                          TIME_CALCULATION_FIXED_VALUE_COLLISION * objAccelerationSliderData.dAccDeceleration *
                          (dAccelerationCollisionBoundaryPosition - dConstantSpeedCollisionBoundaryPosition))) /
                objAccelerationSliderData.dAccDeceleration
            )
            
            # 「衝突境界一致時間(ta)」> 0か判定：分岐範囲
            if dCollisionBoundaryMatchingPositionTimeA > 0:
                # 「衝突境界一致位置(Pa)」の算出
                # =「等速中スライダの現在速度」*「衝突境界一致時間(ta)」+「等速中スライダの衝突境界位置」
                dCollisionBoundaryMatchingPositionA = (
                    objConstantSpeedSliderData.dCurrentSpeed * dCollisionBoundaryMatchingPositionTimeA +
                    dConstantSpeedCollisionBoundaryPosition
                )
            else:
                # 「後方の加速状態」=「加速」か判定：分岐範囲
                if iBackwardAccelerationState == ACCELERATION:
                    # 「後方の衝突回避位置」=「加速中スライダの現在位置」
                    dBackwardCollisionAvoidancePosition = objAccelerationSliderData.dCurrentPosition
                    
                    # 返り値=「後方の衝突回避位置」
                    return dBackwardCollisionAvoidancePosition
                else:
                    # 「後方の衝突回避位置」=「等速中スライダの現在位置」
                    dBackwardCollisionAvoidancePosition = objConstantSpeedSliderData.dCurrentPosition
                    
                    # 返り値=「後方の衝突回避位置」
                    return dBackwardCollisionAvoidancePosition
            
            # 「衝突境界一致位置時間(tb)」の算出
            # ={-(「加速中スライダの現在速度」-「等速中スライダの現在速度」)
            # -√[(「加速中スライダの現在速度」-「等速中スライダの現在速度」)^2
            # -2*「加速中スライダの加減速度」*(「加速中スライダの衝突境界位置」-「等速中スライダの衝突境界位置」)]}
            # /「加速中スライダの加減速度」
            dCollisionBoundaryMatchingPositionTimeB = (
                (-(objAccelerationSliderData.dCurrentSpeed - objConstantSpeedSliderData.dCurrentSpeed) -
                 math.sqrt((objAccelerationSliderData.dCurrentSpeed - objConstantSpeedSliderData.dCurrentSpeed) ** MULTIPLIER_VALUE_COLLISION -
                          TIME_CALCULATION_FIXED_VALUE_COLLISION * objAccelerationSliderData.dAccDeceleration *
                          (dAccelerationCollisionBoundaryPosition - dConstantSpeedCollisionBoundaryPosition))) /
                objAccelerationSliderData.dAccDeceleration
            )
            
            # 「衝突境界一致時間(tb)」> 0か判定：分岐範囲
            if dCollisionBoundaryMatchingPositionTimeB > 0:
                # 「衝突境界一致位置(Pb)」の算出
                # =「等速中スライダの現在速度」*「衝突境界一致時間(tb)」+「等速中スライダの衝突境界位置」
                dCollisionBoundaryMatchingPositionB = (
                    objConstantSpeedSliderData.dCurrentSpeed * dCollisionBoundaryMatchingPositionTimeB +
                    dConstantSpeedCollisionBoundaryPosition
                )
            else:
                # 「後方の加速状態」=「加速」か判定：分岐範囲
                if iBackwardAccelerationState == ACCELERATION:
                    # 「後方の衝突回避位置」=「加速中スライダの現在位置」
                    dBackwardCollisionAvoidancePosition = objAccelerationSliderData.dCurrentPosition
                    
                    # 返り値=「後方の衝突回避位置」
                    return dBackwardCollisionAvoidancePosition
                else:
                    # 「後方の衝突回避位置」=「等速中スライダの現在位置」
                    dBackwardCollisionAvoidancePosition = objConstantSpeedSliderData.dCurrentPosition
                    
                    # 返り値=「後方の衝突回避位置」
                    return dBackwardCollisionAvoidancePosition
            
            # 「衝突境界一致位置(Pa)」= -1 かつ「衝突境界一致位置(Pb)」= -1 か判定：分岐範囲
            if dCollisionBoundaryMatchingPositionA == NO_COLLISION and dCollisionBoundaryMatchingPositionB == NO_COLLISION:
                # 「後方の衝突回避位置」= -1
                dBackwardCollisionAvoidancePosition = NO_COLLISION
            else:
                # 「衝突境界一致位置(Pa)」> 「衝突境界一致位置(Pb)」か判定：分岐範囲
                if dCollisionBoundaryMatchingPositionA > dCollisionBoundaryMatchingPositionB:
                    # 0 >= 「衝突境界一致位置(Pb)」か判定：分岐範囲
                    if 0 >= dCollisionBoundaryMatchingPositionB:
                        # 「衝突境界一致位置」= 「衝突境界一致位置(Pa)」
                        dCollisionBoundaryMatchingPosition = dCollisionBoundaryMatchingPositionA
                    else:
                        # 「衝突境界一致位置」= 「衝突境界一致位置(Pb)」
                        dCollisionBoundaryMatchingPosition = dCollisionBoundaryMatchingPositionB
                else:
                    # 0 >= 「衝突境界一致位置(Pa)」:分岐範囲
                    if 0 >= dCollisionBoundaryMatchingPositionA:
                        # 「衝突境界一致位置」= 「衝突境界一致位置(Pb)」
                        dCollisionBoundaryMatchingPosition = dCollisionBoundaryMatchingPositionB
                    else:
                        # 「衝突境界一致位置」= 「衝突境界一致位置(Pa)」
                        dCollisionBoundaryMatchingPosition = dCollisionBoundaryMatchingPositionA
                
                # 「後方の衝突回避位置」=「衝突境界一致位置」-（ 「スライダサイズ」/ 2 ）
                dSliderSize = self._slider_data_manipulater.readSliderSize()
                dBackwardCollisionAvoidancePosition = dCollisionBoundaryMatchingPosition - (dSliderSize / DIVISION_VALUE_COLLISION)
                
                # 「後方の衝突回避位置」>=「循環システム1周分の長さ」か判定:分岐範囲
                dOneLap = self._axis_data_manipulater.readOneLap(dSliderSize)
                if dBackwardCollisionAvoidancePosition >= dOneLap:
                    # 「後方の衝突回避位置」= 「後方の衝突回避位置」-「循環システム1周分の長さ」
                    dBackwardCollisionAvoidancePosition = dBackwardCollisionAvoidancePosition - dOneLap
                
                # 「後方の加速状態」=「加速」か判定
                if iBackwardAccelerationState == ACCELERATION:
                    # 「後方の衝突回避位置」>=「加速中スライダの目標位置」
                    if dBackwardCollisionAvoidancePosition >= objAccelerationSliderData.dTargetPosition:
                        # 「後方の衝突回避位置」= -1
                        dBackwardCollisionAvoidancePosition = NO_COLLISION
                else:
                    # 「後方の衝突回避位置」>=「等速中スライダの目標位置」
                    if dBackwardCollisionAvoidancePosition >= objAccelerationSliderData.dTargetPosition:
                        # 「後方の衝突回避位置」= -1
                        dBackwardCollisionAvoidancePosition = NO_COLLISION
            
            # 返り値=「後方の衝突回避位置」
            return dBackwardCollisionAvoidancePosition
            
        except Exception as e:
            print(f"{MODULE_NAME_COLLISION_DETECTER}.calculationAccelerationConstantSpeedAvoidancePosition: Error - {e}")
            return NO_COLLISION
    
    # ===========================================================
    # 4.加速と減速の衝突回避位置の算出
    # ===========================================================
    def calculationAccelerationDecelerationAvoidancePosition(
        self,
        objAccelerationSliderData: SliderData,
        objDecelerationSliderData: SliderData,
        dAccelerationCollisionBoundaryPosition: float,
        dDecelerationCollisionBoundaryPosition: float,
        iBackwardAccelerationState: int
    ) -> float:
        """
        加速と減速の衝突回避位置の算出
        
        Args:
            objAccelerationSliderData: 加速中スライダデータオブジェクト
            objDecelerationSliderData: 減速中スライダデータオブジェクト
            dAccelerationCollisionBoundaryPosition: 加速中衝突境界位置[mm]
            dDecelerationCollisionBoundaryPosition: 減速中衝突境界位置[mm]
            iBackwardAccelerationState: 後方の加速状態
            
        Returns:
            float: 後方の衝突回避位置[mm]（NO_COLLISION(-1)の場合は衝突無）
        """
        try:
            dCollisionBoundaryMatchingPositionTimeA = 0.0
            dCollisionBoundaryMatchingPositionA = 0.0
            dCollisionBoundaryMatchingPositionTimeB = 0.0
            dCollisionBoundaryMatchingPositionB = 0.0
            dCollisionBoundaryMatchingPosition = 0.0
            dBackwardCollisionAvoidancePosition = 0.0
            dSqrArgument = 0.0
            
            # VBA相当：With objAccelerationSliderData ... End With
            # Python実装：直接アクセス
            
            # 「加速中スライダの加減速度」= 0 かつ「減速中スライダの加減速度」= 0 か判定：分岐範囲
            if objAccelerationSliderData.dAccDeceleration == 0 and objDecelerationSliderData.dAccDeceleration == 0:
                # 「後方の衝突回避位置」= -1
                dBackwardCollisionAvoidancePosition = NO_COLLISION
                
                # 返り値=「後方の衝突回避位置」
                return dBackwardCollisionAvoidancePosition
            
            # 「Sqr関数の引数」の算出：
            # =(「加速中スライダの現在速度」-「減速中スライダの現在速度)^2
            # '-2*(「加速中スライダの加減速度」+「減速中スライダの加減速度」)
            # '*(「加速中スライダの衝突境界位置」-「減速中スライダの衝突境界位置」)
            dSqrArgument = (
                (objAccelerationSliderData.dCurrentSpeed - objDecelerationSliderData.dCurrentSpeed) ** MULTIPLIER_VALUE_COLLISION -
                TIME_CALCULATION_FIXED_VALUE_COLLISION * (objAccelerationSliderData.dAccDeceleration + objDecelerationSliderData.dAccDeceleration) *
                (dAccelerationCollisionBoundaryPosition - dDecelerationCollisionBoundaryPosition)
            )
            
            # 0 >「Sqr関数の引数」か判定：分岐範囲
            if 0 > dSqrArgument:
                # 「後方の衝突回避位置」= -1
                dBackwardCollisionAvoidancePosition = NO_COLLISION
                
                # 返り値=「後方の衝突回避位置」
                return dBackwardCollisionAvoidancePosition
            
            # 「衝突境界一致位置時間(ta)」の算出
            # ={-(「加速中スライダの現在速度」 - 「減速中スライダの現在速度」)
            # '+√[(「加速中スライダの現在速度」-「減速中スライダの現在速度)^2
            # '-2*(「加速中スライダの加減速度」+「減速中スライダの加減速度」)
            # '*(「加速中スライダの衝突境界位置」-「減速中スライダの衝突境界位置」)]}
            # '/(加速中スライダの加減速度」+「減速中スライダの加減速度」)
            dCollisionBoundaryMatchingPositionTimeA = (
                (-(objAccelerationSliderData.dCurrentSpeed - objDecelerationSliderData.dCurrentSpeed) +
                 math.sqrt((objAccelerationSliderData.dCurrentSpeed - objDecelerationSliderData.dCurrentSpeed) ** MULTIPLIER_VALUE_COLLISION -
                          TIME_CALCULATION_FIXED_VALUE_COLLISION * (objAccelerationSliderData.dAccDeceleration + objDecelerationSliderData.dAccDeceleration) *
                          (dAccelerationCollisionBoundaryPosition - dDecelerationCollisionBoundaryPosition))) /
                (objAccelerationSliderData.dAccDeceleration + objDecelerationSliderData.dAccDeceleration)
            )
            
            # 「衝突境界一致時間(ta)」> 0か判定：分岐範囲
            if dCollisionBoundaryMatchingPositionTimeA > 0:
                # 「衝突境界一致位置(Pa)」の算出
                # =「加速中スライダの現在速度」*「衝突境界一致位置時間(ta)」
                # '+0.5*「加速中スライダの加減速度」*「衝突境界一致位置時間(ta)」^2
                # '+「加速中スライダの衝突回避位置」
                dCollisionBoundaryMatchingPositionA = (
                    objAccelerationSliderData.dCurrentSpeed * dCollisionBoundaryMatchingPositionTimeA +
                    DISTANCE_CALCULATION_FIXED_VALUE_COLLISION * objAccelerationSliderData.dAccDeceleration *
                    dCollisionBoundaryMatchingPositionTimeA ** MULTIPLIER_VALUE_COLLISION +
                    dAccelerationCollisionBoundaryPosition
                )
            else:
                # 「衝突境界一致位置(Pa)」= -1
                dCollisionBoundaryMatchingPositionA = NO_COLLISION
            
            # 「衝突境界一致位置時間(tb)」の算出
            # ={-(「加速中スライダの現在速度」 - 「減速中スライダの現在速度」)
            # '-√[(「加速中スライダの現在速度」-「減速中スライダの現在速度)^2
            # '-2*(「加速中スライダの加減速度」+「減速中スライダの加減速度」)
            # '*(「加速中スライダの衝突境界位置」-「減速中スライダの衝突境界位置」)]}
            # '/(加速中スライダの加減速度」+「減速中スライダの加減速度」)
            dCollisionBoundaryMatchingPositionTimeB = (
                (-(objAccelerationSliderData.dCurrentSpeed - objDecelerationSliderData.dCurrentSpeed) -
                 math.sqrt((objAccelerationSliderData.dCurrentSpeed - objDecelerationSliderData.dCurrentSpeed) ** MULTIPLIER_VALUE_COLLISION -
                          TIME_CALCULATION_FIXED_VALUE_COLLISION * (objAccelerationSliderData.dAccDeceleration + objDecelerationSliderData.dAccDeceleration) *
                          (dAccelerationCollisionBoundaryPosition - dDecelerationCollisionBoundaryPosition))) /
                (objAccelerationSliderData.dAccDeceleration + objDecelerationSliderData.dAccDeceleration)
            )
            
            # 「衝突境界一致時間(tb)」> 0か判定：分岐範囲
            if dCollisionBoundaryMatchingPositionTimeB > 0:
                # 「衝突境界一致位置(Pb)」の算出
                # =「加速中スライダの現在速度」*「衝突境界一致位置時間(tb)」
                # '+0.5*「加速中スライダの加減速度」*「衝突境界一致位置時間(tb)」^2
                # '+「加速中スライダの衝突回避位置」
                dCollisionBoundaryMatchingPositionB = (
                    objAccelerationSliderData.dCurrentSpeed * dCollisionBoundaryMatchingPositionTimeB +
                    DISTANCE_CALCULATION_FIXED_VALUE_COLLISION * objAccelerationSliderData.dAccDeceleration *
                    dCollisionBoundaryMatchingPositionTimeB ** MULTIPLIER_VALUE_COLLISION +
                    dAccelerationCollisionBoundaryPosition
                )
            else:
                # 「衝突境界一致位置(Pb)」= -1
                dCollisionBoundaryMatchingPositionB = NO_COLLISION
            
            # 「衝突境界一致位置(Pa)」= -1 かつ「衝突境界一致位置(Pb)」= -1 か判定：分岐範囲
            if dCollisionBoundaryMatchingPositionA == NO_COLLISION and dCollisionBoundaryMatchingPositionB == NO_COLLISION:
                # 「後方の衝突回避位置」= -1
                dBackwardCollisionAvoidancePosition = NO_COLLISION
            else:
                # 「衝突境界一致位置(Pa)」> 「衝突境界一致位置(Pb)」か判定：分岐範囲
                if dCollisionBoundaryMatchingPositionA > dCollisionBoundaryMatchingPositionB:
                    # 0 >= 「衝突境界一致位置(Pb)」か判定：分岐範囲
                    if 0 >= dCollisionBoundaryMatchingPositionB:
                        # 「衝突境界一致位置」= 「衝突境界一致位置(Pa)」
                        dCollisionBoundaryMatchingPosition = dCollisionBoundaryMatchingPositionA
                    else:
                        # 「衝突境界一致位置」= 「衝突境界一致位置(Pb)」
                        dCollisionBoundaryMatchingPosition = dCollisionBoundaryMatchingPositionB
                else:
                    # 0 >= 「衝突境界一致位置(Pa)」：分岐範囲
                    if 0 >= dCollisionBoundaryMatchingPositionA:
                        # 「衝突境界一致位置」= 「衝突境界一致位置(Pb)」
                        dCollisionBoundaryMatchingPosition = dCollisionBoundaryMatchingPositionB
                    else:
                        # 「衝突境界一致位置」= 「衝突境界一致位置(Pa)」
                        dCollisionBoundaryMatchingPosition = dCollisionBoundaryMatchingPositionA
                
                # 「後方の衝突回避位置」=「衝突境界一致位置」-（ 「スライダサイズ」/ 2 ）
                dSliderSize = self._slider_data_manipulater.readSliderSize()
                dBackwardCollisionAvoidancePosition = dCollisionBoundaryMatchingPosition - (dSliderSize / DIVISION_VALUE_COLLISION)
                
                # 「後方の加速状態」=「加速」か判定：分岐範囲
                if iBackwardAccelerationState == ACCELERATION:
                    # 「後方の衝突回避位置」>=「加速中スライダの目標位置」：分岐範囲
                    if dBackwardCollisionAvoidancePosition >= objAccelerationSliderData.dTargetPosition:
                        # 「後方の衝突回避位置」= -1
                        dBackwardCollisionAvoidancePosition = NO_COLLISION
                else:
                    # 「後方の衝突回避位置」>=「減速速中スライダの目標位置」:分岐範囲
                    if dBackwardCollisionAvoidancePosition >= objDecelerationSliderData.dTargetPosition:
                        # 「後方の衝突回避位置」= -1
                        dBackwardCollisionAvoidancePosition = NO_COLLISION
            
            # 返り値=「後方の衝突回避位置」
            return dBackwardCollisionAvoidancePosition
            
        except Exception as e:
            print(f"{MODULE_NAME_COLLISION_DETECTER}.calculationAccelerationDecelerationAvoidancePosition: Error - {e}")
            return NO_COLLISION
    
    # ===========================================================
    # 5.等速同士の衝突回避位置の算出
    # ===========================================================
    def calculationBetweenConstantSpeedAvoidancePosition(
        self,
        objForwardSliderData: SliderData,
        objBackwardSliderData: SliderData,
        dForwardCollisionBoundaryPosition: float,
        dBackwardCollisionBoundaryPosition: float
    ) -> float:
        """
        等速同士の衝突回避位置の算出
        
        Args:
            objForwardSliderData: 前方スライダデータオブジェクト
            objBackwardSliderData: 後方スライダデータオブジェクト
            dForwardCollisionBoundaryPosition: 前方衝突境界位置[mm]
            dBackwardCollisionBoundaryPosition: 後方衝突境界位置[mm]
            
        Returns:
            float: 後方の衝突回避位置[mm]（NO_COLLISION(-1)の場合は衝突無）
        """
        try:
            dCollisionBoundaryMatchingPositionTime = 0.0
            dCollisionBoundaryMatchingPosition = 0.0
            dBackwardCollisionAvoidancePosition = 0.0
            
            # VBA相当：With objForwardSliderData ... End With
            # Python実装：直接アクセス
            
            # 「前方の現在速度」=「後方の現在速度」か判定：分岐範囲
            if objForwardSliderData.dCurrentSpeed == objBackwardSliderData.dCurrentSpeed:
                # 「後方の衝突回避位置」= -1
                dBackwardCollisionAvoidancePosition = NO_COLLISION
                
                # 返り値=「後方の衝突回避位置」
                return dBackwardCollisionAvoidancePosition
            
            # 「衝突境界一致位置時間」の算出
            # =(「後方の衝突境界位置」-「前方の衝突境界位置」)
            # / (「前方の現在速度」-「後方の現在速度」)
            dCollisionBoundaryMatchingPositionTime = (
                (dBackwardCollisionBoundaryPosition - dForwardCollisionBoundaryPosition) /
                (objForwardSliderData.dCurrentSpeed - objBackwardSliderData.dCurrentSpeed)
            )
            
            # 「衝突境界一致時間」> 0か判定：分岐範囲
            if dCollisionBoundaryMatchingPositionTime > 0:
                # 「衝突境界一致位置」の算出
                # =「前方の現在速度」*「衝突境界一致時間」+「前方の衝突境界位置」
                dCollisionBoundaryMatchingPosition = (
                    objForwardSliderData.dCurrentSpeed * dCollisionBoundaryMatchingPositionTime +
                    dForwardCollisionBoundaryPosition
                )
            else:
                # 「衝突境界一致位置」= -1
                dCollisionBoundaryMatchingPosition = NO_COLLISION
            
            # 「衝突境界一致位置」= -1：分岐範囲
            if dCollisionBoundaryMatchingPosition == NO_COLLISION:
                # 「後方の衝突回避位置」= -1
                dBackwardCollisionAvoidancePosition = NO_COLLISION
            else:
                # 「後方の衝突回避位置」=「衝突境界一致位置」-（ 「スライダサイズ」/ 2 ）
                dSliderSize = self._slider_data_manipulater.readSliderSize()
                dBackwardCollisionAvoidancePosition = dCollisionBoundaryMatchingPosition - (dSliderSize / DIVISION_VALUE_COLLISION)
                
                # 「後方の衝突回避位置」>=「循環システム1周分の長さ」か判定：分岐範囲
                dOneLap = self._axis_data_manipulater.readOneLap(dSliderSize)
                if dBackwardCollisionAvoidancePosition >= dOneLap:
                    # 「後方の衝突回避位置」= 「後方の衝突回避位置」-「循環システム1周分の長さ」
                    dBackwardCollisionAvoidancePosition = dBackwardCollisionAvoidancePosition - dOneLap
                
                # 「後方の衝突回避位置」>=「後方の目標位置」か判定：分岐範囲
                if dBackwardCollisionAvoidancePosition >= objBackwardSliderData.dTargetPosition:
                    # 「後方の衝突回避位置」= -1
                    dBackwardCollisionAvoidancePosition = NO_COLLISION
            
            # 返り値=「後方の衝突回避位置」
            return dBackwardCollisionAvoidancePosition
            
        except Exception as e:
            print(f"{MODULE_NAME_COLLISION_DETECTER}.calculationBetweenConstantSpeedAvoidancePosition: Error - {e}")
            return NO_COLLISION
    
    # ===========================================================
    # 6.等速と減速の衝突回避位置の算出
    # ===========================================================
    def calculationConstantSpeedDecelerationAvoidancePosition(
        self,
        objConstantSpeedSliderData: SliderData,
        objDecelerationSliderData: SliderData,
        dConstantSpeedCollisionBoundaryPosition: float,
        dDecelerationCollisionBoundaryPosition: float,
        iBackwardAccelerationState: int
    ) -> float:
        """
        等速と減速の衝突回避位置の算出
        
        Args:
            objConstantSpeedSliderData: 等速中スライダデータオブジェクト
            objDecelerationSliderData: 減速中スライダデータオブジェクト
            dConstantSpeedCollisionBoundaryPosition: 等速中衝突境界位置[mm]
            dDecelerationCollisionBoundaryPosition: 減速中衝突境界位置[mm]
            iBackwardAccelerationState: 後方の加速状態
            
        Returns:
            float: 後方の衝突回避位置[mm]（NO_COLLISION(-1)の場合は衝突無）
        """
        try:
            dCollisionBoundaryMatchingPositionTimeA = 0.0
            dCollisionBoundaryMatchingPositionA = 0.0
            dCollisionBoundaryMatchingPositionTimeB = 0.0
            dCollisionBoundaryMatchingPositionB = 0.0
            dCollisionBoundaryMatchingPosition = 0.0
            dBackwardCollisionAvoidancePosition = 0.0
            dSqrArgument = 0.0
            
            # VBA相当：With objConstantSpeedSliderData ... End With
            # Python実装：直接アクセス
            
            # 「Sqr関数の引数」の算出：
            # =（「等速中の現在速度」-「減速中の現在速度」)^2
            # '-2*「減速中の加減速度」*(「等速中の衝突境界位置」-「減速中の衝突境界位置」）
            dSqrArgument = (
                (objConstantSpeedSliderData.dCurrentSpeed - objDecelerationSliderData.dCurrentSpeed) ** MULTIPLIER_VALUE_COLLISION -
                TIME_CALCULATION_FIXED_VALUE_COLLISION * objDecelerationSliderData.dAccDeceleration *
                (dConstantSpeedCollisionBoundaryPosition - dDecelerationCollisionBoundaryPosition)
            )
            
            # 0 >「Sqr関数の引数」か判定：分岐範囲
            if 0 > dSqrArgument:
                # 「後方の衝突回避位置」= -1
                dBackwardCollisionAvoidancePosition = NO_COLLISION
                
                # 返り値=「後方の衝突回避位置」
                return dBackwardCollisionAvoidancePosition
            
            # 「衝突境界一致位置時間(ta)」の算出
            # ={-(「等速中の現在速度」-「減速中の現在速度」)
            # '+√[(「等速中の現在速度」-「減速中の現在速度」)^2
            # '-2*「減速中の加減速度」*(「等速中の衝突境界位置」-「減速中の衝突境界位置」)]}
            # '/「減速中の加減速度」
            dCollisionBoundaryMatchingPositionTimeA = (
                (-(objConstantSpeedSliderData.dCurrentSpeed - objDecelerationSliderData.dCurrentSpeed) +
                 math.sqrt((objConstantSpeedSliderData.dCurrentSpeed - objDecelerationSliderData.dCurrentSpeed) ** MULTIPLIER_VALUE_COLLISION -
                          TIME_CALCULATION_FIXED_VALUE_COLLISION * objDecelerationSliderData.dAccDeceleration *
                          (dConstantSpeedCollisionBoundaryPosition - dDecelerationCollisionBoundaryPosition))) /
                objDecelerationSliderData.dAccDeceleration
            )
            
            # 「衝突境界一致時間(ta)」> 0か判定：分岐範囲
            if dCollisionBoundaryMatchingPositionTimeA > 0:
                # 「衝突境界一致位置(Pa)」の算出
                # =「等速中の現在速度」*「衝突境界一致位置時間(ta)」+「等速中の衝突境界位置」
                dCollisionBoundaryMatchingPositionA = (
                    objConstantSpeedSliderData.dCurrentSpeed * dCollisionBoundaryMatchingPositionTimeA +
                    dConstantSpeedCollisionBoundaryPosition
                )
            else:
                # 「衝突境界一致位置(Pa)」= -1
                dCollisionBoundaryMatchingPositionA = NO_COLLISION
            
            # 「衝突境界一致位置時間(tb)」の算出
            # ={-(「等速中の現在速度」-「減速中の現在速度」)
            # '-√[(「等速中の現在速度」-「減速中の現在速度」)^2
            # '-2*「減速中の加減速度」*(「等速中の衝突境界位置」-「減速中の衝突境界位置」)]}
            # '/「減速中の加減速度」
            # 注意：VBA コードに誤りがある可能性（減速側加減速度と位置差の積が式に入るべき）
            # 補足：VBA 1514 行付近の式を踏襲し、現行のまま使用
            dCollisionBoundaryMatchingPositionTimeB = (
                (-(objConstantSpeedSliderData.dCurrentSpeed - objDecelerationSliderData.dCurrentSpeed) -
                 math.sqrt((objConstantSpeedSliderData.dCurrentSpeed - objDecelerationSliderData.dCurrentSpeed) ** MULTIPLIER_VALUE_COLLISION -
                          TIME_CALCULATION_FIXED_VALUE_COLLISION * (dConstantSpeedCollisionBoundaryPosition - dDecelerationCollisionBoundaryPosition))) /
                objDecelerationSliderData.dAccDeceleration
            )
            
            # 「衝突境界一致時間(tb)」> 0か判定：分岐範囲
            if dCollisionBoundaryMatchingPositionTimeB > 0:
                # 「衝突境界一致位置(Pb)」の算出
                # =「等速中の現在速度」*「衝突境界一致位置時間(tb)」+「等速中の衝突境界位置」
                dCollisionBoundaryMatchingPositionB = (
                    objConstantSpeedSliderData.dCurrentSpeed * dCollisionBoundaryMatchingPositionTimeB +
                    dConstantSpeedCollisionBoundaryPosition
                )
            else:
                # 「衝突境界一致位置(Pb)」= -1
                dCollisionBoundaryMatchingPositionB = NO_COLLISION
            
            # 「衝突境界一致位置(Pa)」= -1 かつ「衝突境界一致位置(Pb)」= -1 か判定：分岐範囲
            if dCollisionBoundaryMatchingPositionA == NO_COLLISION and dCollisionBoundaryMatchingPositionB == NO_COLLISION:
                # 「後方の衝突回避位置」= -1
                dBackwardCollisionAvoidancePosition = NO_COLLISION
            else:
                # 「衝突境界一致位置(Pa)」> 「衝突境界一致位置(Pb)」か判定：分岐範囲
                if dCollisionBoundaryMatchingPositionA > dCollisionBoundaryMatchingPositionB:
                    # 0 >= 「衝突境界一致位置(Pb)」か判定：分岐範囲
                    if 0 >= dCollisionBoundaryMatchingPositionB:
                        # 「衝突境界一致位置」= 「衝突境界一致位置(Pa)」
                        dCollisionBoundaryMatchingPosition = dCollisionBoundaryMatchingPositionA
                    else:
                        # 「衝突境界一致位置」= 「衝突境界一致位置(Pb)」
                        dCollisionBoundaryMatchingPosition = dCollisionBoundaryMatchingPositionB
                else:
                    # 0 >= 「衝突境界一致位置(Pa)」か判定：分岐範囲
                    if 0 >= dCollisionBoundaryMatchingPositionA:
                        # 「衝突境界一致位置」= 「衝突境界一致位置(Pb)」
                        dCollisionBoundaryMatchingPosition = dCollisionBoundaryMatchingPositionB
                    else:
                        # 「衝突境界一致位置」= 「衝突境界一致位置(Pa)」
                        dCollisionBoundaryMatchingPosition = dCollisionBoundaryMatchingPositionA
                
                # 「後方の衝突回避位置」=「衝突境界一致位置」-（ 「スライダサイズ」/ 2 ）
                dSliderSize = self._slider_data_manipulater.readSliderSize()
                dBackwardCollisionAvoidancePosition = dCollisionBoundaryMatchingPosition - (dSliderSize / DIVISION_VALUE_COLLISION)
                
                # 「後方の衝突回避位置」>=「循環システム1周分の長さ」か判定：分岐範囲
                dOneLap = self._axis_data_manipulater.readOneLap(dSliderSize)
                if dBackwardCollisionAvoidancePosition >= dOneLap:
                    # 「後方の衝突回避位置」= 「後方の衝突回避位置」-「循環システム1周分の長さ」
                    dBackwardCollisionAvoidancePosition = dBackwardCollisionAvoidancePosition - dOneLap
                
                # 「後方の加速状態」=「等速」か判定：分岐範囲
                if iBackwardAccelerationState == CONSTANT_SPEED:
                    # 「後方の衝突回避位置」>=「等速中スライダの目標位置」：分岐範囲
                    if dBackwardCollisionAvoidancePosition >= objConstantSpeedSliderData.dTargetPosition:
                        # 「後方の衝突回避位置」= -1
                        dBackwardCollisionAvoidancePosition = NO_COLLISION
                else:
                    # 「後方の衝突回避位置」>=「減速速中スライダの目標位置」:分岐範囲
                    if dBackwardCollisionAvoidancePosition >= objDecelerationSliderData.dTargetPosition:
                        # 「後方の衝突回避位置」= -1
                        dBackwardCollisionAvoidancePosition = NO_COLLISION
            
            # 返り値=「後方の衝突回避位置」
            return dBackwardCollisionAvoidancePosition
            
        except Exception as e:
            print(f"{MODULE_NAME_COLLISION_DETECTER}.calculationConstantSpeedDecelerationAvoidancePosition: Error - {e}")
            return NO_COLLISION
    
    # ===========================================================
    # 7.減速同士の衝突回避位置の算出
    # ===========================================================
    def calculationBetweenDecelerationAvoidancePosition(
        self,
        objForwardSliderData: SliderData,
        objBackwardSliderData: SliderData,
        dForwardCollisionBoundaryPosition: float,
        dBackwardCollisionBoundaryPosition: float
    ) -> float:
        """
        減速同士の衝突回避位置の算出
        
        Args:
            objForwardSliderData: 前方スライダデータオブジェクト
            objBackwardSliderData: 後方スライダデータオブジェクト
            dForwardCollisionBoundaryPosition: 前方衝突境界位置[mm]
            dBackwardCollisionBoundaryPosition: 後方衝突境界位置[mm]
            
        Returns:
            float: 後方の衝突回避位置[mm]（NO_COLLISION(-1)の場合は衝突無）
        """
        try:
            dCollisionBoundaryMatchingPositionTimeA = 0.0
            dCollisionBoundaryMatchingPositionA = 0.0
            dCollisionBoundaryMatchingPositionTimeB = 0.0
            dCollisionBoundaryMatchingPositionB = 0.0
            dCollisionBoundaryMatchingPosition = 0.0
            dBackwardCollisionAvoidancePosition = 0.0
            dSqrArgument = 0.0
            
            # VBA相当：With objBackwardSliderData ... End With
            # Python実装：直接アクセス
            
            # 「前方の加減速度」=「後方の加減速度」か判定：分岐範囲
            if objBackwardSliderData.dAccDeceleration == objForwardSliderData.dAccDeceleration:
                # 「後方の衝突回避位置」= -1
                dBackwardCollisionAvoidancePosition = NO_COLLISION
                
                # 返り値=「後方の衝突回避位置」
                return dBackwardCollisionAvoidancePosition
            
            # 「Sqr関数の引数」の算出
            # =(「前方の現在速度」-「後方の現在速度」)^2
            # '-2*(「後方の加減速度」-「前方の加減速度」)
            # '*(「前方の衝突境界位置」-「後方の衝突境界位置」)
            dSqrArgument = (
                (objForwardSliderData.dCurrentSpeed - objBackwardSliderData.dCurrentSpeed) ** MULTIPLIER_VALUE_COLLISION -
                TIME_CALCULATION_FIXED_VALUE_COLLISION * (objBackwardSliderData.dAccDeceleration - objForwardSliderData.dAccDeceleration) *
                (dForwardCollisionBoundaryPosition - dBackwardCollisionBoundaryPosition)
            )
            
            # 0 >「Sqr関数の引数」か判定：分岐範囲
            if 0 > dSqrArgument:
                # 「後方の衝突回避位置」= -1
                dBackwardCollisionAvoidancePosition = NO_COLLISION
                
                # 返り値=「後方の衝突回避位置」
                return dBackwardCollisionAvoidancePosition
            
            # 「衝突境界一致位置時間(ta)」の算出
            # ={-(「前方の現在速度」-「後方の現在速度」)
            # '+√[(「前方の現在速度」-「後方の現在速度」)^2
            # '-2*(「後方の加減速度」-「前方の加減速度」)
            # '*(「前方の衝突境界位置」-「後方の衝突境界位置」)]}
            # '/(「後方の加減速度」-「前方の加減速度」)
            dCollisionBoundaryMatchingPositionTimeA = (
                (-(objForwardSliderData.dCurrentSpeed - objBackwardSliderData.dCurrentSpeed) +
                 math.sqrt((objForwardSliderData.dCurrentSpeed - objBackwardSliderData.dCurrentSpeed) ** MULTIPLIER_VALUE_COLLISION -
                          TIME_CALCULATION_FIXED_VALUE_COLLISION * (objBackwardSliderData.dAccDeceleration - objForwardSliderData.dAccDeceleration) *
                          (dForwardCollisionBoundaryPosition - dBackwardCollisionBoundaryPosition))) /
                (objBackwardSliderData.dAccDeceleration - objForwardSliderData.dAccDeceleration)
            )
            
            # 「衝突境界一致時間(ta)」> 0か判定：分岐範囲
            if dCollisionBoundaryMatchingPositionTimeA > 0:
                # 「衝突境界一致位置(Pa)」の算出
                # =「後方の現在速度」*「衝突境界一致位置時間(ta)」
                # '-0.5*「後方の加減速度」*「衝突境界一致位置時間(ta)」^2
                # '+「後方の衝突境界位置」
                # 注意：VBA コードに誤りがある可能性（加減速度のべき乗ではなく、時間のべき乗を掛ける形であるべき）
                # 補足：VBA 1734 行付近の式を踏襲し、現行のまま使用
                dCollisionBoundaryMatchingPositionA = (
                    objBackwardSliderData.dCurrentSpeed * dCollisionBoundaryMatchingPositionTimeA -
                    DISTANCE_CALCULATION_FIXED_VALUE_COLLISION * objBackwardSliderData.dAccDeceleration ** MULTIPLIER_VALUE_COLLISION +
                    dBackwardCollisionBoundaryPosition
                )
            else:
                # 「衝突境界一致位置(Pa)」= -1
                dCollisionBoundaryMatchingPositionA = NO_COLLISION
            
            # 「衝突境界一致位置時間(tb)」の算出
            # ={-(「前方の現在速度」-「後方の現在速度」)
            # '-√[(「前方の現在速度」-「後方の現在速度」)^2
            # '-2*(「後方の加減速度」-「前方の加減速度」)
            # '*(「前方の衝突境界位置」-「後方の衝突境界位置」)]}
            # '/(「後方の加減速度」-「前方の加減速度」)
            dCollisionBoundaryMatchingPositionTimeB = (
                (-(objForwardSliderData.dCurrentSpeed - objBackwardSliderData.dCurrentSpeed) -
                 math.sqrt((objForwardSliderData.dCurrentSpeed - objBackwardSliderData.dCurrentSpeed) ** MULTIPLIER_VALUE_COLLISION -
                          TIME_CALCULATION_FIXED_VALUE_COLLISION * (objBackwardSliderData.dAccDeceleration - objForwardSliderData.dAccDeceleration) *
                          (dForwardCollisionBoundaryPosition - dBackwardCollisionBoundaryPosition))) /
                (objBackwardSliderData.dAccDeceleration - objForwardSliderData.dAccDeceleration)
            )
            
            # 「衝突境界一致時間(tb)」> 0か判定：分岐範囲
            if dCollisionBoundaryMatchingPositionTimeB > 0:
                # 「衝突境界一致位置(Pb)」の算出
                # =「後方の現在速度」*「衝突境界一致位置時間(tb)」
                # '-0.5*「後方の加減速度」*「衝突境界一致位置時間(tb)」^2
                # '+「後方の衝突境界位置」
                # 注意：VBA コードに誤りがある可能性（直前の Pa 算出と同様の指摘）
                dCollisionBoundaryMatchingPositionB = (
                    objBackwardSliderData.dCurrentSpeed * dCollisionBoundaryMatchingPositionTimeB -
                    DISTANCE_CALCULATION_FIXED_VALUE_COLLISION * objBackwardSliderData.dAccDeceleration ** MULTIPLIER_VALUE_COLLISION +
                    dBackwardCollisionBoundaryPosition
                )
            else:
                # 「衝突境界一致位置(Pb)」= -1
                dCollisionBoundaryMatchingPositionB = NO_COLLISION
            
            # 「衝突境界一致位置(Pa)」= -1 かつ「衝突境界一致位置(Pb)」= -1 か判定：分岐範囲
            if dCollisionBoundaryMatchingPositionA == NO_COLLISION and dCollisionBoundaryMatchingPositionB == NO_COLLISION:
                # 「後方の衝突回避位置」= -1
                dBackwardCollisionAvoidancePosition = NO_COLLISION
            else:
                # 「衝突境界一致位置(Pa)」> 「衝突境界一致位置(Pb)」か判定：分岐範囲
                if dCollisionBoundaryMatchingPositionA > dCollisionBoundaryMatchingPositionB:
                    # 0 >= 「衝突境界一致位置(Pb)」か判定：分岐範囲
                    if 0 >= dCollisionBoundaryMatchingPositionB:
                        # 「衝突境界一致位置」= 「衝突境界一致位置(Pa)」
                        dCollisionBoundaryMatchingPosition = dCollisionBoundaryMatchingPositionA
                    else:
                        # 「衝突境界一致位置」= 「衝突境界一致位置(Pb)」
                        dCollisionBoundaryMatchingPosition = dCollisionBoundaryMatchingPositionB
                else:
                    # 0 >= 「衝突境界一致位置(Pa)」か判定：分岐範囲
                    if 0 >= dCollisionBoundaryMatchingPositionA:
                        # 「衝突境界一致位置」= 「衝突境界一致位置(Pb)」
                        dCollisionBoundaryMatchingPosition = dCollisionBoundaryMatchingPositionB
                    else:
                        # 「衝突境界一致位置」= 「衝突境界一致位置(Pa)」
                        dCollisionBoundaryMatchingPosition = dCollisionBoundaryMatchingPositionA
                
                # 「後方の衝突回避位置」=「衝突境界一致位置」-（ 「スライダサイズ」/ 2 ）
                dSliderSize = self._slider_data_manipulater.readSliderSize()
                dBackwardCollisionAvoidancePosition = dCollisionBoundaryMatchingPosition - (dSliderSize / DIVISION_VALUE_COLLISION)
                
                # 「後方の衝突回避位置」>=「循環システム1周分の長さ」か判定：分岐範囲
                dOneLap = self._axis_data_manipulater.readOneLap(dSliderSize)
                if dBackwardCollisionAvoidancePosition >= dOneLap:
                    # 「後方の衝突回避位置」= 「後方の衝突回避位置」-「循環システム1周分の長さ」
                    dBackwardCollisionAvoidancePosition = dBackwardCollisionAvoidancePosition - dOneLap
                
                # 「後方の衝突回避位置」>=「後方の目標位置」か判定：分岐範囲
                if dBackwardCollisionAvoidancePosition >= objBackwardSliderData.dTargetPosition:
                    # 「後方の衝突回避位置」= -1
                    dBackwardCollisionAvoidancePosition = NO_COLLISION
            
            # 返り値=「後方の衝突回避位置」
            return dBackwardCollisionAvoidancePosition
            
        except Exception as e:
            print(f"{MODULE_NAME_COLLISION_DETECTER}.calculationBetweenDecelerationAvoidancePosition: Error - {e}")
            return NO_COLLISION
    
    # ===========================================================
    # 8.停止と加速の衝突回避位置の算出
    # ===========================================================
    def calculationStopAccelerationAvoidancePosition(
        self,
        objForwardSliderData: SliderData,
        objBackwardSliderData: SliderData,
        dForwardCollisionBoundaryPosition: float,
        dBackwardCollisionBoundaryPosition: float
    ) -> float:
        """
        停止と加速の衝突回避位置の算出
        
        Args:
            objForwardSliderData: 前方スライダデータオブジェクト
            objBackwardSliderData: 後方スライダデータオブジェクト
            dForwardCollisionBoundaryPosition: 前方衝突境界位置[mm]
            dBackwardCollisionBoundaryPosition: 後方衝突境界位置[mm]
            
        Returns:
            float: 後方の衝突回避位置[mm]（NO_COLLISION(-1)の場合は衝突無）
        """
        try:
            dCollisionBoundaryMatchingPositionTimeA = 0.0
            dCollisionBoundaryMatchingPositionA = 0.0
            dCollisionBoundaryMatchingPositionTimeB = 0.0
            dCollisionBoundaryMatchingPositionB = 0.0
            dCollisionBoundaryMatchingPosition = 0.0
            dBackwardCollisionAvoidancePosition = 0.0
            dTempBackwardTargetPosition = 0.0
            dSqrArgument = 0.0
            
            # VBA相当：With objBackwardSliderData ... End With
            # Python実装：直接アクセス
            
            # 「後方の加減速度」= 0か判定：分岐範囲
            if objBackwardSliderData.dAccDeceleration == 0:
                # 「後方の衝突回避位置」= -1
                dBackwardCollisionAvoidancePosition = NO_COLLISION
                
                # 返り値=「後方の衝突回避位置」
                return dBackwardCollisionAvoidancePosition
            
            # 「Sqr関数の引数」の算出
            # =「後方の現在速度」^2
            # '-2 *「後方の加減速度」
            # '* (「後方の衝突境界位置」-「前方の衝突回避位置」)
            # '/ 「後方の加減速度」
            # 注意：VBA コードに誤りがある可能性（末尾の加減速度による除算は冗長）
            # 補足：VBA 1909 行付近の式を踏襲し、現行のまま使用
            dSqrArgument = (
                objBackwardSliderData.dCurrentSpeed ** MULTIPLIER_VALUE_COLLISION -
                TIME_CALCULATION_FIXED_VALUE_COLLISION * objBackwardSliderData.dAccDeceleration *
                (dBackwardCollisionBoundaryPosition - dForwardCollisionBoundaryPosition) /
                objBackwardSliderData.dAccDeceleration
            )
            
            # 0 >「Sqr関数の引数」か判定：分岐範囲
            if 0 > dSqrArgument:
                # 「後方の衝突回避位置」= 「後方の現在位置」
                dBackwardCollisionAvoidancePosition = objBackwardSliderData.dCurrentPosition
                
                # 返り値=「後方の衝突回避位置」
                return dBackwardCollisionAvoidancePosition
            
            # 「衝突境界一致位置時間(ta)」の算出
            # ={-「後方の現在速度」
            # '+√ [ 「後方の現在速度」^2
            # '-2 * 「後方の加減速度」
            # '* (「後方の衝突境界位置」-「前方の衝突回避位置」) ]  }
            # '/ 「後方の加減速度」
            dCollisionBoundaryMatchingPositionTimeA = (
                (-objBackwardSliderData.dCurrentSpeed +
                 math.sqrt(objBackwardSliderData.dCurrentSpeed ** MULTIPLIER_VALUE_COLLISION -
                          TIME_CALCULATION_FIXED_VALUE_COLLISION * objBackwardSliderData.dAccDeceleration *
                          (dBackwardCollisionBoundaryPosition - dForwardCollisionBoundaryPosition))) /
                objBackwardSliderData.dAccDeceleration
            )
            
            # 「衝突境界一致時間(ta)」> 0か判定：分岐範囲
            if dCollisionBoundaryMatchingPositionTimeA > 0:
                # 「衝突境界一致位置(Pa)」の算出
                # =「後方の現在速度」*「衝突境界一致時間(ta)」
                # '+0.5*「後方の加減速度」
                # '*「衝突境界一致時間(ta)」^2
                # '+「後方の衝突回避位置」
                dCollisionBoundaryMatchingPositionA = (
                    objBackwardSliderData.dCurrentSpeed * dCollisionBoundaryMatchingPositionTimeA +
                    DISTANCE_CALCULATION_FIXED_VALUE_COLLISION * objBackwardSliderData.dAccDeceleration *
                    dCollisionBoundaryMatchingPositionTimeA ** MULTIPLIER_VALUE_COLLISION +
                    dBackwardCollisionBoundaryPosition
                )
            else:
                # 「衝突境界一致位置(Pa)」= -1
                dCollisionBoundaryMatchingPositionA = NO_COLLISION
            
            # 「衝突境界一致位置時間(tb)」の算出
            # ={-「後方の現在速度」
            # '-√ [ 「後方の現在速度」^2
            # '-2 * 「後方の加減速度」
            # '* (「後方の衝突境界位置」-「前方の衝突回避位置」) ]  }
            # '/ 「後方の加減速度」
            dCollisionBoundaryMatchingPositionTimeB = (
                (-objBackwardSliderData.dCurrentSpeed -
                 math.sqrt(objBackwardSliderData.dCurrentSpeed ** MULTIPLIER_VALUE_COLLISION -
                          TIME_CALCULATION_FIXED_VALUE_COLLISION * objBackwardSliderData.dAccDeceleration *
                          (dBackwardCollisionBoundaryPosition - dForwardCollisionBoundaryPosition))) /
                objBackwardSliderData.dAccDeceleration
            )
            
            # 「衝突境界一致時間(tb)」> 0か判定：分岐範囲
            if dCollisionBoundaryMatchingPositionTimeB > 0:
                # 「衝突境界一致位置(Pb)」の算出
                # =「後方の現在速度」*「衝突境界一致時間(tb)」
                # '+0.5*「後方の加減速度」
                # '*「衝突境界一致時間(tb)」^2
                # '+「後方の衝突回避位置」
                dCollisionBoundaryMatchingPositionB = (
                    objBackwardSliderData.dCurrentSpeed * dCollisionBoundaryMatchingPositionTimeB +
                    DISTANCE_CALCULATION_FIXED_VALUE_COLLISION * objBackwardSliderData.dAccDeceleration *
                    dCollisionBoundaryMatchingPositionTimeB ** MULTIPLIER_VALUE_COLLISION +
                    dBackwardCollisionBoundaryPosition
                )
            else:
                # 「衝突境界一致位置(Pb)」= -1
                dCollisionBoundaryMatchingPositionB = NO_COLLISION
            
            # 「衝突境界一致位置(Pa)」= -1 かつ「衝突境界一致位置(Pb)」= -1 か判定：分岐範囲
            if dCollisionBoundaryMatchingPositionA == NO_COLLISION and dCollisionBoundaryMatchingPositionB == NO_COLLISION:
                # 「後方の衝突回避位置」= -1
                dBackwardCollisionAvoidancePosition = NO_COLLISION
            else:
                # 「衝突境界一致位置(Pa)」> 「衝突境界一致位置(Pb)」か判定：分岐範囲
                if dCollisionBoundaryMatchingPositionA > dCollisionBoundaryMatchingPositionB:
                    # 0 >= 「衝突境界一致位置(Pb)」か判定：分岐範囲
                    if 0 >= dCollisionBoundaryMatchingPositionB:
                        # 「衝突境界一致位置」= 「衝突境界一致位置(Pa)」
                        dCollisionBoundaryMatchingPosition = dCollisionBoundaryMatchingPositionA
                    else:
                        # 「衝突境界一致位置」= 「衝突境界一致位置(Pb)」
                        dCollisionBoundaryMatchingPosition = dCollisionBoundaryMatchingPositionB
                else:
                    # 0 >= 「衝突境界一致位置(Pa)」か判定：分岐範囲
                    if 0 >= dCollisionBoundaryMatchingPositionA:
                        # 「衝突境界一致位置」= 「衝突境界一致位置(Pb)」
                        dCollisionBoundaryMatchingPosition = dCollisionBoundaryMatchingPositionB
                    else:
                        # 「衝突境界一致位置」= 「衝突境界一致位置(Pa)」
                        dCollisionBoundaryMatchingPosition = dCollisionBoundaryMatchingPositionA
                
                # 「後方の衝突回避位置」=「衝突境界一致位置」-（ 「スライダサイズ」/ 2 ）
                dSliderSize = self._slider_data_manipulater.readSliderSize()
                dBackwardCollisionAvoidancePosition = dCollisionBoundaryMatchingPosition - (dSliderSize / DIVISION_VALUE_COLLISION)
                
                # 「後方の目標位置」= 0か判定：分岐範囲
                if objBackwardSliderData.dTargetPosition == 0:
                    # 「後方の目標位置（一時保存）」= 「循環システム1周分の長さ」
                    dOneLap = self._axis_data_manipulater.readOneLap(dSliderSize)
                    dTempBackwardTargetPosition = dOneLap
                else:
                    # 「後方の目標位置（一時保存）」= 「後方の目標位置」
                    dTempBackwardTargetPosition = objBackwardSliderData.dTargetPosition
                
                # 「後方の衝突回避位置」>=「後方の目標位置（一時保存）」か判定：分岐範囲
                if dBackwardCollisionAvoidancePosition >= dTempBackwardTargetPosition:
                    # 「後方の衝突回避位置」= -1
                    dBackwardCollisionAvoidancePosition = NO_COLLISION
            
            # 返り値=「後方の衝突回避位置」
            return dBackwardCollisionAvoidancePosition
            
        except Exception as e:
            print(f"{MODULE_NAME_COLLISION_DETECTER}.calculationStopAccelerationAvoidancePosition: Error - {e}")
            return NO_COLLISION
    
    # ===========================================================
    # 9.停止と等速の衝突回避位置の算出
    # ===========================================================
    def calculationStopConstantSpeedAvoidancePosition(
        self,
        objForwardSliderData: SliderData,
        objBackwardSliderData: SliderData,
        dForwardCollisionBoundaryPosition: float,
        dBackwardCollisionBoundaryPosition: float
    ) -> float:
        """
        停止と等速の衝突回避位置の算出
        
        Args:
            objForwardSliderData: 前方スライダデータオブジェクト
            objBackwardSliderData: 後方スライダデータオブジェクト
            dForwardCollisionBoundaryPosition: 前方衝突境界位置[mm]
            dBackwardCollisionBoundaryPosition: 後方衝突境界位置[mm]
            
        Returns:
            float: 後方の衝突回避位置[mm]（NO_COLLISION(-1)の場合は衝突無）
        """
        try:
            dCollisionBoundaryMatchingPositionTime = 0.0
            dCollisionBoundaryMatchingPosition = 0.0
            dBackwardCollisionAvoidancePosition = 0.0
            dSqrArgument = 0.0
            
            # VBA相当：With objBackwardSliderData ... End With
            # Python実装：直接アクセス
            
            # 「後方の現在速度」= 0か判定：分岐範囲
            if objBackwardSliderData.dCurrentSpeed == 0:
                # 「後方の衝突回避位置」= -1
                dBackwardCollisionAvoidancePosition = NO_COLLISION
                
                # 返り値=「後方の衝突回避位置」
                return dBackwardCollisionAvoidancePosition
            
            # 「衝突境界一致位置時間」の算出
            # =(「前方の衝突境界位置」-「後方の衝突境界位置」) / 「後方の現在速度」
            dCollisionBoundaryMatchingPositionTime = (
                (dForwardCollisionBoundaryPosition - dBackwardCollisionBoundaryPosition) /
                objBackwardSliderData.dCurrentSpeed
            )
            
            # 「衝突境界一致時間」> 0か判定：分岐範囲
            if dCollisionBoundaryMatchingPositionTime > 0:
                # 「衝突境界一致位置」の算出
                # =「後方の現在速度」*「衝突一致時間」+「後方の現在位置」
                dCollisionBoundaryMatchingPosition = (
                    objBackwardSliderData.dCurrentSpeed * dCollisionBoundaryMatchingPositionTime +
                    dBackwardCollisionBoundaryPosition
                )
            else:
                # 「衝突境界一致位置」= -1
                dCollisionBoundaryMatchingPosition = NO_COLLISION
            
            # 「衝突境界一致位置」= -1 か判定：分岐範囲
            if dCollisionBoundaryMatchingPosition == NO_COLLISION:
                # 「後方の衝突回避位置」= -1
                dBackwardCollisionAvoidancePosition = NO_COLLISION
            else:
                # 「後方の衝突回避位置」=「衝突境界一致位置」-（ 「スライダサイズ」 / 2 )
                dSliderSize = self._slider_data_manipulater.readSliderSize()
                dBackwardCollisionAvoidancePosition = dCollisionBoundaryMatchingPosition - (dSliderSize / DIVISION_VALUE_COLLISION)
                
                # 「後方の衝突回避位置」>=「循環システム1周分の長さ」か判定：分岐範囲
                dOneLap = self._axis_data_manipulater.readOneLap(dSliderSize)
                if dBackwardCollisionAvoidancePosition >= dOneLap:
                    # 「後方の衝突回避位置」= 「後方の衝突回避位置」-「循環システム1周分の長さ」
                    dBackwardCollisionAvoidancePosition = dBackwardCollisionAvoidancePosition - dOneLap
                
                # 「後方の衝突回避位置」>=「後方の目標位置」か判定
                if dBackwardCollisionAvoidancePosition >= objBackwardSliderData.dTargetPosition:
                    # 「後方の衝突回避位置」= -1
                    dBackwardCollisionAvoidancePosition = NO_COLLISION
            
            # 返り値=「後方の衝突回避位置」
            return dBackwardCollisionAvoidancePosition
            
        except Exception as e:
            print(f"{MODULE_NAME_COLLISION_DETECTER}.calculationStopConstantSpeedAvoidancePosition: Error - {e}")
            return NO_COLLISION
    
    # ===========================================================
    # 10.停止と減速の衝突回避位置の算出
    # ===========================================================
    def calculationStopDecelerationAvoidancePosition(
        self,
        objForwardSliderData: SliderData,
        objBackwardSliderData: SliderData,
        dForwardCollisionBoundaryPosition: float,
        dBackwardCollisionBoundaryPosition: float
    ) -> float:
        """
        停止と減速の衝突回避位置の算出
        
        Args:
            objForwardSliderData: 前方スライダデータオブジェクト
            objBackwardSliderData: 後方スライダデータオブジェクト
            dForwardCollisionBoundaryPosition: 前方衝突境界位置[mm]
            dBackwardCollisionBoundaryPosition: 後方衝突境界位置[mm]
            
        Returns:
            float: 後方の衝突回避位置[mm]（NO_COLLISION(-1)の場合は衝突無）
        """
        try:
            dCollisionBoundaryMatchingPositionTimeA = 0.0
            dCollisionBoundaryMatchingPositionA = 0.0
            dCollisionBoundaryMatchingPositionTimeB = 0.0
            dCollisionBoundaryMatchingPositionB = 0.0
            dCollisionBoundaryMatchingPosition = 0.0
            dBackwardCollisionAvoidancePosition = 0.0
            dTempBackwardTargetPosition = 0.0
            dSqrArgument = 0.0
            dForBackwardDifference = 0.0
            
            # VBA相当：With objBackwardSliderData ... End With
            # Python実装：直接アクセス
            
            # 「後方の加減速度」= 0か判定：分岐範囲
            if objBackwardSliderData.dAccDeceleration == 0:
                # 「後方の衝突回避位置」= -1
                dBackwardCollisionAvoidancePosition = NO_COLLISION
                
                # 返り値=「後方の衝突回避位置」
                return dBackwardCollisionAvoidancePosition
            
            # 「Sqr関数の引数」の算出
            # =「後方の現在速度」^2
            # '-2 *「後方の加減速度」
            # '* (「前方の衝突境界位置」-「後方の衝突回避位置」)
            dSqrArgument = (
                objBackwardSliderData.dCurrentSpeed ** MULTIPLIER_VALUE_COLLISION -
                TIME_CALCULATION_FIXED_VALUE_COLLISION * objBackwardSliderData.dAccDeceleration *
                (dForwardCollisionBoundaryPosition - dBackwardCollisionBoundaryPosition)
            )
            
            # 0 >「Sqr関数の引数」か判定：分岐範囲
            if 0 > dSqrArgument:
                # 「前後の差分」=「前方の現在位置」と「後方の目標位置」の差分
                dForBackwardDifference = abs(objForwardSliderData.dCurrentPosition - objBackwardSliderData.dTargetPosition)
                
                # 「スライダサイズ」>「前後の差分」か判定：分岐範囲
                dSliderSize = self._slider_data_manipulater.readSliderSize()
                if dSliderSize > dForBackwardDifference:
                    # 「後方の衝突回避位置」= 「前方の現在位置」-「スライダサイズ」
                    dBackwardCollisionAvoidancePosition = objForwardSliderData.dCurrentPosition - dSliderSize
                    
                    # 「後方の衝突回避位置」>=「循環システム1周分の長さ」か判定：分岐範囲
                    dOneLap = self._axis_data_manipulater.readOneLap(dSliderSize)
                    if dBackwardCollisionAvoidancePosition >= dOneLap:
                        # 「後方の衝突回避位置」= 「後方の衝突回避位置」-「循環システム1周分の長さ」
                        dBackwardCollisionAvoidancePosition = dBackwardCollisionAvoidancePosition - dOneLap
                else:
                    # 「後方の衝突回避位置」= -1
                    dBackwardCollisionAvoidancePosition = NO_COLLISION
                
                # 返り値=「後方の衝突回避位置」
                return dBackwardCollisionAvoidancePosition
            
            # 「衝突境界一致位置時間(ta)」の算出
            # ={「後方の現在速度」
            # '+√ [ 「後方の現在速度」^2
            # '-2 * 「後方の加減速度」
            # '* (「前方の衝突境界位置」-「後方の衝突回避位置」) ]  }
            # '/ 「後方の加減速度」
            dCollisionBoundaryMatchingPositionTimeA = (
                (objBackwardSliderData.dCurrentSpeed +
                 math.sqrt(objBackwardSliderData.dCurrentSpeed ** MULTIPLIER_VALUE_COLLISION -
                          TIME_CALCULATION_FIXED_VALUE_COLLISION * objBackwardSliderData.dAccDeceleration *
                          (dForwardCollisionBoundaryPosition - dBackwardCollisionBoundaryPosition))) /
                objBackwardSliderData.dAccDeceleration
            )
            
            # 「衝突境界一致時間(ta)」> 0か判定：分岐範囲
            if dCollisionBoundaryMatchingPositionTimeA > 0:
                # 「衝突境界一致位置(Pa)」の算出
                # =「後方の現在速度」*「衝突境界一致時間(ta)」
                # '-0.5*「後方の加減速度」
                # '*「衝突境界一致時間(ta)」^2
                # '+「後方の衝突回避位置」
                dCollisionBoundaryMatchingPositionA = (
                    objBackwardSliderData.dCurrentSpeed * dCollisionBoundaryMatchingPositionTimeA -
                    DISTANCE_CALCULATION_FIXED_VALUE_COLLISION * objBackwardSliderData.dAccDeceleration *
                    dCollisionBoundaryMatchingPositionTimeA ** MULTIPLIER_VALUE_COLLISION +
                    dBackwardCollisionBoundaryPosition
                )
            else:
                # 「衝突境界一致位置(Pa)」= -1
                dCollisionBoundaryMatchingPositionA = NO_COLLISION
            
            # 「衝突境界一致位置時間(tb)」の算出
            # ={「後方の現在速度」
            # '-√ [ 「後方の現在速度」^2
            # '-2 * 「後方の加減速度」
            # '* (「前方の衝突境界位置」-「後方の衝突回避位置」) ]  }
            # '/ 「後方の加減速度」
            dCollisionBoundaryMatchingPositionTimeB = (
                (objBackwardSliderData.dCurrentSpeed -
                 math.sqrt(objBackwardSliderData.dCurrentSpeed ** MULTIPLIER_VALUE_COLLISION -
                          TIME_CALCULATION_FIXED_VALUE_COLLISION * objBackwardSliderData.dAccDeceleration *
                          (dForwardCollisionBoundaryPosition - dBackwardCollisionBoundaryPosition))) /
                objBackwardSliderData.dAccDeceleration
            )
            
            # 「衝突境界一致時間(tb)」> 0か判定：分岐範囲
            if dCollisionBoundaryMatchingPositionTimeB > 0:
                # 「衝突境界一致位置(Pb)」の算出
                # =「後方の現在速度」*「衝突境界一致時間(tb)」
                # '-0.5*「後方の加減速度」
                # '*「衝突境界一致時間(tb)」^2
                # '+「後方の衝突回避位置」
                dCollisionBoundaryMatchingPositionB = (
                    objBackwardSliderData.dCurrentSpeed * dCollisionBoundaryMatchingPositionTimeB -
                    DISTANCE_CALCULATION_FIXED_VALUE_COLLISION * objBackwardSliderData.dAccDeceleration *
                    dCollisionBoundaryMatchingPositionTimeB ** MULTIPLIER_VALUE_COLLISION +
                    dBackwardCollisionBoundaryPosition
                )
            else:
                # 「衝突境界一致位置(Pb)」= -1
                dCollisionBoundaryMatchingPositionB = NO_COLLISION
            
            # 「衝突境界一致位置(Pa)」= -1 かつ「衝突境界一致位置(Pb)」= -1 か判定：分岐範囲
            if dCollisionBoundaryMatchingPositionA == NO_COLLISION and dCollisionBoundaryMatchingPositionB == NO_COLLISION:
                # 「後方の衝突回避位置」= -1
                dBackwardCollisionAvoidancePosition = NO_COLLISION
            else:
                # 「衝突境界一致位置(Pa)」> 「衝突境界一致位置(Pb)」か判定：分岐範囲
                if dCollisionBoundaryMatchingPositionA > dCollisionBoundaryMatchingPositionB:
                    # 0 >= 「衝突境界一致位置(Pb)」か判定：分岐範囲
                    if 0 >= dCollisionBoundaryMatchingPositionB:
                        # 「衝突境界一致位置」= 「衝突境界一致位置(Pa)」
                        dCollisionBoundaryMatchingPosition = dCollisionBoundaryMatchingPositionA
                    else:
                        # 「衝突境界一致位置」= 「衝突境界一致位置(Pb)」
                        dCollisionBoundaryMatchingPosition = dCollisionBoundaryMatchingPositionB
                else:
                    # 0 >= 「衝突境界一致位置(Pa)」か判定：分岐範囲
                    if 0 >= dCollisionBoundaryMatchingPositionA:
                        # 「衝突境界一致位置」= 「衝突境界一致位置(Pb)」
                        dCollisionBoundaryMatchingPosition = dCollisionBoundaryMatchingPositionB
                    else:
                        # 「衝突境界一致位置」= 「衝突境界一致位置(Pa)」
                        dCollisionBoundaryMatchingPosition = dCollisionBoundaryMatchingPositionA
                
                # 「後方の衝突回避位置」=「衝突境界一致位置」-（ 「スライダサイズ」/ 2 ）
                dSliderSize = self._slider_data_manipulater.readSliderSize()
                dBackwardCollisionAvoidancePosition = dCollisionBoundaryMatchingPosition - (dSliderSize / DIVISION_VALUE_COLLISION)
                
                # 「後方の衝突回避位置」>=「循環システム1周分の長さ」か判定：分岐範囲
                dOneLap = self._axis_data_manipulater.readOneLap(dSliderSize)
                if dBackwardCollisionAvoidancePosition >= dOneLap:
                    # 「後方の衝突回避位置」= 「後方の衝突回避位置」-「循環システム1周分の長さ」
                    dBackwardCollisionAvoidancePosition = dBackwardCollisionAvoidancePosition - dOneLap
                
                # 「後方の目標位置」= 0か判定：分岐範囲
                if objBackwardSliderData.dTargetPosition == 0:
                    # 「後方の目標位置（一時保存）」= 「循環システム1周分の長さ」
                    dTempBackwardTargetPosition = dOneLap
                else:
                    # 「後方の目標位置（一時保存）」= 「後方の目標位置」
                    dTempBackwardTargetPosition = objBackwardSliderData.dTargetPosition
                
                # 「後方の衝突回避位置」>=「後方の目標位置（一時保存）」か判定：分岐範囲
                if dBackwardCollisionAvoidancePosition >= dTempBackwardTargetPosition:
                    # 「後方の衝突回避位置」= -1
                    dBackwardCollisionAvoidancePosition = NO_COLLISION
            
            # 返り値=「後方の衝突回避位置」
            return dBackwardCollisionAvoidancePosition
            
        except Exception as e:
            print(f"{MODULE_NAME_COLLISION_DETECTER}.calculationStopDecelerationAvoidancePosition: Error - {e}")
            return NO_COLLISION
    
    # ===========================================================
    # 11.目標位置設定
    # ===========================================================
    def settingTargetPosition(
        self,
        objBackwardSliderData: SliderData,
        objForwardSliderData: SliderData
    ) -> float:
        """
        目標位置設定
        
        Args:
            objBackwardSliderData: 後方スライダデータオブジェクト
            objForwardSliderData: 前方スライダデータオブジェクト
            
        Returns:
            float: 衝突判定結果（NO_COLLISION(-1) または COLLISION(1)）
        """
        try:
            dCollisionDeterminationResult = 0.0
            dTempForwarTargetPosition = 0.0
            dForwarOffsetTargetPosition = 0.0
            dTempForwarCurrentPosition = 0.0
            dTempForwarShortestStopPosition = 0.0
            dDecelerationDistance = 0.0
            dTempBackwardShortestStopPosition = 0.0
            dBackwardOffsetShortestStopPosition = 0.0
            
            # 「衝突判定結果」= -1
            dCollisionDeterminationResult = NO_COLLISION
            
            # VBA相当：With objForwardSliderData ... End With
            # Python実装：直接アクセス
            
            # 「後方の現在速度」<=「前方の現在速度」か判定：分岐範囲
            if objBackwardSliderData.dCurrentSpeed <= objForwardSliderData.dCurrentSpeed:
                # 「後方の現在速度」<=「前方の現在速度」Or 「前方の状態」=「停止」」か判定：分岐範囲
                if objBackwardSliderData.dCurrentSpeed <= objForwardSliderData.dCurrentSpeed or objForwardSliderData.iState == STOP_VALUE:
                    # 「後方の現在位置」>「前方の現在位置」か判定：分岐範囲
                    if objBackwardSliderData.dCurrentPosition > objForwardSliderData.dCurrentPosition:
                        # 「前方の現在位置（一時保存）」=「前方の現在位置」+「循環システム一周分の長さ」
                        dSliderSize = self._slider_data_manipulater.readSliderSize()
                        dOneLap = self._axis_data_manipulater.readOneLap(dSliderSize)
                        dTempForwarCurrentPosition = objForwardSliderData.dCurrentPosition + dOneLap
                        
                        # 「前方の最短停止位置（一時保存）」=「前方の最短停止位置」+「循環システム一周分の長さ」
                        dTempForwarShortestStopPosition = objForwardSliderData.dShortestStopPosition + dOneLap
                        
                        # 「前方の目標位置（一時保存）」=「前方の目標位置」+「循環システム一周分の長さ」
                        dTempForwarTargetPosition = objForwardSliderData.dTargetPosition + dOneLap
                    else:
                        # 「前方の現在位置（一時保存）」=「前方の現在位置」
                        dTempForwarCurrentPosition = objForwardSliderData.dCurrentPosition
                        
                        # 「前方の最短停止位置（一時保存）」=「前方の最短停止位置」
                        dTempForwarShortestStopPosition = objForwardSliderData.dShortestStopPosition
                        
                        # 「前方の目標位置（一時保存）」=「前方の目標位置」
                        dTempForwarTargetPosition = objForwardSliderData.dTargetPosition
                    
                    # 「前方の現在位置（一時保存）」>「前方の目標位置（一時保存）」か判定：分岐範囲
                    if dTempForwarCurrentPosition > dTempForwarTargetPosition:
                        # 「前方の目標位置（一時保存）」=「前方の目標位置（一時保存）」+「循環システム一周分の長さ」
                        dSliderSize = self._slider_data_manipulater.readSliderSize()
                        dOneLap = self._axis_data_manipulater.readOneLap(dSliderSize)
                        dTempForwarTargetPosition = dTempForwarTargetPosition + dOneLap
                        
                        # 「前方のオフセット目標位置」=「前方の目標位置（一時保存）」-「スライダサイズ」
                        dForwarOffsetTargetPosition = dTempForwarTargetPosition - dSliderSize
                    else:
                        # 「前方のオフセット目標位置」=「前方の目標位置（一時保存）」-「スライダサイズ」
                        dSliderSize = self._slider_data_manipulater.readSliderSize()
                        dForwarOffsetTargetPosition = dTempForwarTargetPosition - dSliderSize
                    
                    # 「前方の目標位置（一時保存）」<=「後方の最短停止位置」か判定：分岐範囲
                    if dTempForwarTargetPosition <= objBackwardSliderData.dShortestStopPosition:
                        # 「後方の現在位置」<「前方のオフセット目標位置」か判定：分岐範囲
                        if objBackwardSliderData.dCurrentPosition < dForwarOffsetTargetPosition:
                            # 「前方のオフセット目標位置」>「循環システム一周分の長さ」か判定：分岐範囲
                            dSliderSize = self._slider_data_manipulater.readSliderSize()
                            dOneLap = self._axis_data_manipulater.readOneLap(dSliderSize)
                            if dForwarOffsetTargetPosition > dOneLap:
                                # 「前方のオフセット目標位置」=「前方のオフセット目標位置」-「循環システム一周分の長さ」
                                dForwarOffsetTargetPosition = dForwarOffsetTargetPosition - dOneLap
                            
                            # 「後方の目標位置」=「前方のオフセット目標位置」
                            objBackwardSliderData.dTargetPosition = dForwarOffsetTargetPosition
                            
                            # 「衝突判定結果」= 1
                            dCollisionDeterminationResult = COLLISION
                        else:
                            # 「後方の目標位置」=「後方の現在位置」
                            objBackwardSliderData.dTargetPosition = objBackwardSliderData.dCurrentPosition
                            
                            # 「衝突判定結果」= 1
                            dCollisionDeterminationResult = COLLISION
                    else:
                        # 「後方の現在位置」>「後方の最短停止位置」か判定：分岐範囲
                        if objBackwardSliderData.dCurrentPosition > objBackwardSliderData.dShortestStopPosition:
                            # 「後方の最短停止位置（一時保存）」=「後方の最短停止位置」+「循環システム一周分の長さ」
                            dSliderSize = self._slider_data_manipulater.readSliderSize()
                            dOneLap = self._axis_data_manipulater.readOneLap(dSliderSize)
                            dTempBackwardShortestStopPosition = objBackwardSliderData.dShortestStopPosition + dOneLap
                        else:
                            # 「後方の最短停止位置（一時保存）」=「後方の最短停止位置」
                            dTempBackwardShortestStopPosition = objBackwardSliderData.dShortestStopPosition
                        
                        # 「後方のオフセット最短停止位置」=「後方の最短停止位置（一時保存）」+「スライダサイズ」
                        dSliderSize = self._slider_data_manipulater.readSliderSize()
                        dBackwardOffsetShortestStopPosition = dTempBackwardShortestStopPosition + dSliderSize
                        
                        # 「前方の現在位置（一時保存）」<「後方のオフセット最短停止位置」か判定：分岐範囲
                        if dTempForwarCurrentPosition < dBackwardOffsetShortestStopPosition:
                            # 「循環システム一周分の長さ」<=「前方の現在位置（一時保存）」か判定：分岐範囲
                            dOneLap = self._axis_data_manipulater.readOneLap(dSliderSize)
                            if dOneLap <= dTempForwarCurrentPosition:
                                # 「前方の現在位置（一時保存）」=「前方の現在位置（一時保存）」-「循環システム一周分の長さ」
                                dTempForwarCurrentPosition = dTempForwarCurrentPosition - dOneLap
                            
                            # 「後方の目標位置」=「前方の現在位置（一時保存）」-「スライダサイズ」
                            objBackwardSliderData.dTargetPosition = dTempForwarCurrentPosition - dSliderSize
                            
                            # 「衝突判定結果」= 1
                            dCollisionDeterminationResult = COLLISION
            
            # 返り値=「衝突判定結果」
            return dCollisionDeterminationResult
            
        except Exception as e:
            print(f"{MODULE_NAME_COLLISION_DETECTER}.settingTargetPosition: Error - {e}")
            return NO_COLLISION
