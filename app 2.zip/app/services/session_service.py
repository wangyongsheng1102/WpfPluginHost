"""
セッションサービス（多ステップフローの一時データ管理）
"""
import uuid
from sqlalchemy.orm import Session
from sqlalchemy import and_
from typing import Optional, Dict, Any, List
from datetime import datetime, timedelta
from app.models.session import Session as SessionModel
from app.models.vts import MUser
from app.core.config import settings
from app.core.errors import ErrorCode
from app.core.exceptions import THKUnifiedUserAPIError


class SessionService:
    """セッションビジネスロジックサービス"""
    
    @staticmethod
    def generate_session_id() -> str:
        """セッションIDを生成"""
        return f"SESS-{uuid.uuid4().hex[:12].upper()}"
    
    @staticmethod
    def create_session(
        db: Session,
        user: Optional[MUser] = None,
        context: Optional[str] = None,
        language: str = "ja"
    ) -> SessionModel:
        """新しいセッションを作成"""
        session_id = SessionService.generate_session_id()
        
        # 有効期限を設定（デフォルト24時間）
        from datetime import timezone
        expires_at = datetime.now(timezone.utc) + timedelta(hours=settings.SESSION_EXPIRE_HOURS)
        
        session = SessionModel(
            session_id=session_id,
            user_id=user.user_id if user else None,
            context=context,
            language=language,
            step_data={},
            current_step=1,
            completed_steps=[],
            expires_at=expires_at
        )
        
        db.add(session)
        db.commit()
        db.refresh(session)
        return session
    
    @staticmethod
    def get_session(
        db: Session,
        session_id: str,
        user: Optional[MUser] = None,
        require_ownership: bool = False
    ) -> Optional[SessionModel]:
        """
        セッションを取得（有効期限チェック付き）
        
        Args:
            db: データベースセッション
            session_id: セッションID
            user: m_user（オプション）
            require_ownership: Trueの場合、ユーザーが指定されている場合は所有権を要求
        
        Returns:
            SessionModelまたはNone
        """
        session = db.query(SessionModel).filter(
            SessionModel.session_id == session_id
        ).first()
        
        if not session:
            return None
        
        # 有効期限チェック
        if session.is_expired():
            db.delete(session)
            db.commit()
            return None
        
        # ユーザー認証チェック（session.user_id は m_user.user_id 文字列）
        if user:
            if session.user_id:
                if session.user_id != user.user_id:
                    return None  # 他のユーザーのセッションにはアクセス不可
            elif require_ownership:
                return None
        else:
            if session.user_id:
                return None  # ログインユーザーのセッションにはアクセス不可
        
        return session
    
    @staticmethod
    def update_step_data(
        db: Session,
        session_id: str,
        step: int,
        step_type: str,
        content: Dict[str, Any],
        metadata: Optional[Dict[str, Any]] = None,
        mark_completed: bool = False,
        user: Optional[MUser] = None
    ) -> SessionModel:
        """ステップデータを更新（タイプと内容を含む）"""
        from datetime import timezone
        session = SessionService.get_session(db, session_id, user)
        
        if not session:
            raise THKUnifiedUserAPIError(
                ErrorCode.SESSION_NOT_FOUND,
                "セッションが見つかりませんまたは期限切れです"
            )
        
        # ステップデータを更新
        step_data = session.step_data.copy() if session.step_data else {}
        now = datetime.now(timezone.utc)
        
        # ステップ情報を構築
        step_info = {
            "step_type": step_type,
            "content": content,
            "updated_at": now.isoformat()
        }
        
        if metadata:
            step_info["metadata"] = metadata
        
        # 完了マーク
        if mark_completed:
            step_info["completed_at"] = now.isoformat()
            completed_steps = list(session.completed_steps) if session.completed_steps else []
            if step not in completed_steps:
                completed_steps.append(step)
                completed_steps.sort()
            session.completed_steps = completed_steps
        
        step_data[step] = step_info
        session.step_data = step_data
        
        # 現在のステップを更新
        if step > session.current_step:
            session.current_step = step
        
        # 有効期限を延長
        session.update_expiry()
        
        db.commit()
        db.refresh(session)
        return session
    
    @staticmethod
    def proceed_to_step(
        db: Session,
        session_id: str,
        target_step: int,
        user: Optional[MUser] = None
    ) -> SessionModel:
        """指定されたステップに進む（ステップ検証付き）"""
        session = SessionService.get_session(db, session_id, user)
        
        if not session:
            raise THKUnifiedUserAPIError(
                ErrorCode.SESSION_NOT_FOUND,
                "セッションが見つかりませんまたは期限切れです"
            )
        
        # ステップ検証：前のステップが完了しているかチェック
        if target_step > 1:
            completed_steps = session.completed_steps or []
            for step in range(1, target_step):
                if step not in completed_steps:
                    raise THKUnifiedUserAPIError(
                        ErrorCode.SESSION_STEP_NOT_COMPLETED,
                        f"ステップ{step}を先に完了する必要があります"
                    )
        
        # 現在のステップを更新
        if target_step > session.current_step:
            session.current_step = target_step
        
        # 有効期限を延長
        session.update_expiry()
        
        db.commit()
        db.refresh(session)
        return session
    
    @staticmethod
    def get_step_data(
        db: Session,
        session_id: str,
        step: Optional[int] = None,
        step_type: Optional[str] = None,
        user: Optional[MUser] = None
    ) -> Dict[str, Any]:
        """ステップデータを取得"""
        session = SessionService.get_session(db, session_id, user)
        
        if not session:
            raise THKUnifiedUserAPIError(
                ErrorCode.SESSION_NOT_FOUND,
                "セッションが見つかりませんまたは期限切れです"
            )
        
        step_data = session.step_data or {}
        
        if step_type:
            # タイプでフィルタリング
            filtered_data = {}
            for step_num, step_info in step_data.items():
                if isinstance(step_info, dict) and step_info.get("step_type") == step_type:
                    filtered_data[step_num] = step_info
            return filtered_data
        
        if step is None:
            # 全ステップデータを返す
            return step_data
        else:
            # 指定されたステップのデータを返す
            return step_data.get(step, {})
    
    @staticmethod
    def get_steps_by_type(
        db: Session,
        session_id: str,
        step_type: str,
        user: Optional[MUser] = None
    ) -> Dict[int, Dict[str, Any]]:
        """指定されたタイプのステップを取得"""
        session = SessionService.get_session(db, session_id, user)
        
        if not session:
            raise THKUnifiedUserAPIError(
                ErrorCode.SESSION_NOT_FOUND,
                "セッションが見つかりませんまたは期限切れです"
            )
        
        return session.get_steps_by_type(step_type)
    
    @staticmethod
    def delete_session(
        db: Session,
        session_id: str,
        user: Optional[MUser] = None
    ) -> bool:
        """セッションを削除"""
        session = SessionService.get_session(db, session_id, user)
        
        if not session:
            return False
        
        db.delete(session)
        db.commit()
        return True
    
    @staticmethod
    def associate_session_to_user(
        db: Session,
        session_id: str,
        user: MUser
    ) -> SessionModel:
        """
        セッションをユーザーに紐づける（未ログイン時に作成されたセッションをログイン後に紐づける）
        
        Args:
            db: データベースセッション
            session_id: セッションID
            user: m_user
        
        Returns:
            SessionModel
        
        Raises:
            THKUnifiedUserAPIError: セッションが見つからない、または既に他のユーザーに紐づいている場合
        """
        session = db.query(SessionModel).filter(
            SessionModel.session_id == session_id
        ).first()
        
        if not session:
            raise THKUnifiedUserAPIError(
                ErrorCode.SESSION_NOT_FOUND,
                "セッションが見つかりません"
            )
        
        # 既に他のユーザーに紐づいている場合はエラー
        if session.user_id and session.user_id != user.user_id:
            raise THKUnifiedUserAPIError(
                ErrorCode.SESSION_INVALID,
                "このセッションは他のユーザーに紐づいています"
            )
        
        # ユーザーに紐づける
        if not session.user_id:
            session.user_id = user.user_id
            db.commit()
            db.refresh(session)
        
        return session
    
    @staticmethod
    def get_user_sessions(
        db: Session,
        user: MUser,
        context: Optional[str] = None,
        include_expired: bool = False
    ) -> List[SessionModel]:
        """
        ユーザーのセッション一覧を取得
        
        Args:
            db: データベースセッション
            user: m_user
            context: コンテキストでフィルタリング（オプション）
            include_expired: 期限切れセッションを含めるか
        
        Returns:
            SessionModelのリスト
        """
        query = db.query(SessionModel).filter(
            SessionModel.user_id == user.user_id
        )
        
        if context:
            query = query.filter(SessionModel.context == context)
        
        if not include_expired:
            from datetime import timezone
            now = datetime.now(timezone.utc)
            query = query.filter(SessionModel.expires_at > now)
        
        return query.order_by(SessionModel.created_at.desc()).all()
    
    @staticmethod
    def cleanup_expired_sessions(db: Session) -> int:
        """期限切れセッションをクリーンアップ"""
        from datetime import timezone
        now = datetime.now(timezone.utc)
        expired_sessions = db.query(SessionModel).filter(
            SessionModel.expires_at < now
        ).all()
        
        count = len(expired_sessions)
        for session in expired_sessions:
            db.delete(session)
        
        db.commit()
        return count
