"""
VTS Configurator サービス: 画面 context 取得と Project/Layout/Process/ProductList/CTLog CRUD
"""
import csv
import io
from datetime import datetime, timezone
from typing import Optional, List
from sqlalchemy.orm import Session, joinedload
from sqlalchemy import func, and_, case
from sqlalchemy.exc import IntegrityError

from app.core.db_integrity import integrity_error_to_app_exception
from app.core.exceptions import (
    BaseAppException,
    ProjectNameDuplicateError,
    ProjectNameEmptyError,
    ProjectNotFoundError,
    LayoutNotFoundError,
    LayoutNameEmptyError,
    LayoutNameTooLongError,
    LayoutDesignNotFoundError,
    ProcessNotFoundError,
    ProcessDuplicateError,
    ProcessNameEmptyError,
    ProcessNameTooLongError,
    ProductListItemNotFoundError,
    ProductListDuplicateError,
    ProductNotFoundError,
    CTLogNotFoundError,
    CTLogDetailDuplicateError,
    CTLogNameEmptyError,
    CTLogNameTooLongError,
    DesignerContextNotFoundError,
    CycleTimeContextNotFoundError,
    CompareContextNotFoundError,
)

from app.models.vts import (
    Project,
    Layout,
    LayoutDesign,
    Process,
    ProductList,
    CTLogHeader,
    CTLogDetail,
    MProduct,
    MPrdUserUnique,
)
from app.schemas.vts import (
    ProjectCreate,
    ProjectUpdate,
    LayoutCreate,
    LayoutUpdate,
    LayoutDesignUpdate,
    ProcessCreate,
    ProcessUpdate,
    ProductListItemCreate,
    ProductListItemUpdate,
    CTLogCreate,
    CTLogUpdate,
    CTLogDetailCreate,
    Step5SaveRequest,
    LayoutUniqueCreateRequest,
)


def _project_response(p: Project):
    from app.schemas.vts import ProjectResponse
    return ProjectResponse(
        project_id=p.project_id,
        project_name=p.project_name,
        del_flg=p.del_flg or False,
        create_date=p.create_date,
        create_user=p.create_user,
        update_date=p.update_date,
        update_user=p.update_user,
    )


def _layout_response(l: Layout):
    from app.schemas.vts import LayoutResponse
    return LayoutResponse(
        project_id=l.project_id,
        layout_id=l.layout_id,
        vts_return_trip=l.vts_return_trip,
        circulation_type=l.circulation_type,
        module_direction=l.module_direction,
        footprint_limit_x=l.footprint_limit_x,
        footprint_limit_y=l.footprint_limit_y,
        footprint_limit_z=l.footprint_limit_z,
        work_name=l.work_name,
        work_size_w=l.work_size_w,
        work_size_l=l.work_size_l,
        work_size_d=l.work_size_d,
        work_mass=l.work_mass,
        work_products_per_pallet=l.work_products_per_pallet,
        pallet_w=l.pallet_w,
        pallet_l=l.pallet_l,
        pallet_d=l.pallet_d,
        pallet_mass=l.pallet_mass,
        slider_type=l.slider_type,

        process_distance_type=l.process_distance_type,
        circulation_axis_full_length=l.circulation_axis_full_length,
        circulation_axis_offset=l.circulation_axis_offset,
        circulation_axis_speed=l.circulation_axis_speed,
        circulation_axis_acceleration=l.circulation_axis_acceleration,
        circulation_axis_sensor=l.circulation_axis_sensor,
        circulation_axis_lead=l.circulation_axis_lead,
        circulation_name=l.circulation_name,
        circulation_type_attr=l.circulation_type_attr,
        circulation_guide=l.circulation_guide,
        circulation_stroke=l.circulation_stroke,
        circulation_motor_set_direction=l.circulation_motor_set_direction,
        eor_speed=l.eor_speed,
        eor_acceleration=l.eor_acceleration,
        control_controller_pattern=l.control_controller_pattern,
        finish_flg=l.finish_flg,
        position_or_distance=l.position_or_distance,
        vts_total_length=l.vts_total_length,
        module_count=l.module_count,

        del_flg=l.del_flg or False,
        create_date=l.create_date,
        create_user=l.create_user,
        update_date=l.update_date,
        update_user=l.update_user,
    )


def _layout_design_response(d: LayoutDesign):
    from app.schemas.vts import LayoutDesignResponse
    return LayoutDesignResponse(
        project_id=d.project_id,
        layout_id=d.layout_id,
        layout_design=d.layout_design,
        layout_image=d.layout_image,
        del_flg=d.del_flg or False,
        create_date=d.create_date,
        create_user=d.create_user,
        update_date=d.update_date,
        update_user=d.update_user,
    )


def _process_response(p: Process):
    from app.schemas.vts import ProcessResponse
    return ProcessResponse(
        project_id=p.project_id,
        layout_id=p.layout_id,
        process_no=p.process_no,
        truck_no=p.truck_no,
        log_no=p.log_no,
        process_name=p.process_name,
        process_time=p.process_time,
        process_time_tolerance=p.process_time_tolerance,
        settling_time=p.settling_time,
        process_stop_position=p.process_stop_position,
        process_forbidden_area=p.process_forbidden_area,
        move_to_process_speed=p.move_to_process_speed,
        move_to_process_accel=p.move_to_process_accel,
        ct_check_result=p.ct_check_result,
        wait_time=p.wait_time,
        vts_move_time=p.vts_move_time,
        del_flg=p.del_flg or False,
        create_date=p.create_date,
        create_user=p.create_user,
        update_date=p.update_date,
        update_user=p.update_user,
    )


def _product_list_response(p: ProductList):
    from app.schemas.vts import ProductListItemResponse
    return ProductListItemResponse(
        project_id=p.project_id,
        layout_id=p.layout_id,
        product_id=p.product_id,
        quantity=p.quantity or 1,
        cable_no=p.cable_no,
        del_flg=p.del_flg or False,
        create_date=p.create_date,
        create_user=p.create_user,
        update_date=p.update_date,
        update_user=p.update_user,
    )


def _ct_log_response(c: CTLogHeader):
    from app.schemas.vts import CTLogResponse
    return CTLogResponse(
        project_id=c.project_id,
        layout_id=c.layout_id,
        log_no=c.log_no,
        target_cycle_time=c.target_cycle_time,
        target_throughput=c.target_throughput,
        calculation_range=c.calculation_range,
        slider_count=c.slider_count,
        expected_ct=c.expected_ct,
        expected_throughput=c.expected_throughput,
        expected_time_efficiency=c.expected_time_efficiency,
        record_flg=c.record_flg,
        ct_result_image=c.ct_result_image,
        del_flg=c.del_flg or False,
        create_date=c.create_date,
        create_user=c.create_user,
        update_date=c.update_date,
        update_user=c.update_user,
    )


def _ct_log_detail_response(d: CTLogDetail):
    from app.schemas.vts import CTLogDetailResponse
    return CTLogDetailResponse(
        project_id=d.project_id,
        layout_id=d.layout_id,
        log_no=d.log_no,
        log_detail_no=d.log_detail_no,
        log_detail_name=d.log_detail_name,
        log_detail_value=d.log_detail_value,
        del_flg=d.del_flg or False,
        create_date=d.create_date,
        create_user=d.create_user,
        update_date=d.update_date,
        update_user=d.update_user,
    )


# ---------- Home context ----------
def get_home_context(db: Session, create_user: str) -> List:
    q = db.query(Project).filter(Project.del_flg == False, Project.create_user == create_user)
    projects = q.all()
    return [_project_response(p) for p in projects]


# ---------- Designer Step contexts ----------
def get_designer_step1_context(db: Session, create_user: str, project_id: Optional[int] = None):
    from app.schemas.vts import DesignerStep1ContextResponse
    if project_id is None:
        return DesignerStep1ContextResponse(project=None, layouts=[])
    project = db.query(Project).filter(Project.project_id == project_id, Project.del_flg == False, Project.create_user == create_user).first()
    if not project:
        return DesignerStep1ContextResponse(project=None, layouts=[])
    layouts = db.query(Layout).filter(
        Layout.project_id == project_id,
        Layout.del_flg == False
    ).all()
    return DesignerStep1ContextResponse(
        project=_project_response(project),
        layouts=[_layout_response(l) for l in layouts],
    )


def get_designer_step2_context(db: Session, create_user: str, project_id: int, layout_id: int):
    """デザイナー STEP2 コンテキストを取得。プロジェクトまたはレイアウトが見つからない場合は例外を発生"""
    from app.schemas.vts import DesignerStep2ContextResponse
    project = db.query(Project).filter(Project.project_id == project_id, Project.del_flg == False, Project.create_user == create_user).first()
    if not project:
        raise ProjectNotFoundError()
    layout = db.query(Layout).filter(
        Layout.project_id == project_id,
        Layout.layout_id == layout_id,
        Layout.del_flg == False,
    ).first()
    if not layout:
        raise LayoutNotFoundError()
    return DesignerStep2ContextResponse(
        project=_project_response(project),
        layout=_layout_response(layout),
    )


def get_designer_step3_context(db: Session, create_user: str, project_id: int, layout_id: int):
    """デザイナー STEP3 コンテキストを取得。プロジェクトまたはレイアウトが見つからない場合は例外を発生"""
    from app.schemas.vts import DesignerStep3ContextResponse
    project = db.query(Project).filter(Project.project_id == project_id, Project.del_flg == False, Project.create_user == create_user).first()
    if not project:
        raise ProjectNotFoundError()
    layout = db.query(Layout).filter(
        Layout.project_id == project_id,
        Layout.layout_id == layout_id,
        Layout.del_flg == False,
    ).first()
    if not layout:
        raise LayoutNotFoundError()
    processes = db.query(Process).filter(
        Process.project_id == project_id,
        Process.layout_id == layout_id,
        Process.del_flg == False,
    ).all()
    return DesignerStep3ContextResponse(
        project=_project_response(project),
        layout=_layout_response(layout),
        processes=[_process_response(p) for p in processes],
    )


def get_designer_step3_4_context(db: Session, create_user: str, project_id: int, layout_id: int):
    """STEP3/4 統合コンテキスト（STEP3 と STEP4 は画面上で統合された1ステップ）。プロジェクトまたはレイアウトが見つからない場合は例外を発生"""
    from app.schemas.vts import DesignerStep3_4ContextResponse
    project = db.query(Project).filter(Project.project_id == project_id, Project.del_flg == False, Project.create_user == create_user).first()
    if not project:
        raise ProjectNotFoundError()
    layout = db.query(Layout).filter(
        Layout.project_id == project_id,
        Layout.layout_id == layout_id,
        Layout.del_flg == False,
    ).first()
    if not layout:
        raise LayoutNotFoundError()
    design = db.query(LayoutDesign).filter(
        LayoutDesign.project_id == project_id,
        LayoutDesign.layout_id == layout_id,
        LayoutDesign.del_flg == False,
    ).first()
    processes = db.query(Process).filter(
        Process.project_id == project_id,
        Process.layout_id == layout_id,
        Process.del_flg == False,
    ).all()
    return DesignerStep3_4ContextResponse(
        project=_project_response(project),
        layout=_layout_response(layout),
        layout_design=_layout_design_response(design) if design else None,
        processes=[_process_response(p) for p in processes],
    )


def get_designer_step4_context(db: Session, create_user: str, project_id: int, layout_id: int):
    """STEP4 コンテキスト（後方互換性のため、内部で step3-4 を呼び出し）。プロジェクトまたはレイアウトが見つからない場合は例外を発生"""
    from app.schemas.vts import DesignerStep4ContextResponse
    ctx = get_designer_step3_4_context(db, create_user, project_id, layout_id)
    # DesignerStep4ContextResponse に変換（構造は同じ）
    return DesignerStep4ContextResponse(
        project=ctx.project,
        layout=ctx.layout,
        layout_design=ctx.layout_design,
        processes=ctx.processes,
    )


def get_designer_step5_context(db: Session, create_user: str, project_id: int, layout_id: int):
    """デザイナー STEP5 コンテキストを取得。プロジェクトまたはレイアウトが見つからない場合は例外を発生"""
    from app.schemas.vts import DesignerStep5ContextResponse
    project = db.query(Project).filter(Project.project_id == project_id, Project.del_flg == False, Project.create_user == create_user).first()
    if not project:
        raise ProjectNotFoundError()
    layout = db.query(Layout).filter(
        Layout.project_id == project_id,
        Layout.layout_id == layout_id,
        Layout.del_flg == False,
    ).first()
    if not layout:
        raise LayoutNotFoundError()
    design = db.query(LayoutDesign).filter(
        LayoutDesign.project_id == project_id,
        LayoutDesign.layout_id == layout_id,
        LayoutDesign.del_flg == False,
    ).first()
    items = db.query(ProductList).filter(
        ProductList.project_id == project_id,
        ProductList.layout_id == layout_id,
        ProductList.del_flg == False,
    ).order_by(ProductList.product_id).all()
    return DesignerStep5ContextResponse(
        project=_project_response(project),
        layout=_layout_response(layout),
        layout_design=_layout_design_response(design) if design else None,
        product_list=[_product_list_response(i) for i in items],
    )


# ---------- Cycle-time Step contexts ----------
def get_cycle_time_step1_context(db: Session, create_user: str, project_id: int):
    """サイクルタイム STEP1 コンテキストを取得。プロジェクトが見つからない場合は ProjectNotFoundError を発生"""
    from app.schemas.vts import CycleTimeStep1ContextResponse
    project = db.query(Project).filter(Project.project_id == project_id, Project.del_flg == False, Project.create_user == create_user).first()
    if not project:
        raise ProjectNotFoundError()
    layouts = db.query(Layout).filter(
        Layout.project_id == project_id,
        Layout.del_flg == False,
    ).all()
    return CycleTimeStep1ContextResponse(
        project=_project_response(project),
        layouts=[_layout_response(l) for l in layouts],
    )


def get_cycle_time_step2_context(db: Session, create_user: str, project_id: int, layout_id: int):
    """サイクルタイム STEP2 コンテキストを取得。プロジェクトまたはレイアウトが見つからない場合は例外を発生"""
    from app.schemas.vts import CycleTimeStep2ContextResponse
    project = db.query(Project).filter(Project.project_id == project_id, Project.del_flg == False, Project.create_user == create_user).first()
    if not project:
        raise ProjectNotFoundError()
    layout = db.query(Layout).filter(
        Layout.project_id == project_id,
        Layout.layout_id == layout_id,
        Layout.del_flg == False,
    ).first()
    if not layout:
        raise LayoutNotFoundError()
    processes = db.query(Process).filter(
        Process.project_id == project_id,
        Process.layout_id == layout_id,
        Process.del_flg == False,
    ).all()
    return CycleTimeStep2ContextResponse(
        project=_project_response(project),
        layout=_layout_response(layout),
        processes=[_process_response(p) for p in processes],
    )


def get_cycle_time_step3_context(db: Session, create_user: str, project_id: int, layout_id: int):
    """サイクルタイム STEP3 コンテキストを取得。プロジェクトまたはレイアウトが見つからない場合は例外を発生"""
    from app.schemas.vts import CycleTimeStep3ContextResponse
    project = db.query(Project).filter(Project.project_id == project_id, Project.del_flg == False, Project.create_user == create_user).first()
    if not project:
        raise ProjectNotFoundError()
    layout = db.query(Layout).filter(
        Layout.project_id == project_id,
        Layout.layout_id == layout_id,
        Layout.del_flg == False,
    ).first()
    if not layout:
        raise LayoutNotFoundError()
    logs = db.query(CTLogHeader).filter(
        CTLogHeader.project_id == project_id,
        CTLogHeader.layout_id == layout_id,
        CTLogHeader.del_flg == False,
    ).order_by(CTLogHeader.log_no).all()
    return CycleTimeStep3ContextResponse(
        project=_project_response(project),
        layout=_layout_response(layout),
        ct_logs=[_ct_log_response(c) for c in logs],
    )


# ---------- Compare context ----------
def get_compare_context(db: Session, create_user: str, project_id: int, layout_id: Optional[int] = None):
    """比較コンテキストを取得。プロジェクトが見つからない場合は ProjectNotFoundError を発生"""
    from app.schemas.vts import CompareContextResponse
    project = db.query(Project).filter(Project.project_id == project_id, Project.del_flg == False, Project.create_user == create_user).first()
    if not project:
        raise ProjectNotFoundError()
    layouts = db.query(Layout).filter(
        Layout.project_id == project_id,
        Layout.del_flg == False,
    ).all()
    ct_logs = None
    if layout_id is not None:
        logs = db.query(CTLogHeader).filter(
            CTLogHeader.project_id == project_id,
            CTLogHeader.layout_id == layout_id,
            CTLogHeader.del_flg == False,
        ).order_by(CTLogHeader.log_no).all()
        ct_logs = [_ct_log_response(c) for c in logs]
    return CompareContextResponse(
        project=_project_response(project),
        layouts=[_layout_response(l) for l in layouts],
        ct_logs=ct_logs,
    )


# ---------- Project CRUD ----------
def list_projects(
    db: Session,
    create_user: str,
    search: Optional[str] = None,
    limit: int = 50,
    offset: int = 0,
    sort_by: str = "update_date",
    order: str = "desc",
):
    """プロジェクト一覧（del_flg=False、ユーザー別）。search で project_name 曖昧検索、sort_by/order で並び替え、limit/offset でページング。"""
    limit = min(max(1, limit), 200)
    q = db.query(Project).filter(Project.del_flg == False, Project.create_user == create_user)
    if search and search.strip():
        q = q.filter(Project.project_name.ilike(f"%{search.strip()}%"))
    sort_column = {
        "create_date": Project.create_date,
        "update_date": Project.update_date,
        "project_name": Project.project_name,
    }.get(sort_by, Project.update_date)
    if order == "asc":
        q = q.order_by(sort_column.asc())
    else:
        q = q.order_by(sort_column.desc())
    rows = q.offset(offset).limit(limit).all()
    return [_project_response(p) for p in rows]


def delete_project(db: Session, create_user: str, project_id: int) -> None:
    """プロジェクトを論理削除（del_flg=True）。Layout/Process/CTLog は残し遡及可能。対象が存在しないか他ユーザーなら ProjectNotFoundError を発生。"""
    p = db.query(Project).filter(Project.project_id == project_id, Project.create_user == create_user).first()
    if not p:
        raise ProjectNotFoundError()
    p.del_flg = True
    p.update_user = create_user
    p.update_date = datetime.now(timezone.utc)
    try:
        db.commit()
    except IntegrityError as e:
        db.rollback()
        raise integrity_error_to_app_exception(e) from e


def get_project(db: Session, create_user: str, project_id: int):
    """プロジェクトを取得。見つからない場合は ProjectNotFoundError を発生"""
    p = db.query(Project).filter(Project.project_id == project_id, Project.del_flg == False, Project.create_user == create_user).first()
    if not p:
        raise ProjectNotFoundError()
    return _project_response(p)


def _is_project_name_duplicate_error(e: Exception) -> bool:
    """同一ユーザー内プロジェクト名一意制約違反かどうかを判定"""
    if not isinstance(e, IntegrityError):
        return False
    orig = getattr(e, "orig", None)
    if orig is None:
        return "idx_t_project_create_user_project_name_uniq" in str(e)
    if getattr(orig, "pgcode", None) != "23505":  # unique_violation
        return False
    msg = str(orig) + str(getattr(orig, "diag", "") or "")
    return "idx_t_project_create_user_project_name_uniq" in msg


def _is_process_pkey_duplicate_error(e: Exception) -> bool:
    """t_process 主キー重複（INSERT 時の一意制約違反）かどうかを判定"""
    if not isinstance(e, IntegrityError):
        return False
    orig = getattr(e, "orig", None)
    if orig is not None and getattr(orig, "pgcode", None) != "23505":
        return False
    msg = (str(orig) if orig is not None else str(e)).lower()
    return "t_process_pkey" in msg or ("t_process" in msg and "pkey" in msg)


def _is_product_list_pkey_duplicate_error(e: Exception) -> bool:
    """t_product_list 主キー重複かどうかを判定"""
    if not isinstance(e, IntegrityError):
        return False
    orig = getattr(e, "orig", None)
    if orig is not None and getattr(orig, "pgcode", None) != "23505":
        return False
    msg = (str(orig) if orig is not None else str(e)).lower()
    return "t_product_list_pkey" in msg or ("t_product_list" in msg and "pkey" in msg)


def _is_ct_log_detail_pkey_duplicate_error(e: Exception) -> bool:
    """t_ct_log_detail 主キー重複かどうかを判定"""
    if not isinstance(e, IntegrityError):
        return False
    orig = getattr(e, "orig", None)
    if orig is not None and getattr(orig, "pgcode", None) != "23505":
        return False
    msg = (str(orig) if orig is not None else str(e)).lower()
    return "t_ct_log_detail_pkey" in msg or ("t_ct_log_detail" in msg and "pkey" in msg)


def create_project(db: Session, create_user: str, data: ProjectCreate) -> Project:
    name = (data.project_name or "").strip()
    if not name:
        raise ProjectNameEmptyError("project_name cannot be empty or whitespace only")
    p = Project(
        project_name=name,
        del_flg=False,
        create_user=create_user,
        update_user=create_user,
    )
    db.add(p)
    try:
        db.commit()
        db.refresh(p)
        return p
    except IntegrityError as e:
        db.rollback()
        if _is_project_name_duplicate_error(e):
            raise ProjectNameDuplicateError("project name duplicate") from e
        raise integrity_error_to_app_exception(e) from e


def update_project(db: Session, create_user: str, project_id: int, data: ProjectUpdate, update_user: Optional[str] = None) -> Project:
    """プロジェクトを更新。見つからない場合は ProjectNotFoundError を発生"""
    p = db.query(Project).filter(Project.project_id == project_id, Project.create_user == create_user).first()
    if not p:
        raise ProjectNotFoundError()
    if data.project_name is not None:
        name = data.project_name.strip()
        if not name:
            raise ProjectNameEmptyError("project_name cannot be empty or whitespace only")
        p.project_name = name
    p.update_user = update_user
    p.update_date = datetime.now(timezone.utc)
    try:
        db.commit()
        db.refresh(p)
        return p
    except IntegrityError as e:
        db.rollback()
        if _is_project_name_duplicate_error(e):
            raise ProjectNameDuplicateError("project name duplicate") from e
        raise integrity_error_to_app_exception(e) from e


def copy_project(
    db: Session,
    create_user: str,
    source_project_id: int,
    new_project_name: Optional[str] = None,
) -> Project:
    """
    プロジェクトを複製する（Layout / LayoutDesign / Process / ProductList / CTLog をすべてコピー）。
    新規プロジェクトは create_user のものとして作成。存在しない or 他ユーザーなら ProjectNotFoundError を発生。
    """
    src_proj = db.query(Project).filter(
        Project.project_id == source_project_id,
        Project.del_flg == False,
        Project.create_user == create_user,
    ).first()
    if not src_proj:
        raise ProjectNotFoundError()
    name = (new_project_name or f"Copy of {src_proj.project_name}").strip() or "Copy of project"
    name = name[:255]  # DB制約のため255文字に切り詰め
    new_proj = Project(
        project_name=name,
        del_flg=False,
        create_user=create_user,
        update_user=create_user,
    )
    db.add(new_proj)
    try:
        db.flush()
    except IntegrityError as e:
        db.rollback()
        if _is_project_name_duplicate_error(e):
            raise ProjectNameDuplicateError("project name duplicate") from e
        raise integrity_error_to_app_exception(e) from e
    src_layouts = (
        db.query(Layout)
        .filter(Layout.project_id == source_project_id, Layout.del_flg == False)
        .order_by(Layout.layout_id)
        .all()
    )
    for src_layout in src_layouts:
        new_layout = Layout(
            project_id=new_proj.project_id,
            layout_id=_next_layout_id(db, new_proj.project_id),
            vts_return_trip=src_layout.vts_return_trip,
            circulation_type=src_layout.circulation_type,
            module_direction=src_layout.module_direction,
            footprint_limit_x=src_layout.footprint_limit_x,
            footprint_limit_y=src_layout.footprint_limit_y,
            footprint_limit_z=src_layout.footprint_limit_z,
            work_name=src_layout.work_name,
            work_size_w=src_layout.work_size_w,
            work_size_l=src_layout.work_size_l,
            work_size_d=src_layout.work_size_d,
            work_mass=src_layout.work_mass,
            work_products_per_pallet=src_layout.work_products_per_pallet,
            pallet_w=src_layout.pallet_w,
            pallet_l=src_layout.pallet_l,
            pallet_d=src_layout.pallet_d,
            pallet_mass=src_layout.pallet_mass,
            slider_type=src_layout.slider_type,
            process_distance_type=src_layout.process_distance_type,
            circulation_axis_full_length=src_layout.circulation_axis_full_length,
            circulation_axis_offset=src_layout.circulation_axis_offset,
            circulation_axis_speed=src_layout.circulation_axis_speed,
            circulation_axis_acceleration=src_layout.circulation_axis_acceleration,
            circulation_axis_sensor=src_layout.circulation_axis_sensor,
            circulation_axis_lead=src_layout.circulation_axis_lead,
            circulation_name=src_layout.circulation_name,
            circulation_type_attr=src_layout.circulation_type_attr,
            circulation_guide=src_layout.circulation_guide,
            circulation_stroke=src_layout.circulation_stroke,
            circulation_motor_set_direction=src_layout.circulation_motor_set_direction,
            eor_speed=src_layout.eor_speed,
            eor_acceleration=src_layout.eor_acceleration,
            control_controller_pattern=src_layout.control_controller_pattern,
            finish_flg=src_layout.finish_flg,
            position_or_distance=src_layout.position_or_distance,
            vts_total_length=src_layout.vts_total_length,
            module_count=src_layout.module_count,
            del_flg=False,
            create_user=create_user,
            update_user=create_user,
        )
        db.add(new_layout)
        try:
            db.flush()
        except IntegrityError as e:
            db.rollback()
            raise integrity_error_to_app_exception(e) from e
        src_design = (
            db.query(LayoutDesign)
            .filter(
                LayoutDesign.project_id == source_project_id,
                LayoutDesign.layout_id == src_layout.layout_id,
                LayoutDesign.del_flg == False,
            )
            .first()
        )
        if src_design:
            nd = LayoutDesign(
                project_id=new_proj.project_id,
                layout_id=new_layout.layout_id,
                layout_design=src_design.layout_design,
                layout_image=src_design.layout_image,
                del_flg=False,
                create_user=create_user,
                update_user=create_user,
            )
            db.add(nd)
        src_processes = (
            db.query(Process)
            .filter(
                Process.project_id == source_project_id,
                Process.layout_id == src_layout.layout_id,
                Process.del_flg == False,
            )
            .all()
        )
        for sp in src_processes:
            np = Process(
                project_id=new_proj.project_id,
                layout_id=new_layout.layout_id,
                process_no=sp.process_no,
                truck_no=sp.truck_no,
                log_no=sp.log_no,
                process_name=sp.process_name,
                process_time=sp.process_time,
                process_time_tolerance=sp.process_time_tolerance,
                settling_time=sp.settling_time,
                process_distance_type=sp.process_distance_type,
                process_distance=sp.process_distance,
                process_forbidden_area=sp.process_forbidden_area,
                circulation_axis_offset=sp.circulation_axis_offset,
                circulation_axis_speed=sp.circulation_axis_speed,
                circulation_axis_accel=sp.circulation_axis_accel,
                eject_or_load_speed=sp.eject_or_load_speed,
                eject_or_load_accel=sp.eject_or_load_accel,
                move_to_process_speed=sp.move_to_process_speed,
                move_to_process_accel=sp.move_to_process_accel,
                control_controller_pattern=sp.control_controller_pattern,
                del_flg=False,
                create_user=create_user,
                update_user=create_user,
            )
            db.add(np)
        src_items = (
            db.query(ProductList)
            .filter(
                ProductList.project_id == source_project_id,
                ProductList.layout_id == src_layout.layout_id,
                ProductList.del_flg == False,
            )
            .order_by(ProductList.product_id)
            .all()
        )
        for si in src_items:
            ni = ProductList(
                project_id=new_proj.project_id,
                layout_id=new_layout.layout_id,
                product_id=si.product_id,
                quantity=si.quantity or 1,
                cable_no=si.cable_no,
                del_flg=False,
                create_user=create_user,
                update_user=create_user,
            )
            db.add(ni)
        src_logs = (
            db.query(CTLogHeader)
            .filter(
                CTLogHeader.project_id == source_project_id,
                CTLogHeader.layout_id == src_layout.layout_id,
                CTLogHeader.del_flg == False,
            )
            .order_by(CTLogHeader.log_no)
            .all()
        )
        next_log = _next_log_no(db, new_proj.project_id, new_layout.layout_id)
        for sl in src_logs:
            nc = CTLogHeader(
                project_id=new_proj.project_id,
                layout_id=new_layout.layout_id,
                log_no=next_log,
                target_cycle_time=sl.target_cycle_time,
                target_throughput=sl.target_throughput,
                calculation_range=sl.calculation_range,
                slider_count=sl.slider_count,
                expected_ct=sl.expected_ct,
                expected_throughput=sl.expected_throughput,
                expected_time_efficiency=sl.expected_time_efficiency,
                record_flg=sl.record_flg,
                ct_result_image=sl.ct_result_image,
                del_flg=False,
                create_user=create_user,
                update_user=create_user,
            )
            db.add(nc)
            next_log += 1
    try:
        db.commit()
        db.refresh(new_proj)
    except IntegrityError as e:
        db.rollback()
        raise integrity_error_to_app_exception(e) from e
    return new_proj


# ---------- Layout CRUD ----------
def _next_layout_id(db: Session, project_id: int) -> int:
    r = db.query(func.coalesce(func.max(Layout.layout_id), 0) + 1).filter(Layout.project_id == project_id).scalar()
    return r or 1


def list_layouts(db: Session, create_user: str, project_id: int):
    # プロジェクトが現在のユーザーに属することを確認
    proj = db.query(Project).filter(Project.project_id == project_id, Project.create_user == create_user).first()
    if not proj:
        return []
    rows = db.query(Layout).filter(
        Layout.project_id == project_id,
        Layout.del_flg == False,
    ).all()
    return [_layout_response(l) for l in rows]


def get_layout(db: Session, create_user: str, project_id: int, layout_id: int):
    """レイアウトを取得。プロジェクトまたはレイアウトが見つからない場合は例外を発生"""
    # プロジェクトが現在のユーザーに属することを確認
    proj = db.query(Project).filter(Project.project_id == project_id, Project.create_user == create_user).first()
    if not proj:
        raise ProjectNotFoundError()
    l = db.query(Layout).filter(
        Layout.project_id == project_id,
        Layout.layout_id == layout_id,
        Layout.del_flg == False,
    ).first()
    if not l:
        raise LayoutNotFoundError()
    return _layout_response(l)


def create_layout(db: Session, create_user: str, project_id: int, data: LayoutCreate) -> Layout:
    """レイアウトを作成。プロジェクトが見つからない場合は ProjectNotFoundError"""
    proj = db.query(Project).filter(Project.project_id == project_id, Project.del_flg == False, Project.create_user == create_user).first()
    if not proj:
        raise ProjectNotFoundError()
    layout_id = _next_layout_id(db, project_id)
    payload = data.model_dump()
    payload.update(
        project_id=project_id,
        layout_id=layout_id,
        del_flg=False,
        create_user=create_user,
        update_user=create_user,
    )
    l = Layout(**payload)
    db.add(l)
    try:
        db.commit()
        db.refresh(l)
    except IntegrityError as e:
        db.rollback()
        raise integrity_error_to_app_exception(e) from e
    return l


def update_layout(db: Session, create_user: str, project_id: int, layout_id: int, data: LayoutUpdate, update_user: Optional[str] = None) -> Layout:
    """レイアウトを更新。プロジェクトまたはレイアウトが見つからない場合は例外を発生"""
    proj = db.query(Project).filter(Project.project_id == project_id, Project.create_user == create_user).first()
    if not proj:
        raise ProjectNotFoundError()
    l = db.query(Layout).filter(Layout.project_id == project_id, Layout.layout_id == layout_id).first()
    if not l:
        raise LayoutNotFoundError()
    payload = data.model_dump(exclude_unset=True)
    for k, v in payload.items():
        setattr(l, k, v)
    l.update_user = update_user
    l.update_date = datetime.now(timezone.utc)  # ORM の onupdate は「変更された列」にのみ発火するため、明示的に更新
    try:
        db.commit()
        db.refresh(l)
    except IntegrityError as e:
        db.rollback()
        raise integrity_error_to_app_exception(e) from e
    return l


# ---------- LayoutDesign ----------
def get_layout_design(db: Session, create_user: str, project_id: int, layout_id: int):
    """レイアウトデザインを取得。プロジェクトまたはレイアウトデザインが見つからない場合は例外を発生"""
    # プロジェクトが現在のユーザーに属することを確認
    proj = db.query(Project).filter(Project.project_id == project_id, Project.create_user == create_user).first()
    if not proj:
        raise ProjectNotFoundError()
    d = db.query(LayoutDesign).filter(
        LayoutDesign.project_id == project_id,
        LayoutDesign.layout_id == layout_id,
        LayoutDesign.del_flg == False,
    ).first()
    if not d:
        raise LayoutDesignNotFoundError()
    return _layout_design_response(d)


def upsert_layout_design(db: Session, create_user: str, project_id: int, layout_id: int, data: LayoutDesignUpdate, user: Optional[str] = None) -> LayoutDesign:
    """レイアウトデザインを upsert。プロジェクトまたはレイアウトが見つからない場合は例外を発生"""
    # プロジェクトが現在のユーザーに属することを確認
    proj = db.query(Project).filter(Project.project_id == project_id, Project.create_user == create_user).first()
    if not proj:
        raise ProjectNotFoundError()
    layout = db.query(Layout).filter(
        Layout.project_id == project_id,
        Layout.layout_id == layout_id,
        Layout.del_flg == False,
    ).first()
    if not layout:
        raise LayoutNotFoundError()
    d = db.query(LayoutDesign).filter(
        LayoutDesign.project_id == project_id,
        LayoutDesign.layout_id == layout_id,
    ).first()
    if d:
        if data.layout_design is not None:
            d.layout_design = data.layout_design
        if data.layout_image is not None:
            d.layout_image = data.layout_image
        d.update_user = user
        d.update_date = datetime.now(timezone.utc)
    else:
        d = LayoutDesign(
            project_id=project_id,
            layout_id=layout_id,
            layout_design=data.layout_design,
            layout_image=data.layout_image,
            del_flg=False,
            create_user=user,
            update_user=user,
        )
        db.add(d)
    try:
        db.commit()
        db.refresh(d)
    except IntegrityError as e:
        db.rollback()
        raise integrity_error_to_app_exception(e) from e
    return d


def save_step5(db: Session, create_user: str, data: Step5SaveRequest) -> dict:
    """
    STEP5 完成時の一括保存。ProductList と LayoutDesign をトランザクション内で一括更新。
    戻り値は `layout_design` と `product_list` を含む。
    プロジェクトまたはレイアウトが見つからない場合は例外を発生する。
    """
    from app.schemas.vts import Step5SaveResponse, LayoutDesignUpdate
    # プロジェクトが現在のユーザーに属することを確認
    proj = db.query(Project).filter(
        Project.project_id == data.project_id,
        Project.del_flg == False,
        Project.create_user == create_user,
    ).first()
    if not proj:
        raise ProjectNotFoundError()
    layout = db.query(Layout).filter(
        Layout.project_id == data.project_id,
        Layout.layout_id == data.layout_id,
        Layout.del_flg == False,
    ).first()
    if not layout:
        raise LayoutNotFoundError()
    try:
        # 1. この layout のすべての古い ProductList レコードを削除（物理削除、全量置換のため）
        db.query(ProductList).filter(
            ProductList.project_id == data.project_id,
            ProductList.layout_id == data.layout_id,
        ).delete()
        # 2. 新しい ProductList を一括挿入
        product_map = {}  # product_id -> MProduct、一括検索用
        product_ids = {item.product_id for item in data.product_list if item.product_id}
        if product_ids:
            products = db.query(MProduct).filter(
                MProduct.product_id.in_(product_ids),
                MProduct.del_flg == False,
            ).all()
            product_map = {p.product_id: p for p in products}
        new_items = []
        for item_data in data.product_list:
            product = product_map.get(item_data.product_id)
            if not product:
                continue  # 無効な product_id をスキップ
            quantity = item_data.quantity if item_data.quantity is not None and item_data.quantity >= 0 else 1
            new_item = ProductList(
                project_id=data.project_id,
                layout_id=data.layout_id,
                product_id=item_data.product_id,
                quantity=quantity,
                cable_no=item_data.cable_no,
                del_flg=False,
                create_user=create_user,
                update_user=create_user,
            )
            new_items.append(new_item)
        db.bulk_save_objects(new_items)
        # 3. LayoutDesign を Upsert（同一トランザクション内）
        design = db.query(LayoutDesign).filter(
            LayoutDesign.project_id == data.project_id,
            LayoutDesign.layout_id == data.layout_id,
        ).first()
        if design:
            if data.layout_design is not None:
                design.layout_design = data.layout_design
            if data.layout_image is not None:
                design.layout_image = data.layout_image
            design.update_user = create_user
            design.update_date = datetime.now(timezone.utc)
        else:
            design = LayoutDesign(
                project_id=data.project_id,
                layout_id=data.layout_id,
                layout_design=data.layout_design,
                layout_image=data.layout_image,
                del_flg=False,
                create_user=create_user,
                update_user=create_user,
            )
            db.add(design)
        try:
            db.commit()
            db.refresh(design)
        except IntegrityError as e:
            db.rollback()
            raise integrity_error_to_app_exception(e) from e
        # 4. 保存後のデータを返す
        saved_items = db.query(ProductList).filter(
            ProductList.project_id == data.project_id,
            ProductList.layout_id == data.layout_id,
            ProductList.del_flg == False,
        ).order_by(ProductList.product_id).all()
        return {
            "layout_design": _layout_design_response(design),
            "product_list": [_product_list_response(item) for item in saved_items],
        }
    except BaseAppException:
        raise
    except Exception:
        db.rollback()
        raise


def export_product_list_csv(db: Session, create_user: str, project_id: int, layout_id: int, language: str = "ja") -> io.BytesIO:
    """
    部品表をCSV形式でエクスポート。UTF-8 BOM付きでExcel互換。
    戻り値は CSV 内容を格納した `io.BytesIO` である。
    """
    # プロジェクトが現在のユーザーに属することを確認
    proj = db.query(Project).filter(
        Project.project_id == project_id,
        Project.del_flg == False,
        Project.create_user == create_user,
    ).first()
    if not proj:
        return None
    layout = db.query(Layout).filter(
        Layout.project_id == project_id,
        Layout.layout_id == layout_id,
        Layout.del_flg == False,
    ).first()
    if not layout:
        return None
    # ProductList を検索
    items = db.query(ProductList).filter(
        ProductList.project_id == project_id,
        ProductList.layout_id == layout_id,
        ProductList.del_flg == False,
    ).order_by(ProductList.product_id).all()
    # product_id から MProduct を取得して名称等を付与
    product_ids = [i.product_id for i in items]
    product_map = {}
    if product_ids:
        prods = db.query(MProduct).filter(MProduct.product_id.in_(product_ids)).all()
        product_map = {p.product_id: p for p in prods}
    from app.core.product_locale import resolve_product_name

    if language == "en":
        headers = ["Product ID", "Product Name", "Product Model", "Product Code", "Quantity", "Cable No"]
    else:
        headers = ["製品ID", "部品名称", "部品型番", "商品コード", "数量", "ケーブル番号"]
    import io as io_module
    string_buffer = io_module.StringIO()
    writer = csv.writer(string_buffer)
    writer.writerow(headers)
    for idx, item in enumerate(items, start=1):
        p = product_map.get(item.product_id)
        writer.writerow([
            item.product_id,
            resolve_product_name(p, language) if p else "",
            p.product_model if p else "",
            p.product_code if p else "",
            item.quantity or 0,
            item.cable_no or "",
        ])
    csv_content = string_buffer.getvalue()
    string_buffer.close()
    # UTF-8 BOM を追加して bytes にエンコード
    output = io.BytesIO()
    output.write("\ufeff".encode("utf-8"))  # UTF-8 BOM for Excel
    output.write(csv_content.encode("utf-8"))
    output.seek(0)
    return output


# ---------- Layout Unique (m_prd_user_unique) CRUD ----------
def _layout_unique_response(lu: MPrdUserUnique):
    from app.schemas.vts import LayoutUniqueResponse
    return LayoutUniqueResponse(
        layout_info_id=lu.layout_info_id,
        layout_info=lu.layout_info or {},
        layout_info_name=getattr(lu, "layout_info_name", None),
        min_cycle_time=getattr(lu, "min_cycle_time", None),
        layout_image=getattr(lu, "layout_image", None),
        del_flg=lu.del_flg or False,
        create_date=lu.create_date,
        create_user=lu.create_user,
        update_date=lu.update_date,
        update_user=lu.update_user,
    )


def layout_unique_response(lu: MPrdUserUnique):
    """公開用: LayoutUniqueResponse を返す"""
    return _layout_unique_response(lu)


def create_layout_unique(db: Session, create_user: str, data: LayoutUniqueCreateRequest) -> MPrdUserUnique:
    """ユーザーユニーク製品マスタにレイアウト情報を登録（m_prd_user_unique）"""
    layout_info = data.layout_info.copy() if data.layout_info else {}
    lu = MPrdUserUnique(
        layout_info_name=data.layout_info_name,
        layout_info=layout_info,
        min_cycle_time=data.min_cycle_time,
        layout_image=data.layout_image,
        del_flg=False,
        create_user=create_user,
        update_user=create_user,
    )
    db.add(lu)
    try:
        db.commit()
        db.refresh(lu)
    except IntegrityError as e:
        db.rollback()
        raise integrity_error_to_app_exception(e) from e
    return lu


def list_layout_uniques(db: Session, create_user: str) -> List[MPrdUserUnique]:
    """ユーザーが作成した layout unique 一覧"""
    rows = db.query(MPrdUserUnique).filter(
        MPrdUserUnique.create_user == create_user,
        MPrdUserUnique.del_flg == False,
    ).order_by(MPrdUserUnique.create_date.desc()).all()
    return rows


def list_layout_uniques_responses(db: Session, create_user: str):
    """STEP3/4 サイドバー用 layout unique 一覧（LayoutUniqueResponse のリスト）"""
    rows = list_layout_uniques(db, create_user)
    return [_layout_unique_response(lu) for lu in rows]


def _m_product_response(p: MProduct, language: str = "ja"):
    """MProduct を MProductResponse に変換（product_type_id で m_ProductType 参照）"""
    from app.core.product_locale import resolve_product_name, resolve_product_type_name
    from app.schemas.vts import MProductResponse
    return MProductResponse(
        product_id=p.product_id,
        product_name=resolve_product_name(p, language),
        product_name_en=(p.product_name_en.strip() if p.product_name_en else None),
        product_isome_image=p.product_isome_image,
        product_side_view_image=p.product_side_view_image,
        product_top_view_image=p.product_top_view_image,
        product_type_id=p.product_type_id,
        product_type_name=resolve_product_type_name(p.product_type_rel, language),
        product_type_name_en=(
            p.product_type_rel.product_type_name_en.strip()
            if p.product_type_rel and p.product_type_rel.product_type_name_en
            else None
        ),
        product_model=p.product_model,
        product_code=p.product_code,
        min_cycle_time=p.min_cycle_time,
        stroke=p.stroke,
        list_price=p.list_price,
    )


def list_sidebar_products(db: Session, category: str, language: str = "ja"):
    """
    STEP3/4 サイドバー用 m_product 一覧。
    category=module → product_type_id IN (1, 2, 3, 4)
    category=accessory → product_type_id = 11
    """
    query = (
        db.query(MProduct)
        .options(joinedload(MProduct.product_type_rel))
        .filter(MProduct.del_flg == False)
    )
    if category == "module":
        query = query.filter(MProduct.product_type_id.in_([1, 2, 3, 4]))
    elif category == "accessory":
        query = query.filter(MProduct.product_type_id == 11)
    rows = query.order_by(MProduct.product_code).all()
    return [_m_product_response(p, language) for p in rows]


def list_step5_sidebar_products(db: Session, category: str, language: str = "ja"):
    """
    STEP5 サイドバー用 m_product 一覧。
    controller_unique / controller → product_type_id IN (8, 9)
    cable → product_type_id IN (5, 6, 7)
    """
    query = (
        db.query(MProduct)
        .options(joinedload(MProduct.product_type_rel))
        .filter(MProduct.del_flg == False)
    )
    if category in ("controller_unique", "controller"):
        query = query.filter(MProduct.product_type_id.in_([8, 9]))
    elif category == "cable":
        query = query.filter(MProduct.product_type_id.in_([5, 6, 7]))
    rows = query.order_by(MProduct.product_code).all()
    return [_m_product_response(p, language) for p in rows]


def get_designer_sidebar_context(db: Session, create_user: str, project_id: int, layout_id: int):
    """
    STEP3/4 サイドバー用コンテキスト（axis + processes のみ）。
    layout_uniques は GET .../sidebar/layout-uniques、modules/アクセサリ は GET .../sidebar/products?category= で取得すること。
    """
    from app.schemas.vts import DesignerSidebarContextResponse
    proj = db.query(Project).filter(
        Project.project_id == project_id,
        Project.del_flg == False,
        Project.create_user == create_user,
    ).first()
    if not proj:
        raise ProjectNotFoundError()
    layout = db.query(Layout).filter(
        Layout.project_id == project_id,
        Layout.layout_id == layout_id,
        Layout.del_flg == False,
    ).first()
    if not layout:
        raise LayoutNotFoundError()
    processes = db.query(Process).filter(
        Process.project_id == project_id,
        Process.layout_id == layout_id,
        Process.del_flg == False,
    ).all()
    circulation_axis_config = None
    if processes:
        first_process = processes[0]
        circulation_axis_config = {
            "move_to_process_speed": float(first_process.move_to_process_speed) if first_process.move_to_process_speed is not None else None,
            "move_to_process_accel": float(first_process.move_to_process_accel) if first_process.move_to_process_accel is not None else None,
        }
    return DesignerSidebarContextResponse(
        layout_uniques=[],
        modules=[],
        circulation_axis_config=circulation_axis_config,
        processes=[_process_response(p) for p in processes],
    )


# ---------- Process CRUD ----------
def list_processes(db: Session, create_user: str, project_id: int, layout_id: int):
    # プロジェクトが現在のユーザーに属することを確認
    proj = db.query(Project).filter(Project.project_id == project_id, Project.create_user == create_user).first()
    if not proj:
        return []
    rows = db.query(Process).filter(
        Process.project_id == project_id,
        Process.layout_id == layout_id,
        Process.del_flg == False,
    ).all()
    return [_process_response(p) for p in rows]


def create_process(db: Session, create_user: str, project_id: int, layout_id: int, process_no: int, truck_no: int, log_no: int, data: ProcessCreate) -> Process:
    """プロセスを作成。process_no は path、truck_no / log_no は query で必須。プロジェクトまたはレイアウトが見つからない場合は例外を発生。process_name が空の場合は ProcessNameEmptyError を発生"""
    proj = db.query(Project).filter(Project.project_id == project_id, Project.create_user == create_user).first()
    if not proj:
        raise ProjectNotFoundError()
    layout = db.query(Layout).filter(
        Layout.project_id == project_id,
        Layout.layout_id == layout_id,
        Layout.del_flg == False,
    ).first()
    if not layout:
        raise LayoutNotFoundError()
    process_name_val = (data.process_name or "").strip()
    if not process_name_val:
        raise ProcessNameEmptyError("process_name cannot be empty or whitespace only")
    if len(process_name_val) > 30:
        raise ProcessNameTooLongError("process_name cannot exceed 30 characters")
    p = Process(
        project_id=project_id,
        layout_id=layout_id,
        process_no=process_no,
        truck_no=truck_no,
        log_no=log_no,
        process_name=process_name_val,
        process_time=data.process_time,
        process_time_tolerance=data.process_time_tolerance,
        settling_time=data.settling_time,
        process_stop_position=data.process_stop_position,
        process_forbidden_area=data.process_forbidden_area,
        move_to_process_speed=data.move_to_process_speed,
        move_to_process_accel=data.move_to_process_accel,
        ct_check_result=data.ct_check_result,
        wait_time=data.wait_time,
        vts_move_time=data.vts_move_time,
        del_flg=False,
        create_user=create_user,
        update_user=create_user,
    )
    db.add(p)
    try:
        db.commit()
        db.refresh(p)
    except IntegrityError as e:
        db.rollback()
        if _is_process_pkey_duplicate_error(e):
            raise ProcessDuplicateError("process duplicate key") from e
        raise integrity_error_to_app_exception(e) from e

    return p


def update_process(db: Session, create_user: str, project_id: int, layout_id: int, process_no: int, truck_no: int, log_no: int, data: ProcessUpdate, update_user: Optional[str] = None) -> Process:
    """プロセスを更新。プロジェクトまたはプロセスが見つからない場合は例外を発生"""
    proj = db.query(Project).filter(Project.project_id == project_id, Project.create_user == create_user).first()
    if not proj:
        raise ProjectNotFoundError()
    p = db.query(Process).filter(
        Process.project_id == project_id,
        Process.layout_id == layout_id,
        Process.process_no == process_no,
        Process.truck_no == truck_no,
        Process.log_no == log_no,
    ).first()
    if not p:
        raise ProcessNotFoundError()
    payload = data.model_dump(exclude_unset=True)
    if "process_name" in payload and payload["process_name"] is not None:
        name_val = (payload["process_name"] or "").strip()
        if not name_val:
            raise ProcessNameEmptyError("process_name cannot be empty or whitespace only")
        if len(name_val) > 30:
            raise ProcessNameTooLongError("process_name cannot exceed 30 characters")
        payload["process_name"] = name_val
    for k, v in payload.items():
        setattr(p, k, v)
    p.update_user = update_user
    p.update_date = datetime.now(timezone.utc)
    try:
        db.commit()
        db.refresh(p)
    except IntegrityError as e:
        db.rollback()
        raise integrity_error_to_app_exception(e) from e
    return p


def delete_process(db: Session, create_user: str, project_id: int, layout_id: int, process_no: int, truck_no: int, log_no: int) -> None:
    """プロセスを削除。プロジェクトまたはプロセスが見つからない場合は例外を発生。"""
    proj = db.query(Project).filter(Project.project_id == project_id, Project.create_user == create_user).first()
    if not proj:
        raise ProjectNotFoundError()
    p = db.query(Process).filter(
        Process.project_id == project_id,
        Process.layout_id == layout_id,
        Process.process_no == process_no,
        Process.truck_no == truck_no,
        Process.log_no == log_no,
    ).first()
    if not p:
        raise ProcessNotFoundError()
    db.delete(p)
    try:
        db.commit()
    except IntegrityError as e:
        db.rollback()
        raise integrity_error_to_app_exception(e) from e


# ---------- ProductList CRUD ----------
def list_product_list(db: Session, create_user: str, project_id: int, layout_id: int):
    # プロジェクトが現在のユーザーに属することを確認
    proj = db.query(Project).filter(Project.project_id == project_id, Project.create_user == create_user).first()
    if not proj:
        return []
    rows = db.query(ProductList).filter(
        ProductList.project_id == project_id,
        ProductList.layout_id == layout_id,
        ProductList.del_flg == False,
    ).order_by(ProductList.product_id).all()
    return [_product_list_response(i) for i in rows]


def create_product_list_item(db: Session, create_user: str, project_id: int, layout_id: int, data: ProductListItemCreate) -> ProductList:
    """部品表アイテムを作成（PK: project_id, layout_id, product_id, cable_no）。同一 product_id + cable_no は upsert（数量更新）"""
    proj = db.query(Project).filter(Project.project_id == project_id, Project.create_user == create_user).first()
    if not proj:
        raise ProjectNotFoundError()
    layout = db.query(Layout).filter(
        Layout.project_id == project_id,
        Layout.layout_id == layout_id,
        Layout.del_flg == False,
    ).first()
    if not layout:
        raise LayoutNotFoundError()
    product = db.query(MProduct).filter(MProduct.product_id == data.product_id, MProduct.del_flg == False).first()
    if not product:
        raise ProductNotFoundError()
    quantity = data.quantity if data.quantity is not None and data.quantity >= 0 else 1
    item = db.query(ProductList).filter(
        ProductList.project_id == project_id,
        ProductList.layout_id == layout_id,
        ProductList.product_id == data.product_id,
        ProductList.cable_no == data.cable_no,
    ).first()
    if item:
        item.quantity = quantity
        item.update_user = create_user
        item.update_date = datetime.now(timezone.utc)
        try:
            db.commit()
            db.refresh(item)
        except IntegrityError as e:
            db.rollback()
            if _is_product_list_pkey_duplicate_error(e):
                raise ProductListDuplicateError() from e
            raise integrity_error_to_app_exception(e) from e
        return item
    item = ProductList(
        project_id=project_id,
        layout_id=layout_id,
        product_id=data.product_id,
        quantity=quantity,
        cable_no=data.cable_no,
        del_flg=False,
        create_user=create_user,
        update_user=create_user,
    )
    db.add(item)
    try:
        db.commit()
        db.refresh(item)
    except IntegrityError as e:
        db.rollback()
        if _is_product_list_pkey_duplicate_error(e):
            raise ProductListDuplicateError() from e
        raise integrity_error_to_app_exception(e) from e
    return item


def update_product_list_item(db: Session, create_user: str, project_id: int, layout_id: int, product_id: int, data: ProductListItemUpdate, update_user: Optional[str] = None) -> ProductList:
    """部品表アイテムを更新（PK の project_id, layout_id, product_id（+ 任意の cable_no）で指定）"""
    proj = db.query(Project).filter(Project.project_id == project_id, Project.create_user == create_user).first()
    if not proj:
        raise ProjectNotFoundError()
    # 基本キー条件：project_id + layout_id + product_id
    q = db.query(ProductList).filter(
        ProductList.project_id == project_id,
        ProductList.layout_id == layout_id,
        ProductList.product_id == product_id,
    )
    # cable_no が「有効値」のときだけ、追加条件に使う
    if data.cable_no is not None and data.cable_no != "":
        q = q.filter(ProductList.cable_no == data.cable_no)

    exists = q.first()
    if not exists:
        raise ProductListItemNotFoundError()

    payload = data.model_dump(exclude_unset=True)
    # quantity と cable_no 以外は更新しない設計だが、念のため model_dump の結果をそのまま適用
    if update_user is None:
        update_user = create_user
    payload["update_user"] = update_user
    payload["update_date"] = datetime.now(timezone.utc)

    # バルク更新（行数が 1 でなくてもエラーにしない）
    q.update(payload, synchronize_session=False)
    try:
        db.commit()
    except IntegrityError as e:
        db.rollback()
        raise integrity_error_to_app_exception(e) from e

    # 更新後の 1 レコードを返す（検索条件は上の q と同じルール）
    item_q = db.query(ProductList).filter(
        ProductList.project_id == project_id,
        ProductList.layout_id == layout_id,
        ProductList.product_id == product_id,
    )
    if data.cable_no is not None and data.cable_no != "":
        item_q = item_q.filter(ProductList.cable_no == data.cable_no)
    item = item_q.first()
    if not item:
        raise ProductListItemNotFoundError()
    return item


def delete_product_list_item(db: Session, create_user: str, project_id: int, layout_id: int, product_id: int) -> None:
    """部品表行を削除（product_id で指定）"""
    proj = db.query(Project).filter(Project.project_id == project_id, Project.create_user == create_user).first()
    if not proj:
        raise ProjectNotFoundError()
    item = db.query(ProductList).filter(
        ProductList.project_id == project_id,
        ProductList.layout_id == layout_id,
        ProductList.product_id == product_id,
    ).first()
    if not item:
        raise ProductListItemNotFoundError()
    db.delete(item)
    try:
        db.commit()
    except IntegrityError as e:
        db.rollback()
        raise integrity_error_to_app_exception(e) from e


# ---------- Comparison (比較画面) ----------
def get_comparison_columns(db: Session, create_user: str, project_id: int) -> List:
    """比較画面用：プロジェクト配下の全レイアウトについて、t_layout と t_ct_log_header の最新1件を結合して返す。"""
    from app.schemas.vts import ComparisonColumnResponse
    proj = db.query(Project).filter(Project.project_id == project_id, Project.del_flg == False, Project.create_user == create_user).first()
    if not proj:
        return []
    layouts = db.query(Layout).filter(
        Layout.project_id == project_id,
        Layout.del_flg == False,
    ).order_by(Layout.layout_id).all()
    result = []
    for idx, layout in enumerate(layouts):
        ct = (
            db.query(CTLogHeader)
            .filter(
                CTLogHeader.project_id == project_id,
                CTLogHeader.layout_id == layout.layout_id,
                CTLogHeader.del_flg == False,
            )
            .order_by(
                case((CTLogHeader.record_flg == True, 0), else_=1),
                CTLogHeader.log_no.desc(),
            )
            .first()
        )
        result.append(
            ComparisonColumnResponse(
                column_index=idx + 1,
                layout_id=layout.layout_id,
                layout_name=f"Layout{layout.layout_id}",
                vts_total_length=layout.vts_total_length,
                slider_count=ct.slider_count if ct else None,
                module_count=layout.module_count,
                expected_ct=ct.expected_ct if ct else None,
            )
        )
    return result


# ---------- CTLog CRUD ----------
def list_ct_logs(db: Session, create_user: str, project_id: int, layout_id: int):
    # プロジェクトが現在のユーザーに属することを確認
    proj = db.query(Project).filter(Project.project_id == project_id, Project.create_user == create_user).first()
    if not proj:
        return []
    # 作成日時の降順で最新15件を取得し、返却時は昇順に並べ替える
    rows = db.query(CTLogHeader).filter(
        CTLogHeader.project_id == project_id,
        CTLogHeader.layout_id == layout_id,
        CTLogHeader.del_flg == False,
    ).order_by(CTLogHeader.create_date.desc(), CTLogHeader.log_no.desc()).limit(15).all()
    rows = sorted(rows, key=lambda r: ((r.create_date is None), r.create_date, r.log_no))
    return [_ct_log_response(c) for c in rows]


def _next_log_no(db: Session, project_id: int, layout_id: int) -> int:
    r = db.query(func.coalesce(func.max(CTLogHeader.log_no), 0) + 1).filter(
        CTLogHeader.project_id == project_id,
        CTLogHeader.layout_id == layout_id,
    ).scalar()
    return r or 1


def _next_log_detail_no(db: Session, project_id: int, layout_id: int, log_no: int) -> int:
    r = db.query(func.coalesce(func.max(CTLogDetail.log_detail_no), 0) + 1).filter(
        CTLogDetail.project_id == project_id,
        CTLogDetail.layout_id == layout_id,
        CTLogDetail.log_no == log_no,
    ).scalar()
    return r or 1


def create_ct_log(db: Session, create_user: str, project_id: int, layout_id: int, data: CTLogCreate) -> CTLogHeader:
    """CTログヘッダを作成（t_ct_log_header）"""
    proj = db.query(Project).filter(Project.project_id == project_id, Project.create_user == create_user).first()
    if not proj:
        raise ProjectNotFoundError()
    layout = db.query(Layout).filter(
        Layout.project_id == project_id,
        Layout.layout_id == layout_id,
        Layout.del_flg == False,
    ).first()
    if not layout:
        raise LayoutNotFoundError()
    log_no = _next_log_no(db, project_id, layout_id)
    c = CTLogHeader(
        project_id=project_id,
        layout_id=layout_id,
        log_no=log_no,
        target_cycle_time=data.target_cycle_time,
        target_throughput=data.target_throughput,
        calculation_range=data.calculation_range,
        slider_count=data.slider_count,
        expected_ct=data.expected_ct,
        expected_throughput=data.expected_throughput,
        expected_time_efficiency=data.expected_time_efficiency,
        record_flg=data.record_flg,
        ct_result_image=data.ct_result_image,
        del_flg=False,
        create_user=create_user,
        update_user=create_user,
    )
    db.add(c)
    try:
        db.commit()
        db.refresh(c)
    except IntegrityError as e:
        db.rollback()
        raise integrity_error_to_app_exception(e) from e

    # 最新15件のみ保持し、それ以前は論理削除する
    active_rows = db.query(CTLogHeader).filter(
        CTLogHeader.project_id == project_id,
        CTLogHeader.layout_id == layout_id,
        CTLogHeader.del_flg == False,
    ).order_by(CTLogHeader.create_date.desc(), CTLogHeader.log_no.desc()).all()
    old_rows = active_rows[15:]
    if old_rows:
        now = datetime.now(timezone.utc)
        for row in old_rows:
            row.del_flg = True
            row.update_user = create_user
            row.update_date = now
        try:
            db.commit()
        except IntegrityError as e:
            db.rollback()
            raise integrity_error_to_app_exception(e) from e

    return c


def create_ct_log_detail(
    db: Session,
    create_user: str,
    project_id: int,
    layout_id: int,
    log_no: int,
    data: CTLogDetailCreate,
) -> CTLogDetail:
    """CTログ明細を追加（t_ct_log_detail）"""
    proj = db.query(Project).filter(Project.project_id == project_id, Project.create_user == create_user).first()
    if not proj:
        raise ProjectNotFoundError()
    layout = db.query(Layout).filter(
        Layout.project_id == project_id,
        Layout.layout_id == layout_id,
        Layout.del_flg == False,
    ).first()
    if not layout:
        raise LayoutNotFoundError()
    header = db.query(CTLogHeader).filter(
        CTLogHeader.project_id == project_id,
        CTLogHeader.layout_id == layout_id,
        CTLogHeader.log_no == log_no,
        CTLogHeader.del_flg == False,
    ).first()
    if not header:
        raise CTLogNotFoundError()

    log_detail_no = data.log_detail_no
    if log_detail_no is None:
        log_detail_no = _next_log_detail_no(db, project_id, layout_id, log_no)
    else:
        exists = db.query(CTLogDetail).filter(
            CTLogDetail.project_id == project_id,
            CTLogDetail.layout_id == layout_id,
            CTLogDetail.log_no == log_no,
            CTLogDetail.log_detail_no == log_detail_no,
        ).first()
        if exists:
            raise CTLogDetailDuplicateError()

    row = CTLogDetail(
        project_id=project_id,
        layout_id=layout_id,
        log_no=log_no,
        log_detail_no=log_detail_no,
        log_detail_name=data.log_detail_name,
        log_detail_value=data.log_detail_value,
        del_flg=False,
        create_user=create_user,
        update_user=create_user,
    )
    db.add(row)
    try:
        db.commit()
        db.refresh(row)
    except IntegrityError as e:
        db.rollback()
        if _is_ct_log_detail_pkey_duplicate_error(e):
            raise CTLogDetailDuplicateError() from e
        raise integrity_error_to_app_exception(e) from e
    return row


def update_ct_log(db: Session, create_user: str, project_id: int, layout_id: int, log_no: int, data: CTLogUpdate, update_user: Optional[str] = None) -> CTLogHeader:
    """CTログヘッダを更新"""
    proj = db.query(Project).filter(Project.project_id == project_id, Project.create_user == create_user).first()
    if not proj:
        raise ProjectNotFoundError()
    c = db.query(CTLogHeader).filter(
        CTLogHeader.project_id == project_id,
        CTLogHeader.layout_id == layout_id,
        CTLogHeader.log_no == log_no,
    ).first()
    if not c:
        raise CTLogNotFoundError()
    payload = data.model_dump(exclude_unset=True)
    for k, v in payload.items():
        setattr(c, k, v)
    c.update_user = update_user
    c.update_date = datetime.now(timezone.utc)
    try:
        db.commit()
        db.refresh(c)
    except IntegrityError as e:
        db.rollback()
        raise integrity_error_to_app_exception(e) from e
    return c


def delete_ct_log(db: Session, create_user: str, project_id: int, layout_id: int, log_no: int) -> None:
    """CTログヘッダを削除"""
    proj = db.query(Project).filter(Project.project_id == project_id, Project.create_user == create_user).first()
    if not proj:
        raise ProjectNotFoundError()
    c = db.query(CTLogHeader).filter(
        CTLogHeader.project_id == project_id,
        CTLogHeader.layout_id == layout_id,
        CTLogHeader.log_no == log_no,
    ).first()
    if not c:
        raise CTLogNotFoundError()
    db.delete(c)
    try:
        db.commit()
    except IntegrityError as e:
        db.rollback()
        raise integrity_error_to_app_exception(e) from e


def reset_ct_history(
    db: Session,
    create_user: str,
    project_id: int,
    layout_id: int,
) -> dict:
    """
    当該 project/layout の CT 履歴をリセットする。
    t_ct_log_detail / t_ct_log_header を全件物理削除し、t_process の log_no != 0 の行のみ物理削除する（log_no=0 は維持）。
    """
    proj = db.query(Project).filter(Project.project_id == project_id, Project.create_user == create_user).first()
    if not proj:
        raise ProjectNotFoundError()
    layout = db.query(Layout).filter(
        Layout.project_id == project_id,
        Layout.layout_id == layout_id,
        Layout.del_flg == False,
    ).first()
    if not layout:
        raise LayoutNotFoundError()

    try:
        n_detail = db.query(CTLogDetail).filter(
            CTLogDetail.project_id == project_id,
            CTLogDetail.layout_id == layout_id,
        ).delete(synchronize_session=False)
        n_header = db.query(CTLogHeader).filter(
            CTLogHeader.project_id == project_id,
            CTLogHeader.layout_id == layout_id,
        ).delete(synchronize_session=False)
        n_process = db.query(Process).filter(
            Process.project_id == project_id,
            Process.layout_id == layout_id,
            Process.log_no != 0,
        ).delete(synchronize_session=False)
        db.commit()
    except IntegrityError as e:
        db.rollback()
        raise integrity_error_to_app_exception(e) from e

    return {
        "ct_log_detail_deleted": int(n_detail or 0),
        "ct_log_header_deleted": int(n_header or 0),
        "process_nonzero_log_deleted": int(n_process or 0),
    }


def clear_ct_log_record_flags(
    db: Session,
    create_user: str,
    project_id: int,
    layout_id: int,
    update_user: Optional[str] = None,
) -> int:
    """指定 project/layout 配下の t_ct_log_header の record_flg を一括で false にする。"""
    proj = db.query(Project).filter(Project.project_id == project_id, Project.create_user == create_user).first()
    if not proj:
        raise ProjectNotFoundError()
    layout = db.query(Layout).filter(
        Layout.project_id == project_id,
        Layout.layout_id == layout_id,
        Layout.del_flg == False,
    ).first()
    if not layout:
        raise LayoutNotFoundError()

    now = datetime.now(timezone.utc)
    updated = db.query(CTLogHeader).filter(
        CTLogHeader.project_id == project_id,
        CTLogHeader.layout_id == layout_id,
        CTLogHeader.del_flg == False,
    ).update(
        {
            CTLogHeader.record_flg: False,
            CTLogHeader.update_user: update_user,
            CTLogHeader.update_date: now,
        },
        synchronize_session=False,
    )
    try:
        db.commit()
    except IntegrityError as e:
        db.rollback()
        raise integrity_error_to_app_exception(e) from e
    return int(updated or 0)
