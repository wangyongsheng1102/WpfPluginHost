"""
PDF 報告用コンテキスト取得サービス
project_id / layout_id から部品表・入力条件・プロセス表・VTS図・CTログ一覧等を組み立てる
"""
from decimal import Decimal
from typing import List, Optional

from sqlalchemy.orm import Session

from app.core.exceptions import LayoutNotFoundError, ProjectNotFoundError
from app.core.product_locale import resolve_product_name, resolve_product_type_name
from app.models.vts import (
    CTLogHeader,
    Layout,
    LayoutDesign,
    MProduct,
    MProductType,
    Process,
    ProductList,
    Project,
)
from app.schemas.pdf_report import (
    PdfCalculationResult,
    PdfCoverData,
    PdfCtLogOption,
    PdfInputConditionRow,
    PdfLayoutOption,
    PdfPartsListItem,
    PdfProcessTableRow,
    PdfReportContextResponse,
)


def _format_decimal(v) -> str:
    if v is None:
        return ""
    if isinstance(v, Decimal):
        return str(v)
    return str(v)


def get_pdf_report_context(
    db: Session,
    create_user: str,
    project_id: int,
    layout_id: int,
    ct_log_no: Optional[int] = None,
    language: str = "ja",
) -> PdfReportContextResponse:
    """
    PDF 報告用のコンテキストを取得する。
    プロジェクト・レイアウトが存在しない場合は例外を発生。
    """
    project = (
        db.query(Project)
        .filter(
            Project.project_id == project_id,
            Project.del_flg == False,
            Project.create_user == create_user,
        )
        .first()
    )
    if not project:
        raise ProjectNotFoundError()

    layout = (
        db.query(Layout)
        .filter(
            Layout.project_id == project_id,
            Layout.layout_id == layout_id,
            Layout.del_flg == False,
        )
        .first()
    )
    if not layout:
        raise LayoutNotFoundError()

    # layout_list: 同一プロジェクト内のレイアウト一覧（モーダル用）
    layouts = (
        db.query(Layout)
        .filter(
            Layout.project_id == project_id,
            Layout.del_flg == False,
        )
        .order_by(Layout.layout_id)
        .all()
    )
    layout_name_prefix = "Layout" if language == "en" else "レイアウト"
    layout_list = [
        PdfLayoutOption(
            layout_id=l.layout_id,
            layout_name=f"{layout_name_prefix}{l.layout_id}",
            project_id=project_id,
            finish_flg=l.finish_flg,
        )
        for l in layouts
    ]

    # ct_log_list: 当 layout の CT ログ一覧（モーダル用）
    ct_logs = (
        db.query(CTLogHeader)
        .filter(
            CTLogHeader.project_id == project_id,
            CTLogHeader.layout_id == layout_id,
            CTLogHeader.del_flg == False,
        )
        .order_by(CTLogHeader.log_no)
        .all()
    )
    log_name_prefix = "Log" if language == "en" else "ログ"
    ct_log_list = [
        PdfCtLogOption(log_no=c.log_no, log_name=f"{log_name_prefix}{c.log_no}")
        for c in ct_logs
    ]

    # parts_list: ProductList + MProduct + MProductType から部品表（JOIN で一括取得）
    pl_items = (
        db.query(ProductList, MProduct, MProductType)
        .join(MProduct, ProductList.product_id == MProduct.product_id)
        .outerjoin(MProductType, MProduct.product_type_id == MProductType.product_type_id)
        .filter(
            ProductList.project_id == project_id,
            ProductList.layout_id == layout_id,
            ProductList.del_flg == False,
            MProduct.del_flg == False,
        )
        .order_by(ProductList.product_id)
        .all()
    )
    parts_list = []
    for idx, (pl, prod, ptype) in enumerate(pl_items, start=1):
        category = (resolve_product_type_name(ptype, language) if ptype else None) or ""
        parts_list.append(
            PdfPartsListItem(
                no=idx,
                category=category,
                name=resolve_product_name(prod, language),
                model_number=prod.product_model or "",
                product_code=prod.product_code or "",
                quantity=pl.quantity or 0,
            )
        )

    # 入力条件は 36 項目。目標CT等 4 項目は CT ログから取得（指定 or 先頭）
    ct_log_for_input = None
    if ct_log_no is not None:
        ct_log_for_input = (
            db.query(CTLogHeader)
            .filter(
                CTLogHeader.project_id == project_id,
                CTLogHeader.layout_id == layout_id,
                CTLogHeader.log_no == ct_log_no,
                CTLogHeader.del_flg == False,
            )
            .first()
        )
    if ct_log_for_input is None:
        ct_log_for_input = (
            db.query(CTLogHeader)
            .filter(
                CTLogHeader.project_id == project_id,
                CTLogHeader.layout_id == layout_id,
                CTLogHeader.del_flg == False,
            )
            .order_by(CTLogHeader.log_no)
            .first()
        )
    input_conditions = [
        PdfInputConditionRow(item="レイアウト", value=f"レイアウト{layout_id}", unit=""),
        PdfInputConditionRow(item="VTS復路", value="ON" if layout.vts_return_trip else "OFF", unit=""),
        PdfInputConditionRow(item="循環方式", value=_format_decimal(layout.circulation_type), unit=""),
        PdfInputConditionRow(item="モジュール配置方向", value=_format_decimal(layout.module_direction), unit=""),
        PdfInputConditionRow(item="フットプリント制限: X", value=_format_decimal(layout.footprint_limit_x), unit="mm"),
        PdfInputConditionRow(item="フットプリント制限: Y", value=_format_decimal(layout.footprint_limit_y), unit="mm"),
        PdfInputConditionRow(item="フットプリント制限: Z", value=_format_decimal(layout.footprint_limit_z), unit="mm"),
        PdfInputConditionRow(item="ワーク名称", value=(layout.work_name or "").strip(), unit=""),
        PdfInputConditionRow(item="ワークサイズ: L", value=_format_decimal(layout.work_size_l), unit="mm"),
        PdfInputConditionRow(item="ワークサイズ: W", value=_format_decimal(layout.work_size_w), unit="mm"),
        PdfInputConditionRow(item="ワークサイズ: D", value=_format_decimal(layout.work_size_d), unit="mm"),
        PdfInputConditionRow(item="ワーク質量", value=_format_decimal(layout.work_mass), unit="kg"),
        PdfInputConditionRow(item="ワーク搭載数", value=_format_decimal(layout.work_products_per_pallet), unit="個"),
        PdfInputConditionRow(item="パレットサイズ: L", value=_format_decimal(layout.pallet_l), unit="mm"),
        PdfInputConditionRow(item="パレットサイズ: W", value=_format_decimal(layout.pallet_w), unit="mm"),
        PdfInputConditionRow(item="パレットサイズ: D", value=_format_decimal(layout.pallet_d), unit="mm"),
        PdfInputConditionRow(item="パレット質量", value=_format_decimal(layout.pallet_mass), unit="kg"),
        PdfInputConditionRow(item="スライダタイプ", value=_format_decimal(layout.slider_type), unit=""),
        PdfInputConditionRow(item="循環軸の長さ", value=_format_decimal(layout.circulation_axis_full_length), unit="mm"),
        PdfInputConditionRow(item="循環軸位置オフセット", value=_format_decimal(layout.circulation_axis_offset), unit="mm"),
        PdfInputConditionRow(item="循環軸速度", value=_format_decimal(layout.circulation_axis_speed), unit="mm/s"),
        PdfInputConditionRow(item="循環軸加減速度", value=_format_decimal(layout.circulation_axis_acceleration), unit="mm/s^2"),
        PdfInputConditionRow(item="循環軸センサ", value=(layout.circulation_axis_sensor or "").strip(), unit=""),
        PdfInputConditionRow(item="循環名称", value=(layout.circulation_name or "").strip(), unit=""),
        PdfInputConditionRow(item="垂直循環タイプ", value=(layout.circulation_type_attr or "").strip(), unit=""),
        PdfInputConditionRow(item="垂直循環リード", value=_format_decimal(layout.circulation_axis_lead), unit="mm"),
        PdfInputConditionRow(item="垂直循環ストローク", value=_format_decimal(layout.circulation_stroke), unit="mm"),
        PdfInputConditionRow(item="垂直循環モータ設置向き", value=(layout.circulation_motor_set_direction or "").strip(), unit=""),
        PdfInputConditionRow(item="垂直循環ハウジング", value=(layout.circulation_guide or "").strip(), unit=""),
        PdfInputConditionRow(item="排出速度 or 引込速度", value=_format_decimal(layout.eor_speed), unit="mm/s"),
        PdfInputConditionRow(item="排出加減速度 or 引込加減速度", value=_format_decimal(layout.eor_acceleration), unit="mm/s^2"),
        PdfInputConditionRow(item="制御コントローラパターン", value=(layout.control_controller_pattern or "").strip(), unit=""),
        PdfInputConditionRow(item="VTS全長", value=_format_decimal(layout.vts_total_length), unit="mm"),
    ]
    if ct_log_for_input:
        input_conditions.append(PdfInputConditionRow(item="目標サイクルタイム", value=_format_decimal(ct_log_for_input.target_cycle_time), unit="s"))
        input_conditions.append(PdfInputConditionRow(item="目標スループット", value=_format_decimal(ct_log_for_input.target_throughput), unit="pcs/h"))
        input_conditions.append(PdfInputConditionRow(item="計算範囲", value=(ct_log_for_input.calculation_range or "").strip(), unit="s"))
        input_conditions.append(PdfInputConditionRow(item="スライダ数", value=_format_decimal(ct_log_for_input.slider_count), unit="個"))
    else:
        input_conditions.append(PdfInputConditionRow(item="目標サイクルタイム", value="", unit="s"))
        input_conditions.append(PdfInputConditionRow(item="目標スループット", value="", unit="pcs/h"))
        input_conditions.append(PdfInputConditionRow(item="計算範囲", value="", unit="s"))
        input_conditions.append(PdfInputConditionRow(item="スライダ数", value="", unit="個"))

    # process_table: Process を行方向に項目、列方向にプロセス（A, P1-1, ...）
    processes = (
        db.query(Process)
        .filter(
            Process.project_id == project_id,
            Process.layout_id == layout_id,
            Process.del_flg == False,
        )
        .order_by(Process.process_no)
        .all()
    )

    def process_label(p: Process) -> str:
        return f"{p.truck_no}-{p.process_no}"

    process_table: List[PdfProcessTableRow] = []
    if processes:
        col_labels = [process_label(p) for p in processes]
        # 行: プロセス名称, プロセスCT動作時間[s], ...
        process_name_row = PdfProcessTableRow(item="プロセス名称", values={process_label(p): (p.process_name or "") for p in processes})
        process_table.append(process_name_row)
        process_time_row = PdfProcessTableRow(item="プロセスCT動作時間[s]", values={process_label(p): _format_decimal(p.process_time) for p in processes})
        process_table.append(process_time_row)
        process_time_tol_row = PdfProcessTableRow(item="プロセスCT動作時間公差[s]", values={process_label(p): _format_decimal(p.process_time_tolerance) for p in processes})
        process_table.append(process_time_tol_row)
        settling_row = PdfProcessTableRow(item="静定時間[s]", values={process_label(p): _format_decimal(p.settling_time) for p in processes})
        process_table.append(settling_row)
        stop_pos_row = PdfProcessTableRow(item="プロセス停止位置[mm]", values={process_label(p): _format_decimal(p.process_stop_position) for p in processes})
        process_table.append(stop_pos_row)
        forbidden_row = PdfProcessTableRow(
            item="プロセス中禁止領域[mm]",
            values={process_label(p): str(p.process_forbidden_area or "") for p in processes},
        )
        process_table.append(forbidden_row)
        move_speed_row = PdfProcessTableRow(item="本プロセスへの移動速度 [mm/s]", values={process_label(p): _format_decimal(p.move_to_process_speed) for p in processes})
        process_table.append(move_speed_row)
        move_accel_row = PdfProcessTableRow(item="本プロセスへの移動加減速度 [mm/s^2]", values={process_label(p): _format_decimal(p.move_to_process_accel) for p in processes})
        process_table.append(move_accel_row)

    # calculation_result: 指定 ct_log_no の CT ログがあれば使用
    calculation_result: Optional[PdfCalculationResult] = None
    if ct_log_no is not None:
        ct_log = (
            db.query(CTLogHeader)
            .filter(
                CTLogHeader.project_id == project_id,
                CTLogHeader.layout_id == layout_id,
                CTLogHeader.log_no == ct_log_no,
                CTLogHeader.del_flg == False,
            )
            .first()
        )
        if ct_log:
            calculation_result = PdfCalculationResult(
                target_cycle_time=ct_log.target_cycle_time,
                target_throughput=ct_log.target_throughput,
                calculation_range=ct_log.calculation_range,
                work_load_count=layout.work_products_per_pallet,
                slider_count=ct_log.slider_count,
                expected_cycle_time=ct_log.expected_ct,
                expected_throughput=ct_log.expected_throughput,
                expected_time_efficiency=ct_log.expected_time_efficiency,
                ct_result_image=ct_log.ct_result_image,
            )

    # vts_diagram: LayoutDesign.layout_image (Base64)
    design = (
        db.query(LayoutDesign)
        .filter(
            LayoutDesign.project_id == project_id,
            LayoutDesign.layout_id == layout_id,
            LayoutDesign.del_flg == False,
        )
        .first()
    )
    vts_diagram = None
    if design and design.layout_image:
        img = design.layout_image
        vts_diagram = img if img.startswith("data:") else f"data:image/png;base64,{img}"

    cover = PdfCoverData(
        title="",
        creation_date=None,
        creator="",
    )

    return PdfReportContextResponse(
        cover=cover,
        layout_list=layout_list,
        ct_log_list=ct_log_list,
        parts_list=parts_list,
        input_conditions=input_conditions,
        process_table=process_table,
        calculation_result=calculation_result,
        vts_diagram=vts_diagram,
    )
