"""
最適スライダ数計算サービス（参照: CalculationOptimalSliderNumber.py）
入口はフル計算のみとし、入力は「レイアウト関連の 11 パラメータ + 製造プロセス一覧」とする。
処理フローは `build_stops_from_layout` → （lap, stop_list）→ `calculate` である。
`optimum_slider_count_total_value` は現状、単一系の `optimal_slider_count` を返す。参照スクリプトの入力セル In[32]–In[49] に相当する複数グループ合算ロジックは未対応である。
"""

import math
from dataclasses import dataclass
from typing import List, Optional, Tuple, Any

# 定数（参照スクリプトと同一）
INITIAL_VALUE = 0
FIRST_NUMBER = 0
CIRCULATION_AXIS_VALID = 1
INIT_SLIDER_NUMBER = 2
ADD_VALE = 1
SLIDER_COUNT_MAX = 128
CYCLICAL_AXIS_POSITION_A = 0
MAX_SPEED = 3000
MAX_ADDITION_AND_SUBTRACTION_SPEED = 9000
PATTERN_1 = 1
PATTERN_2 = 2
MAX_PROCESS_COUNT = 256


@dataclass
class StopInput:
    """停止位置情報（統合版：位置情報 + 停止時間）"""
    number: int
    position: float
    max_speed: float
    acceleration: float
    circulation_axis_flag: int
    stop_time: Optional[float]  # 停止時間（非循環軸位置で使用）


@dataclass
class StopTimeInput:
    """停止時間リスト（内部使用：stop_list から抽出した停止時間）"""
    number: int
    processing_time: float


@dataclass
class StopPositionOutput:
    """停止位置情報（計算後）。print(stop_position) による表示内容。"""
    number: int
    processing_time: float
    position: float
    max_speed: float
    acceleration: float
    distance: float
    circulation_axis_flag: int


@dataclass
class StopTimeOutput:
    """停止時間リスト 1 件（統合後）"""
    number: int
    processing_time: float
    position: float
    max_speed: float
    acceleration: float
    distance: float
    circulation_axis_flag: int


@dataclass
class DivisionLoopStep:
    """割り数ループの 1 ステップ"""
    division_count: int
    other_processing_time: float
    temp_other_processing_time: float
    max_processing_time: float


@dataclass
class OptimalSliderResult:
    """API レスポンス相当（参照スクリプトの print 出力一式および start_positions）"""
    stop_position_list_num: int
    stop_position_list: List[StopPositionOutput]
    stop_time_list: List[StopTimeOutput]
    max_processing_time: float
    total_processing_time: float
    other_processing_time: float
    division_loop: List[DivisionLoopStep]
    optimal_slider_count: int
    start_positions: List[float]


def _get_process(item: Any, key: str, default: Any = None) -> Any:
    """dict / オブジェクト両対応でフィールドを取得"""
    if isinstance(item, dict):
        return item.get(key, default)
    return getattr(item, key, default)


def build_stops_from_layout(
    vts_length: float,
    cyclical_axis_offset: float,
    cyclical_axis_stroke: float,
    slider_length: float,
    work_size_w: float,
    pallet_size_w: float,
    controller_pattern: int,
    cyclical_axis_speed: float,
    cyclical_axis_accel: float,
    eject_or_retract_speed: float,
    eject_or_retract_accel: float,
    manufacturing_process_list: Optional[List[Any]] = None,
) -> Tuple[float, List[StopInput]]:
    """
    設定値ロジック（参照スクリプトの入力セル In[8]–In[27] に相当）。
    入力（レイアウト関連の 11 パラメータ + 製造プロセス一覧）から（system_one_lap_length, stop_list）を構築する。
    """
    if manufacturing_process_list is None:
        manufacturing_process_list = []
    if len(manufacturing_process_list) > MAX_PROCESS_COUNT:
        raise ValueError(f"製造プロセス情報が最大数({MAX_PROCESS_COUNT})を超えています: {len(manufacturing_process_list)}")

    # 一周長さ（参照スクリプト入力セル In[8] に相当）
    circumference_length = (cyclical_axis_offset * 4) + (vts_length * 2) + (cyclical_axis_stroke * 2)

    # 製品最大サイズ（参照スクリプト入力セル In[11]・In[12] に相当）
    product_max_size = max(work_size_w, pallet_size_w)
    product_max_size = max(product_max_size, slider_length)

    # 循環軸位置A = 0
    pos_a = CYCLICAL_AXIS_POSITION_A
    outward_start_a = pos_a + cyclical_axis_offset + (product_max_size / 2)
    outward_end_b = pos_a + cyclical_axis_offset + (vts_length - (product_max_size / 2))
    pos_b = pos_a + cyclical_axis_offset + vts_length + cyclical_axis_offset
    pos_c = pos_b + cyclical_axis_stroke
    return_start_c = pos_c + cyclical_axis_offset + (product_max_size / 2)
    return_end_d = pos_c + cyclical_axis_offset + (vts_length - product_max_size / 2)
    pos_d = pos_c + cyclical_axis_offset + vts_length + cyclical_axis_offset

    # 固定位置を (position, velocity, acceleration, circulation_axis_flag, stop_time) で収集
    entries: List[Tuple[float, float, float, int, float]] = []

    # 循環軸位置 A（参照スクリプト入力セル In[10] に相当）
    entries.append((pos_a, cyclical_axis_speed, cyclical_axis_accel, CIRCULATION_AXIS_VALID, 0.0))

    if controller_pattern == PATTERN_1:
        entries.append((outward_start_a, eject_or_retract_speed, eject_or_retract_accel, 0, 0.0))
    # 往路 b は PATTERN_2 のみ pos_map に追加（参照スクリプト入力セル In[16] に相当）

    if controller_pattern == PATTERN_2:
        entries.append((outward_end_b, MAX_SPEED, MAX_ADDITION_AND_SUBTRACTION_SPEED, 0, 0.0))

    # 循環軸位置 B（参照スクリプト入力セル In[18] に相当）
    if controller_pattern == PATTERN_1:
        entries.append((pos_b, MAX_SPEED, MAX_ADDITION_AND_SUBTRACTION_SPEED, 0, 0.0))
    else:
        entries.append((pos_b, eject_or_retract_speed, eject_or_retract_accel, 0, 0.0))

    # 循環軸位置 C（参照スクリプト入力セル In[20] に相当）
    entries.append((pos_c, cyclical_axis_speed, cyclical_axis_accel, CIRCULATION_AXIS_VALID, 0.0))

    if controller_pattern == PATTERN_1:
        entries.append((return_start_c, eject_or_retract_speed, eject_or_retract_accel, 0, 0.0))
    if controller_pattern == PATTERN_2:
        entries.append((return_end_d, MAX_SPEED, MAX_ADDITION_AND_SUBTRACTION_SPEED, 0, 0.0))

    # 循環軸位置 D（参照スクリプト入力セル In[26] に相当）
    if controller_pattern == PATTERN_1:
        entries.append((pos_d, MAX_SPEED, MAX_ADDITION_AND_SUBTRACTION_SPEED, 0, 0.0))
    else:
        entries.append((pos_d, cyclical_axis_speed, cyclical_axis_accel, 0, 0.0))

    # 製造プロセス（参照スクリプト入力セル In[27] に相当）：往路または復路範囲内の停止位置を追加
    for process in manufacturing_process_list:
        stop_position = float(_get_process(process, "process_stop_position", 0))
        stop_time = (
            float(_get_process(process, "process_ct_time", 0))
            + float(_get_process(process, "process_ct_time_tolerance", 0))
            + float(_get_process(process, "settling_time", 0))
        )
        velocity = float(_get_process(process, "move_speed_to_this_process", 0))
        accel = float(_get_process(process, "move_accel_to_this_process", 0))
        in_outward = outward_start_a < stop_position and stop_position < outward_end_b
        in_return = return_start_c < stop_position and stop_position < return_end_d
        if in_outward or in_return:
            entries.append((stop_position, velocity, accel, 0, stop_time))

    # 位置昇順ソート（参照スクリプト入力セル In[28] に相当）し、StopInput に変換（number は 1 始まり連番）
    entries.sort(key=lambda e: e[0])
    stop_list: List[StopInput] = []
    for i, (position, velocity, accel, circ_flag, stop_time_val) in enumerate(entries, start=1):
        stop_list.append(
            StopInput(
                number=i,
                position=position,
                max_speed=velocity,
                acceleration=accel,
                circulation_axis_flag=circ_flag,
                stop_time=stop_time_val if circ_flag != CIRCULATION_AXIS_VALID else None,
            )
        )
    return circumference_length, stop_list


def _calculation_movement_time(
    max_speed: float,
    acceleration: float,
    distance: float,
    circulation_axis_flag: int,
) -> float:
    """移動時間の算出（参照スクリプトと同一）"""
    if distance <= 0 or acceleration <= 0:
        return 0.0
    acceleration_change_point = math.sqrt(distance * acceleration)
    acceleration_time = acceleration_change_point / acceleration
    if acceleration_change_point > max_speed:
        acceleration_time = max_speed / acceleration
        acceleration_distance = 0.5 * max_speed * acceleration_time
        deceleration_time = max_speed / acceleration
        deceleration_distance = 0.5 * max_speed * deceleration_time
        constant_speed_distance = distance - (acceleration_distance + deceleration_distance)
        constant_speed_time = constant_speed_distance / max_speed
        processing_time = acceleration_time + constant_speed_time + deceleration_time
    else:
        deceleration_time = acceleration_change_point / acceleration
        processing_time = acceleration_time + deceleration_time
    if circulation_axis_flag == CIRCULATION_AXIS_VALID:
        processing_time = processing_time * 2
    return processing_time


def calculate(
    system_one_lap_length: float,
    stop_list: List[StopInput],
) -> Optional[OptimalSliderResult]:
    """
    参照スクリプトと同一フローで計算し、print 出力に相当する結果を返す。
    統合された stop_list から位置情報と停止時間を分離して処理。
    """
    if not stop_list or system_one_lap_length <= 0:
        return None

    # 位置でソート（番号順は参照スクリプトどおりの並びを維持するため、position でソート）
    sorted_stops = sorted(stop_list, key=lambda x: x.position)
    stop_num = len(sorted_stops)
    
    # 停止時間リストを抽出（非循環軸位置の stop_time のみ）
    stop_time_list: List[StopTimeInput] = []
    for stop in sorted_stops:
        if stop.circulation_axis_flag != CIRCULATION_AXIS_VALID and stop.stop_time is not None:
            stop_time_list.append(StopTimeInput(
                number=stop.number,
                processing_time=stop.stop_time
            ))

    # 距離を算出（参照スクリプト: stop_position_list[i+1].distance = ... / stop_position_list[0].distance = ...）
    distances: List[float] = [0.0] * stop_num
    for i in range(stop_num):
        if i == stop_num - 1:
            # 最後 → 先頭 の距離を先頭に格納
            distance_to_front = system_one_lap_length - sorted_stops[i].position
            distances[FIRST_NUMBER] = distance_to_front
        else:
            front_position = sorted_stops[i + 1].position
            rear_position = sorted_stops[i].position
            distances[i + 1] = front_position - rear_position

    # 移動時間を算出
    processing_times: List[float] = []
    for i in range(stop_num):
        pt = _calculation_movement_time(
            sorted_stops[i].max_speed,
            sorted_stops[i].acceleration,
            distances[i],
            sorted_stops[i].circulation_axis_flag,
        )
        processing_times.append(pt)

    # 出力用: 停止位置情報リスト（計算後）
    stop_position_output = [
        StopPositionOutput(
            number=sorted_stops[i].number,
            processing_time=processing_times[i],
            position=sorted_stops[i].position,
            max_speed=sorted_stops[i].max_speed,
            acceleration=sorted_stops[i].acceleration,
            distance=distances[i],
            circulation_axis_flag=sorted_stops[i].circulation_axis_flag,
        )
        for i in range(stop_num)
    ]
    stop_position_list_num = stop_num

    # 停止時間リスト: 入力の stop_time_list + 循環軸ありの停止位置情報
    stop_time_output: List[StopTimeOutput] = []
    for st in stop_time_list:
        stop_time_output.append(StopTimeOutput(
            number=st.number,
            processing_time=st.processing_time,
            position=INITIAL_VALUE,
            max_speed=INITIAL_VALUE,
            acceleration=INITIAL_VALUE,
            distance=INITIAL_VALUE,
            circulation_axis_flag=0,
        ))
    # 循環軸ありの停止位置情報を停止時間リストへ 1 件だけ追加（参照スクリプトと同一。next() で 1 件取得）
    stop_info_to_add = next(
        (info for info in stop_position_output if info.circulation_axis_flag == CIRCULATION_AXIS_VALID),
        None,
    )
    if stop_info_to_add is not None:
        stop_time_output.append(StopTimeOutput(
            number=stop_info_to_add.number,
            processing_time=stop_info_to_add.processing_time,
            position=stop_info_to_add.position,
            max_speed=stop_info_to_add.max_speed,
            acceleration=stop_info_to_add.acceleration,
            distance=stop_info_to_add.distance,
            circulation_axis_flag=stop_info_to_add.circulation_axis_flag,
        ))

    max_processing_time = max(st.processing_time for st in stop_time_output)
    temp_stop_time_list = [st for st in stop_time_output if st.circulation_axis_flag != CIRCULATION_AXIS_VALID]
    total_processing_time = sum(processing_times) + sum(st.processing_time for st in temp_stop_time_list)
    other_processing_time = total_processing_time - max_processing_time

    # 参照スクリプト入力セル In[32]–In[49] に相当：time_map から max_map、group_number、group_map、グループ別 optimum_slider_number、合計へ
    time_list: List[float] = []
    for i in range(stop_num):
        stop_time_i = (sorted_stops[i].stop_time if sorted_stops[i].stop_time is not None else INITIAL_VALUE)
        time_list.append(stop_time_i)
        time_list.append(processing_times[i])
    max_time = max(time_list)
    max_map = [i for i in range(len(time_list)) if time_list[i] == max_time]
    num_groups = len(max_map)

    group_number: List[int] = [0] * len(time_list)
    if num_groups > 1:
        start_key = max_map[0]
        keys_ordered = list(range(len(time_list)))
        start_idx = keys_ordered.index(start_key)
        rotated_keys = keys_ordered[start_idx:] + keys_ordered[:start_idx]
        index = 0
        for key in rotated_keys:
            if time_list[key] == max_time:
                index = index + ADD_VALE
            group_number[key] = index
    else:
        for i in range(len(time_list)):
            group_number[i] = 1

    # 参照スクリプト入力セル In[44] に相当：グループ番号でソートし、累積で group_totals を構築（遷移時に離れるグループの累積を保存）
    sorted_pairs = sorted(enumerate(time_list), key=lambda p: (group_number[p[0]], p[0]))
    group_totals: dict = {}
    temp_group_number = 1
    temp_group_total_process_time = 0.0
    for idx, t in sorted_pairs:
        temp_group_total_process_time += t
        g = group_number[idx]
        if g != temp_group_number:
            group_totals[temp_group_number] = temp_group_total_process_time
            temp_group_number = temp_group_number + ADD_VALE
    group_totals[num_groups] = temp_group_total_process_time

    optimum_slider_count_total_value = 0
    for g in range(1, num_groups + 1):
        total_process_time = group_totals.get(g, 0.0)
        other_time = total_process_time - max_time
        efficiency_time = other_time
        recurring_times = 0
        if efficiency_time > max_time:
            while True:
                efficiency_time = efficiency_time / INIT_SLIDER_NUMBER
                recurring_times = recurring_times + ADD_VALE
                if efficiency_time <= max_time:
                    break
            optimum_slider_number = recurring_times + INIT_SLIDER_NUMBER
        else:
            optimum_slider_number = INIT_SLIDER_NUMBER
        optimum_slider_count_total_value += optimum_slider_number

    optimal_slider_count = optimum_slider_count_total_value
    interval = system_one_lap_length / optimal_slider_count
    start_positions = [i * interval for i in range(optimal_slider_count)]

    # division_loop は参照スクリプトに存在しないが、API 互換のため残す（他処理時間・割り数の表示用）
    division_count = INIT_SLIDER_NUMBER
    temp_other_processing_time = other_processing_time
    division_loop: List[DivisionLoopStep] = []
    while max_processing_time <= temp_other_processing_time and division_count < SLIDER_COUNT_MAX:
        division_loop.append(DivisionLoopStep(
            division_count=division_count,
            other_processing_time=other_processing_time,
            temp_other_processing_time=temp_other_processing_time,
            max_processing_time=max_processing_time,
        ))
        division_count = division_count + ADD_VALE
        temp_other_processing_time = other_processing_time / division_count
    division_loop.append(DivisionLoopStep(
        division_count=division_count,
        other_processing_time=other_processing_time,
        temp_other_processing_time=temp_other_processing_time,
        max_processing_time=max_processing_time,
    ))

    return OptimalSliderResult(
        stop_position_list_num=stop_position_list_num,
        stop_position_list=stop_position_output,
        stop_time_list=stop_time_output,
        max_processing_time=max_processing_time,
        total_processing_time=total_processing_time,
        other_processing_time=other_processing_time,
        division_loop=division_loop,
        optimal_slider_count=optimal_slider_count,
        start_positions=start_positions,
    )
