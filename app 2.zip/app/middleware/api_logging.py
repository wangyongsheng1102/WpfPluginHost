"""
API リクエスト/レスポンスロギングミドルウェア
全ての API リクエストとレスポンスの詳細情報を記録する。
レスポンスは「送信時に body を収集してログに書く」だけにし、元のレスポンスをそのままクライアントへ転送する。
body を読んで再構築すると Starlette 側で body が空になるためである。
"""
import json
import logging
import time
import uuid
from typing import Any, Callable, Dict
from fastapi import Request
from fastapi.exceptions import HTTPException
from fastapi.responses import JSONResponse
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.types import ASGIApp, Message, Receive, Scope, Send

from app.core.config import settings
from app.core.errors import get_error_message, get_language_from_request
from app.core.exceptions import BaseAppException

logger = logging.getLogger("api_access")


class _ResponseLoggingWrapper:
    """
    元のレスポンスをそのまま送信しつつ、送信される body を収集してログに書く ASGI ラッパー。
    レスポンスを再構築しないため、クライアントには元の body がそのまま届く。
    """
    def __init__(self, response, request_info: dict, start_time: float, middleware: "APILoggingMiddleware"):
        self._response = response
        self._request_info = request_info
        self._start_time = start_time
        self._middleware = middleware

    async def __call__(self, scope: Scope, receive: Receive, send: Send) -> None:
        status_code = 200
        response_headers: Dict[str, str] = {}
        body_chunks = []

        async def send_wrapper(message: Message) -> None:
            nonlocal status_code, response_headers
            msg_type = message["type"]
            
            if msg_type == "http.response.start":
                status_code = message.get("status", 200)
                response_headers = self._parse_headers(message.get("headers", []))
            elif msg_type == "http.response.body":
                body = message.get("body", b"")
                if body:
                    body_chunks.append(body)
                if not message.get("more_body", True):
                    self._log_response_body(status_code, response_headers, body_chunks)
            await send(message)

        await self._response(scope, receive, send_wrapper)

    def _parse_headers(self, raw_headers: list) -> Dict[str, str]:
        """レスポンスヘッダをパース"""
        headers = {}
        for k, v in raw_headers:
            key = (k.decode("utf-8", errors="replace") if isinstance(k, bytes) else k).lower()
            val = v.decode("utf-8", errors="replace") if isinstance(v, bytes) else v
            headers[key] = val
        return headers

    def _log_response_body(self, status_code: int, headers: Dict[str, str], body_chunks: list) -> None:
        """レスポンス body をログに記録"""
        duration_ms = (time.time() - self._start_time) * 1000
        body_bytes = b"".join(body_chunks)
        
        try:
            body_str = body_bytes.decode("utf-8")
        except Exception:
            body_str = f"<binary data, {len(body_bytes)} bytes>"
        
        if len(body_str) > self._middleware.max_body_size:
            body_str = body_str[: self._middleware.max_body_size] + (
                f"... [truncated, total size: {len(body_bytes)} bytes]"
            )
        
        masked_headers = self._middleware._mask_sensitive_dict(headers, is_header=True)
        masked_body = self._middleware._mask_json_body(body_str)
        response_info = {
            "request_id": self._request_info["request_id"],
            "status_code": status_code,
            "headers": masked_headers,
            "body": masked_body,
            "body_bytes": body_bytes,
        }
        self._middleware._log_response(self._request_info, response_info, duration_ms)


class APILoggingMiddleware(BaseHTTPMiddleware):
    """
    API アクセスログミドルウェア
    
    全ての HTTP リクエスト/レスポンスを記録する：
    - リクエスト: method, path, headers, query params, path params, body
    - レスポンス: status code, response body, 処理時間
    """
    
    # ログ記録から除外するパス
    EXCLUDED_PATHS = {
        "/health",
        "/ping",
        "/docs",
        "/redoc",
        "/openapi.json",
        "/favicon.ico",
    }
    
    # 敏感フィールドリスト（小文字）
    SENSITIVE_FIELDS = {
        "password", "current_password", "new_password", "confirm_password",
        "token", "refresh_token", "api_key", "secret", "access_token"
    }
    
    # 敏感 Header リスト（小文字）
    SENSITIVE_HEADERS = {
        "authorization", "x-api-key", "cookie", "x-auth-token"
    }
    
    def __init__(self, app: ASGIApp):
        super().__init__(app)
        # 設定から Body サイズの上限を取得
        self.max_body_size = settings.LOG_BODY_MAX_SIZE
        self.log_enabled = settings.LOG_API_REQUESTS
        self.log_request_body = settings.LOG_REQUEST_BODY
        self.log_response_body = settings.LOG_RESPONSE_BODY
        self.log_sensitive_data = settings.LOG_SENSITIVE_DATA
    
    async def dispatch(self, request: Request, call_next: Callable) -> Any:
        """リクエスト/レスポンスをインターセプトしてログを記録する。"""
        
        # ログが無効化されている場合はスキップ
        if not self.log_enabled:
            return await call_next(request)
        
        # 除外パスの判定
        if not self._should_log(request.url.path):
            return await call_next(request)
        
        # リクエスト ID を生成（追跡用）
        request_id = str(uuid.uuid4())
        
        # リクエスト開始時刻
        start_time = time.time()
        
        # リクエスト情報を抽出
        request_info = await self._extract_request_info(request, request_id)
        
        # リクエストログを記録
        self._log_request(request_info)
        
        # リクエスト body を読み取った後、再利用可能にする
        # （FastAPI は body を一度しか読めないため、再構築が必要）
        async def receive():
            return {"type": "http.request", "body": request_info["body_bytes"]}
        
        # 元の receive を置き換え
        request._receive = receive
        
        # レスポンスを取得し、そのままクライアントへ転送するラッパーを返す。
        # ラッパーが送信時に body を横取りしてログに書くため、レスポンスを再構築しない。
        try:
            response = await call_next(request)
            return _ResponseLoggingWrapper(response, request_info, start_time, self)
        except BaseAppException as e:
            return self._handle_app_exception(e, request, request_info, start_time)
        except HTTPException as e:
            return self._handle_http_exception(e, request, request_info, start_time)
        except Exception as e:
            self._log_unhandled_exception(e, request_info, start_time)
            raise
    
    def _handle_app_exception(
        self, exc: BaseAppException, request: Request, request_info: Dict, start_time: float
    ) -> Any:
        """BaseAppException を処理してレスポンスを返す"""
        language = get_language_from_request(request)
        error_message = get_error_message(exc.error_code, language)
        response = JSONResponse(
            status_code=exc.status_code,
            content={
                "error_code": exc.error_code.value,
                "message": error_message,
                "language": language,
            },
        )
        self._add_cors_headers_to_response(request, response)
        self._log_error_response(exc.status_code, exc.error_code.value, request_info, start_time)
        return _ResponseLoggingWrapper(response, request_info, start_time, self)

    def _handle_http_exception(
        self, exc: HTTPException, request: Request, request_info: Dict, start_time: float
    ) -> Any:
        """HTTPException を処理してレスポンスを返す"""
        language = get_language_from_request(request)
        content = (
            exc.detail
            if isinstance(exc.detail, dict)
            else {
                "error_code": "UNKNOWN_ERROR",
                "message": str(exc.detail),
                "language": language,
            }
        )
        response = JSONResponse(status_code=exc.status_code, content=content)
        self._add_cors_headers_to_response(request, response)
        self._log_error_response(exc.status_code, None, request_info, start_time)
        return _ResponseLoggingWrapper(response, request_info, start_time, self)

    def _log_error_response(
        self, status_code: int, error_code: str | None, request_info: Dict, start_time: float
    ) -> None:
        """エラーレスポンスをログに記録"""
        duration_ms = (time.time() - start_time) * 1000
        error_info = f"Status: {status_code}"
        if error_code:
            error_info += f" | error_code: {error_code}"
        logger.warning(
            f"[{request_info['request_id']}] {request_info['method']} {request_info['path']} | "
            f"{error_info} | Duration: {duration_ms:.2f}ms"
        )

    def _log_unhandled_exception(self, exc: Exception, request_info: Dict, start_time: float) -> None:
        """未処理の例外をログに記録"""
        duration_ms = (time.time() - start_time) * 1000
        logger.error(
            f"[{request_info['request_id']}] ERROR: {request_info['method']} {request_info['path']} | "
            f"Duration: {duration_ms:.2f}ms | Error: {str(exc)}",
            exc_info=True,
        )

    def _add_cors_headers_to_response(self, request: Request, response: JSONResponse) -> None:
        """
        エラーレスポンスに CORS ヘッダを付与する。
        中間件で直接 return するレスポンスは CORSMiddleware を通らないため、
        クロスオリジンのフロントエンドが body を読めるようにここで付与する。
        """
        origin = request.headers.get("origin")
        if not origin:
            return
        
        allowed = settings.CORS_ORIGINS
        if "*" in allowed or origin in allowed:
            # allow_credentials=True のときは * の代わりにリクエストの Origin を返す
            response.headers["access-control-allow-origin"] = origin
            response.headers["access-control-allow-credentials"] = "true"

    def _should_log(self, path: str) -> bool:
        """ログ記録対象かどうかを判定"""
        return path not in self.EXCLUDED_PATHS
    
    def _is_production(self) -> bool:
        """環境が本番環境かどうかを判定"""
        return settings.ENVIRONMENT.lower() == "production"
    
    def _mask_sensitive_dict(self, data: dict, is_header: bool = False) -> dict:
        """辞書型データの敏感フィールドを脱敏"""
        if not self._is_production():
            return data
        
        sensitive_keys = self.SENSITIVE_HEADERS if is_header else self.SENSITIVE_FIELDS
        masked = {}
        for key, value in data.items():
            if any(field in key.lower() for field in sensitive_keys):
                masked[key] = "***REDACTED***"
            else:
                masked[key] = value
        return masked
    
    def _mask_json_body(self, body_str: str) -> str:
        """JSON body の敏感フィールドを脱敏"""
        if not self._is_production():
            return body_str
        
        try:
            body_obj = json.loads(body_str)
            if isinstance(body_obj, dict):
                masked_obj = {}
                for key, value in body_obj.items():
                    key_lower = key.lower()
                    if any(field in key_lower for field in self.SENSITIVE_FIELDS):
                        masked_obj[key] = "***REDACTED***"
                    elif isinstance(value, dict):
                        masked_obj[key] = self._mask_sensitive_dict(value)
                    else:
                        masked_obj[key] = value
                return json.dumps(masked_obj, ensure_ascii=False, indent=2)
        except Exception:
            pass
        return body_str
    
    async def _extract_request_info(self, request: Request, request_id: str) -> dict:
        """リクエスト情報を抽出"""
        # Body を読み取る
        body_bytes = await request.body()
        
        # Body をデコード（JSON の場合はパース）
        body_str = ""
        if body_bytes:
            try:
                body_str = body_bytes.decode("utf-8")
                # JSON としてパース可能か試す
                if request.headers.get("content-type", "").startswith("application/json"):
                    json.loads(body_str)  # バリデーションのみ
            except Exception:
                body_str = f"<binary data, {len(body_bytes)} bytes>"
        
        # Body サイズ制限
        if len(body_str) > self.max_body_size:
            body_str = body_str[:self.max_body_size] + f"... [truncated, total size: {len(body_bytes)} bytes]"
        
        # 敏感データの脱敏（本番環境のみ）
        headers = dict(request.headers)
        headers = self._mask_sensitive_dict(headers, is_header=True)
        body_str = self._mask_json_body(body_str)
        
        return {
            "request_id": request_id,
            "method": request.method,
            "path": str(request.url.path),
            "query_params": dict(request.query_params),
            "path_params": dict(request.path_params),
            "headers": headers,
            "body": body_str,
            "body_bytes": body_bytes,
            "client_host": request.client.host if request.client else None,
        }
    
    def _log_request(self, request_info: dict):
        """リクエストログを記録"""
        log_lines = [
            f"[{request_info['request_id']}]",
            f"REQUEST: {request_info['method']} {request_info['path']}",
            f"Client: {request_info['client_host']}",
            f"Headers: {self._format_json(request_info['headers'])}",
            f"Query Params: {self._format_json(request_info['query_params'])}",
            f"Path Params: {self._format_json(request_info['path_params'])}",
        ]
        
        if self.log_request_body:
            body_str = self._format_body(request_info['body'], request_info['headers'])
            log_lines.append(f"Body: {body_str}")
        
        logger.info("\n".join(log_lines))
    
    def _log_response(self, request_info: dict, response_info: dict, duration_ms: float):
        """レスポンスログを記録"""
        log_lines = [
            f"[{request_info['request_id']}]",
            f"RESPONSE: {request_info['method']} {request_info['path']} | "
            f"Status: {response_info['status_code']} | Duration: {duration_ms:.2f}ms",
            f"Headers: {self._format_json(response_info['headers'])}",
        ]
        
        if self.log_response_body:
            body_str = self._format_body(response_info['body'], response_info['headers'], prefix="Response ")
            log_lines.append(f"{body_str}")
        
        logger.info("\n".join(log_lines))

    def _format_json(self, data: dict) -> str:
        """辞書を JSON 文字列にフォーマット"""
        return json.dumps(data, ensure_ascii=False, indent=2)

    def _format_body(self, body: str, headers: dict, prefix: str = "") -> str:
        """Body をフォーマット（JSON の場合は整形）"""
        if not body:
            return f"{prefix}Body: <empty>"
        
        content_type = headers.get('content-type', '')
        if content_type.startswith('application/json'):
            try:
                body_obj = json.loads(body)
                body_formatted = json.dumps(body_obj, ensure_ascii=False, indent=2)
                return f"{prefix}Body: {body_formatted}"
            except Exception:
                pass
        return f"{prefix}Body: {body}"
